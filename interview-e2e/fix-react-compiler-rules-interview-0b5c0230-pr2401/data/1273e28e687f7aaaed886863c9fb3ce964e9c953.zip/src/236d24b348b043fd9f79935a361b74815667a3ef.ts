import { expect, type Locator, type Page } from '@playwright/test';

type CaptureOptions = {
  mask?: Locator[];
  fullPage?: boolean;
};

type CaptureInterviewFn = (
  name: string,
  options?: CaptureOptions,
) => Promise<void>;

/**
 * Interview fixture for e2e tests.
 *
 * Handles interview shell and navigation concerns.
 * Use the `stage` fixture for stage-specific interactions.
 */
export class InterviewFixture {
  readonly page: Page;
  private captureFn: CaptureInterviewFn | null = null;

  /**
   * The interview ID. Must be set before using navigation methods.
   * Typically set in beforeEach after creating the interview in beforeAll.
   */
  interviewId = '';

  /**
   * Optional prefix for screenshot names. Set this in beforeAll/beforeEach
   * to avoid snapshot name collisions between test files testing the same stages.
   */
  snapshotPrefix = '';

  /**
   * When true, afterEach hooks should skip calling next().
   * Set this in tests that call next() or finishInterview() themselves
   * (e.g. form stages with post-submit waits, or finish tests).
   */
  skipNext = false;

  constructor(page: Page) {
    this.page = page;
  }

  /**
   * Set the capture function for automatic screenshots.
   * Called by the interview-test fixture to wire up captureInterview.
   */
  setCaptureFn(fn: CaptureInterviewFn): void {
    this.captureFn = fn;
  }

  /**
   * Manually capture a screenshot with the given name.
   * Useful in afterEach hooks to capture end state.
   * The snapshotPrefix is NOT automatically prepended - use the full name you want.
   */
  async capture(name: string, options?: CaptureOptions): Promise<void> {
    if (this.captureFn) {
      const resolvedOptions = this.resolveCaptureMasks(options);
      await this.captureFn(name, resolvedOptions);
    }
  }

  private resolveCaptureMasks(options?: CaptureOptions): CaptureOptions {
    const videoLocator = this.page.locator('video');
    const existingMasks = options?.mask ?? [];

    return {
      ...options,
      mask: [...existingMasks, videoLocator],
    };
  }

  /**
   * Navigate directly to a stage by index.
   * Navigates to the host app with both interviewId and step query params.
   */
  async goto(stageIndex: number): Promise<void> {
    if (!this.interviewId) {
      throw new Error(
        'interviewId must be set before calling goto(). Set it in beforeEach.',
      );
    }

    await this.page.goto(
      `/?interviewId=${this.interviewId}&step=${stageIndex}`,
    );
    await this.waitForStageLoad();
  }

  /**
   * Open a finished interview. It opens in its completed state, which is no
   * stage the host can step to, so there is no step to wait for: wait for the
   * completed state's heading instead.
   */
  async gotoFinished(stageIndex: number): Promise<void> {
    if (!this.interviewId) {
      throw new Error(
        'interviewId must be set before calling gotoFinished(). Set it in beforeEach.',
      );
    }

    await this.page.goto(
      `/?interviewId=${this.interviewId}&step=${stageIndex}`,
    );
    const main = this.page.locator('main[data-theme-interview]');
    await expect(main).toBeVisible({ timeout: 15_000 });
    await expect(main.locator('[data-interview-completed]')).toBeVisible();
    await expect(main.getByRole('heading', { level: 1 })).toBeVisible();
    await this.waitForMotionCommit();
  }

  async captureInitial(mask?: Locator[]): Promise<void> {
    if (!this.interviewId) {
      throw new Error(
        'interviewId must be set before calling goto(). Set it in beforeEach.',
      );
    }

    const stageIndex = this.getCurrentStep() ?? 'unknown';

    await this.waitForStageLoad();

    const prefix = this.snapshotPrefix ? `${this.snapshotPrefix}-` : '';
    await this.capture(
      `${prefix}stage-${stageIndex}`,
      mask ? { mask } : undefined,
    );
  }

  /**
   * Capture the stage's end state, rendering the full content of any
   * inner scroll container regardless of length.
   *
   * The app shell is viewport-sized and scrolls inside nested elements,
   * so a plain fullPage screenshot would still only show one viewport.
   * Instead, every scrollable element (and its ancestors, whose
   * height/overflow constraints would otherwise clip it) is temporarily
   * expanded so the document itself grows, the screenshot is taken with
   * fullPage, and the inline styles are restored before the test
   * proceeds. A scrollable element that still overflows the page once
   * expanded is left at its normal size.
   */
  async captureFinal(mask?: Locator[]): Promise<void> {
    const step = this.getCurrentStep();
    if (step) {
      await this.waitForMotionCommit();

      const hasScrollableContent = await this.page.evaluate(() => {
        const modified = new Map<HTMLElement, string>();
        const expand = (scrollers: HTMLElement[]) => {
          for (const scroller of scrollers) {
            let el: HTMLElement | null = scroller;
            while (el) {
              if (!modified.has(el)) {
                modified.set(el, el.style.cssText);
              }
              el.style.height = 'auto';
              el.style.maxHeight = 'none';
              el.style.overflowY = 'visible';
              el = el.parentElement;
            }
          }
        };
        const restore = () => {
          for (const [el, cssText] of modified) {
            el.style.cssText = cssText;
          }
          modified.clear();
        };
        const candidates = Array.from(
          document.querySelectorAll<HTMLElement>('*'),
        ).filter((el) => {
          const overflowY = getComputedStyle(el).overflowY;
          return (
            (overflowY === 'auto' || overflowY === 'scroll') &&
            el.scrollHeight > el.clientHeight
          );
        });
        const fitsInPage = (el: HTMLElement) =>
          el.getBoundingClientRect().bottom <=
          document.documentElement.getBoundingClientRect().bottom + 1;

        let scrollers = candidates;
        expand(scrollers);
        while (scrollers.length > 0 && !scrollers.every(fitsInPage)) {
          scrollers = scrollers.filter(fitsInPage);
          restore();
          expand(scrollers);
        }

        window.__restoreExpandedScrollers = () => {
          restore();
          delete window.__restoreExpandedScrollers;
        };
        return scrollers.length > 0;
      });

      const prefix = this.snapshotPrefix ? `${this.snapshotPrefix}-` : '';
      await this.capture(`${prefix}stage-${step}-final`, {
        fullPage: hasScrollableContent,
        ...(mask ? { mask } : {}),
      });

      await this.page.evaluate(() => {
        window.__restoreExpandedScrollers?.();
      });
    }
  }

  get nextButton(): Locator {
    return this.page.getByTestId('next-button');
  }

  async nextButtonHasPulse(): Promise<boolean> {
    const className = await this.nextButton.getAttribute('class');
    return className?.includes('bg-success') ?? false;
  }

  /**
   * Click next and wait for the new stage to be fully mounted.
   *
   * The Shell uses a two-phase transition: first the URL updates (controlled
   * step changes immediately), then the exit animation plays, then the new
   * stage mounts. We wait for the URL change and then for the stage element
   * to reflect the new Redux step index (set only after exit animation).
   */
  async next(): Promise<void> {
    const before = this.getCurrentStep();
    await this.nextButton.click();
    if (before !== null) {
      await this.page.waitForURL(
        (url) => {
          const match = /step=(\d+)/.exec(url.toString());
          return match ? match[1] !== before : false;
        },
        { timeout: 20_000 },
      );
    }
  }

  /**
   * Wait for a SlidesForm stage's (AlterForm, AlterEdgeForm) form section to
   * finish entering. Use before the first interaction with a form field —
   * the section fades in, and Playwright otherwise races the input mount.
   */
  async waitForForm(): Promise<void> {
    await this.page
      .locator('[data-stage-section="form"][data-stage-ready="true"]')
      .waitFor({ state: 'visible', timeout: 5_000 });
  }

  /**
   * Complete the FinishSession stage: click Finish, confirm the dialog.
   *
   * Note: in the standalone host the onFinish handler is a no-op — no URL
   * redirect occurs after finishing.
   */
  async finishInterview(): Promise<void> {
    await expect(
      this.page.getByRole('heading', { name: 'Finish Interview' }),
    ).toBeVisible();

    await this.page.getByRole('button', { name: 'Finish' }).click();

    const dialog = this.page.getByRole('dialog');
    await expect(dialog).toBeVisible();

    await dialog.getByRole('button', { name: 'Finish', exact: true }).click();
  }

  /**
   * Leave the interview and resume it, as a participant returning later
   * would: the host remounts it from the session it holds, so answers are
   * kept and the in-memory encryption key is not. The step is kept too.
   */
  async resume(): Promise<void> {
    if (!this.interviewId) {
      throw new Error('interviewId must be set before calling resume().');
    }
    // The running interview's root is marked so that its replacement, not the
    // root about to be unmounted, is what the stage-load wait sees.
    await this.page.evaluate((id) => {
      document
        .querySelector('main[data-theme-interview]')
        ?.setAttribute('data-e2e-before-resume', '');
      window.__test.remountInterview(id);
    }, this.interviewId);
    await this.page
      .locator('main[data-e2e-before-resume]')
      .waitFor({ state: 'detached', timeout: 15_000 });
    await this.waitForStageLoad();
  }

  /**
   * Navigate to an interview and wait for it to load.
   * Use this in beforeEach to set the starting URL.
   */
  async navigateTo(interviewId: string, step?: number): Promise<void> {
    this.interviewId = interviewId;
    const params = new URLSearchParams({ interviewId });
    if (step !== undefined) {
      params.set('step', String(step));
    }
    await this.page.goto(`/?${params.toString()}`);
    await this.waitForStageLoad();
  }

  private getCurrentStep(): string | null {
    const match = /step=(\d+)/.exec(this.page.url());
    return match?.[1] ?? null;
  }

  /**
   * Wait for motion to commit its initial-mount animation.
   *
   * motion's `MotionConfig skipAnimations` zero-durations transitions but does
   * NOT change what React commits on first render — components mount with
   * their `initial` variant (e.g. `opacity: 0`) and only flip to `animate` in
   * a `useEffect` that fires AFTER the first paint. Playwright's stable-frame
   * heuristic can latch onto that brief initial-variant paint and capture a
   * pre-animation screenshot (most visibly: CategoricalBin bins inside an
   * `<AnimatePresence>` rendering at `opacity: 0`).
   *
   * Two rAFs is enough: the first lets the `useEffect` fire and commit the
   * `animate` values, the second lets the resulting paint complete. ~32ms.
   */
  private async waitForMotionCommit(): Promise<void> {
    await this.page.evaluate(
      () =>
        new Promise<void>((resolve) =>
          requestAnimationFrame(() => requestAnimationFrame(() => resolve())),
        ),
    );
  }

  private async waitForStageLoad(): Promise<void> {
    const mainLocator = this.page.locator('main[data-theme-interview]');
    const currentStep = this.getCurrentStep();

    try {
      await expect(mainLocator).toBeVisible({ timeout: 15000 });
      // If we know the expected step, wait for the Shell's two-phase
      // transition to complete. The motion.div gets data-stage-step={n} only
      // after handleExitComplete updates Redux (via onExitComplete or timer).
      // A finished interview shows its completed state instead, which has no
      // stage step: it is marked data-interview-completed.
      if (currentStep !== null) {
        await this.page
          .locator(`[data-stage-step="${currentStep}"]`)
          .or(this.page.locator('[data-interview-completed]'))
          .waitFor({ state: 'attached', timeout: 5_000 });
      }
      await this.waitForMotionCommit();
    } catch (error) {
      const url = this.page.url();
      const title = await this.page.title();
      const bodyText = await this.page
        .locator('body')
        .textContent()
        .catch(() => 'N/A');

      const diagnostics = [
        'Interview stage load failed',
        `URL: ${url}`,
        `Title: ${title}`,
        `Body content (truncated): ${bodyText?.slice(0, 500) ?? 'empty'}`,
      ].join('\n');

      throw new Error(`${diagnostics}\n\nOriginal error: ${String(error)}`, {
        cause: error,
      });
    }
  }
}
