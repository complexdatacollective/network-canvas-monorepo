import { matrixTest } from '../fixtures/matrix-test.js';
import {
  buildSyntheticPayload,
  finishStageIdOf,
} from '../helpers/synthetic-payload.js';
import type {
  InterfaceScenarios,
  ScenarioContext,
  ScenarioDefinition,
} from './types.js';

/**
 * Install a scenario's protocol + seeded interview and navigate to its
 * starting step. Shared by the matrix runner and the visual suite.
 */
export async function installScenario(
  scenario: ScenarioDefinition,
  ctx: ScenarioContext,
): Promise<void> {
  const synth = scenario.build();
  const result = buildSyntheticPayload(synth, {
    protocolName: `matrix-${scenario.id}`,
    assets: scenario.assets,
    currentStep: scenario.currentStep,
    seedNetwork: scenario.seedNetwork,
    schema8Encryption: scenario.schema8Encryption,
    stageMetadata: scenario.stageMetadata,
  });
  const { protocolId } = await ctx.protocol.installPayload(result);
  const interviewId = await ctx.protocol.createInterview(
    protocolId,
    `matrix-${scenario.id}`,
    {
      network: result.session.network,
      ...(result.session.stageMetadata != null
        ? { stageMetadata: result.session.stageMetadata }
        : {}),
      ...(scenario.finished
        ? {
            finishedAt: {
              stageId:
                scenario.finished === 'recorded'
                  ? (finishStageIdOf(result.protocol) ?? null)
                  : null,
            },
          }
        : {}),
    },
  );
  ctx.interview.interviewId = interviewId;
  if (scenario.finished) {
    await ctx.interview.gotoFinished(result.currentStep);
  } else {
    await ctx.interview.goto(result.currentStep);
  }
}

export function defineScenarioTests(suite: InterfaceScenarios): void {
  for (const scenario of suite.scenarios) {
    if (scenario.touch) {
      // A context's touch screen is fixed when it is created, so a touch
      // scenario gets a context of its own.
      matrixTest.describe(() => {
        matrixTest.use({ hasTouch: true });
        defineScenarioTest(suite, scenario);
      });
    } else {
      defineScenarioTest(suite, scenario);
    }
  }
}

function defineScenarioTest(
  suite: InterfaceScenarios,
  scenario: ScenarioDefinition,
): void {
  const tags = scenario.smoke ? ' @smoke' : '';
  matrixTest(
    `${suite.interfaceType}: ${scenario.id}${tags}`,
    async ({ page, interview, stage, protocol, ariaSnapshot }) => {
      if (scenario.chromiumOnly) {
        matrixTest.skip(
          !matrixTest.info().project.name.startsWith('chromium'),
          'chromium-only scenario',
        );
      }
      if (scenario.slow) {
        matrixTest.slow();
      }
      const ctx: ScenarioContext = { page, interview, stage, protocol };
      await installScenario(scenario, ctx);
      await ariaSnapshot('initial');
      await scenario.run(ctx);
      await ariaSnapshot('final');
    },
  );
}
