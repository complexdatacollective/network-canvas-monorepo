import plugin from "tailwindcss/plugin";
import { generateShadowLayers } from "./jwc";
const elevationPlugin = plugin.withOptions((options = {}) => (api) => {
    const { lightX = 0, lightY = -0.5, oomph = 0.5, crispy = 0.5, resolution = 0.5, opacityScaleFactor = 0.5, } = options;
    const defaultShadowColor = "oklch(10% 1 180)";
    const generateShadow = (elevation) => {
        return generateShadowLayers(elevation, oomph, crispy, {
            x: lightX,
            y: lightY,
        }, resolution)
            .map(({ opacity, blurRadius, spreadRadius, offsetX, offsetY }) => {
            const boostedOpacity = opacity * opacityScaleFactor;
            // Clamp chroma
            return `${offsetX} ${offsetY} ${blurRadius} ${spreadRadius} oklch(from var(--published-bg, ${defaultShadowColor}) clamp(0.025, calc(l - 0.5), 0.1) clamp(0.2, calc(c * 2), 0.5) h / ${boostedOpacity})`;
        })
            .join(", ");
    };
    // Reset --scoped-bg on elements with bg-* but not publish-colors
    // This prevents child elements from overriding the published background
    api.addBase({
        '[class*="bg-"]:where(:not(.publish-colors))': {
            "--scoped-bg": "inherit !important",
        },
    });
    api.addUtilities({
        ".elevation-none": {
            "box-shadow": "none",
        },
        ".elevation-low": {
            "box-shadow": generateShadow("low"),
        },
        ".elevation-medium": {
            "box-shadow": generateShadow("medium"),
        },
        ".elevation-high": {
            "box-shadow": generateShadow("high"),
        },
        ".publish-colors": {
            // These need to be css Color values.
            "--published-bg": "var(--scoped-bg, --color-background)",
            "--published-text": "var(--scoped-text, currentColor)",
        },
    });
    // Use matchUtilities to create bg utilities that set --scoped-bg
    // Transform var(--foo) to var(--color-foo) to match Tailwind's generated color variables
    const toColorVar = (value) => typeof value === "string" && value.startsWith("var(--") ? value.replace(/^var\(--/, "var(--color-") : value;
    // `modifiers: 'any'` ensures alpha-modified classes like `bg-primary/90`
    // still set --scoped-bg. Shadow derivation uses the solid color, so the
    // alpha on the visible background is intentionally discarded here.
    api.matchUtilities({
        bg: (value) => ({
            "--scoped-bg": toColorVar(value),
        }),
    }, {
        values: (api.theme?.("backgroundColor") ?? api.theme?.("colors") ?? {}),
        modifiers: "any",
    });
    api.matchUtilities({
        text: (value) => ({
            "--scoped-text": toColorVar(value),
        }),
    }, {
        values: (api.theme?.("textColor") ?? api.theme?.("colors") ?? {}),
        modifiers: "any",
    });
}, () => ({
    theme: {
        extend: {
            elevation: {
                low: "elevation-low",
                medium: "elevation-medium",
                high: "elevation-high",
            },
        },
    },
}));
export default elevationPlugin;
