import { readFileSync } from 'node:fs';

import type { Page } from '@playwright/test';
import JSZip from 'jszip';

import { DB_NAME } from '../../src/lib/db/storageNames.js';
import { expect, test } from '../fixtures/test.js';
import {
  LEAN_E2E_PROTOCOL_NAME,
  LEAN_E2E_PROTOCOL_PATH,
} from '../helpers/protocol-paths.js';

// --- Sociogram keyboard-DnD helpers (Step 5, optional) ------------------
//
// There is no reusable placement fixture for the Sociogram stage — unlike
// packages/interview/e2e's stage-fixture.ts, which is scoped to that
// package's own Playwright project (a Storybook-hosted contract, not this
// app). These are modelled on stage-fixture.ts's navigateDndToTarget /
// dragNodeToMainList (Ctrl+D to pick up, arrow keys to cycle drop targets,
// Enter to drop) and SociogramFixture.connectNodes (click source then
// target to link; edges counted as visible SVG lines) — see
// packages/interview/e2e/fixtures/stage-fixture.ts:35, :1067, :305-403.
//
// The lean e2e protocol's Sociogram stage sets no `behaviours.automaticLayout`
// (packages/protocols/e2e/interviewer-e2e/protocol.json), so Sociogram.tsx
// resolves `layoutMode: 'MANUAL'`: the force-directed worker (useAutoLayout)
// is disabled entirely and placement is purely drag-driven, so there is no
// non-deterministic physics settle to wait on — the flakiness risk the task
// brief warned about for the *automatic*-layout case doesn't apply here.

async function getDndAnnouncement(page: Page): Promise<string> {
  return page.evaluate(() => {
    const statusElements = document.querySelectorAll(
      'body > div[role="status"][aria-live="polite"]',
    );
    for (const el of statusElements) {
      const text = el.textContent?.trim() ?? '';
      if (text.includes('Drop target')) {
        return text;
      }
    }
    return '';
  });
}

// Picks up an unplaced node from the drawer and drops it onto the Sociogram
// canvas via keyboard DnD. Canvas.tsx computes the drop position from the
// last real pointer position (a document-level `pointermove` listener, since
// keyboard DnD never dispatches one) — moving the mouse first means each
// node lands at a distinct point instead of stacking at the (0.5, 0.5)
// default.
async function placeNodeOnCanvas(
  page: Page,
  label: string,
  point: { x: number; y: number },
  maxSteps = 5,
): Promise<void> {
  const node = page.getByRole('button', { name: new RegExp(`^${label}`) });
  await expect(node).toBeVisible();

  await page.mouse.move(point.x, point.y);

  await node.evaluate((el) => {
    if (el instanceof HTMLElement) el.focus();
  });
  await node.press('Control+d');

  let found = false;
  for (let i = 0; i < maxSteps; i++) {
    await page.keyboard.press('ArrowRight');
    const announcement = await getDndAnnouncement(page);
    if (announcement.includes('Placement area')) {
      found = true;
      break;
    }
  }
  if (!found) {
    throw new Error(
      `Could not find the "Placement area" drop target for "${label}" after ${maxSteps} steps`,
    );
  }
  await page.keyboard.press('Enter');
}

function getEdgeCount(page: Page): Promise<number> {
  return page.locator('svg line[visibility="visible"]').count();
}

// Reads the stored session's network node count straight from IndexedDB.
// Vault mode is 'none' in this suite, so `network` is plaintext on the row.
// Returns null only when the row is absent; a failed read rejects (failing
// the test) rather than becoming a value an assertion could compare.
function readStoredNodeCount(
  page: Page,
  sessionId: string,
): Promise<number | null> {
  return page.evaluate(
    ({ id, dbName }) =>
      new Promise<number | null>((resolve, reject) => {
        const req = indexedDB.open(dbName);
        req.addEventListener('error', () =>
          reject(new Error('indexedDB.open failed')),
        );
        req.onsuccess = () => {
          const get = req.result
            .transaction('sessions', 'readonly')
            .objectStore('sessions')
            .get(id);
          get.addEventListener('error', () =>
            reject(new Error('sessions.get failed')),
          );
          get.onsuccess = () => {
            const row = get.result as
              | { network?: { nodes?: unknown[] } }
              | undefined;
            if (!row) return resolve(null);
            const nodes = row.network?.nodes;
            if (!Array.isArray(nodes)) {
              return reject(new Error('session row has no plaintext network'));
            }
            resolve(nodes.length);
          };
        };
      }),
    { id: sessionId, dbName: DB_NAME },
  );
}

const isRecord = (value: unknown): value is Record<string, unknown> =>
  typeof value === 'object' && value !== null;

// The id of the finish stage in the protocol archive the test imports, found
// by its type: stage ids are UUIDs the fixture's build assigns.
async function finishStageIdOf(archivePath: string): Promise<string> {
  const zip = await JSZip.loadAsync(readFileSync(archivePath));
  const source = await zip.file('protocol.json')?.async('string');
  const protocol: unknown = JSON.parse(source ?? 'null');
  const stages: unknown[] =
    isRecord(protocol) && Array.isArray(protocol.stages) ? protocol.stages : [];
  const finish = stages.find(
    (stage) => isRecord(stage) && stage.type === 'FinishSession',
  );
  return isRecord(finish) && typeof finish.id === 'string' ? finish.id : '';
}

type StoredFinish = {
  finishedAt: string | null;
  finishStageId: unknown;
  finishOutcome: unknown;
};

// Reads the stored session's finish fields straight from IndexedDB. Vault mode
// is 'none' in this suite, so they are plaintext on the row. Returns null only
// when the row is absent; a failed read rejects.
function readStoredFinish(
  page: Page,
  sessionId: string,
): Promise<StoredFinish | null> {
  return page.evaluate(
    ({ id, dbName }) =>
      new Promise<StoredFinish | null>((resolve, reject) => {
        const req = indexedDB.open(dbName);
        req.addEventListener('error', () =>
          reject(new Error('indexedDB.open failed')),
        );
        req.onsuccess = () => {
          const get = req.result
            .transaction('sessions', 'readonly')
            .objectStore('sessions')
            .get(id);
          get.addEventListener('error', () =>
            reject(new Error('sessions.get failed')),
          );
          get.onsuccess = () => {
            const row = get.result as
              | {
                  finishedAt: string | null;
                  finishStageId?: unknown;
                  finishOutcome?: unknown;
                }
              | undefined;
            if (!row) return resolve(null);
            resolve({
              finishedAt: row.finishedAt,
              finishStageId: row.finishStageId,
              finishOutcome: row.finishOutcome,
            });
          };
        };
      }),
    { id: sessionId, dbName: DB_NAME },
  );
}

async function connectNodes(
  page: Page,
  fromLabel: string,
  toLabel: string,
): Promise<void> {
  const fromNode = page.getByRole('button', {
    name: new RegExp(`^${fromLabel}`),
  });
  const toNode = page.getByRole('button', {
    name: new RegExp(`^${toLabel}`),
  });
  const edgesBefore = await getEdgeCount(page);

  await fromNode.click();
  await expect(fromNode).toHaveAttribute('data-node-linking', 'true');
  await toNode.click();
  await expect(fromNode).not.toHaveAttribute('data-node-linking');
  await expect.poll(() => getEdgeCount(page)).not.toBe(edgesBefore);
}

test.describe('conducting an interview', () => {
  test(
    'walks the lean protocol from start to completion',
    {
      tag: '@visual',
    },
    async ({ protocol, interviewNav, page, capture }) => {
      await protocol.import(LEAN_E2E_PROTOCOL_PATH, LEAN_E2E_PROTOCOL_NAME);
      await interviewNav.startNewSession('P01');

      // Stage 0: Information — capture then advance.
      await capture('interview-stage-info');
      await interviewNav.next();

      // Stage 1: EgoForm.
      await interviewNav.fillEgoName('Ada');
      // The baseline below shows the next-button's pulse, which appears with
      // the ready-to-continue description on the same button.
      await expect(page.getByTestId('next-button')).toHaveAccessibleDescription(
        'You can continue to the next step.',
      );
      await capture('interview-stage-ego');
      await interviewNav.next();

      // Stage 2: NameGeneratorQuickAdd — add two alters.
      await interviewNav.quickAddNode('Grace');
      await interviewNav.quickAddNode('Katherine');
      await capture('interview-stage-namegen');
      await interviewNav.next();

      // Stage 3: Sociogram — placement/edges are exercised in the dedicated
      // sociogram test below; here we simply advance to Finish. Nodes may
      // remain unplaced in the drawer — the stage has no minNodes-placed
      // behaviour.
      await capture('interview-stage-sociogram');
      await interviewNav.next();

      // FinishSession stage.
      const sessionId = /\/interview\/([^/?#]+)/.exec(page.url())?.[1] ?? '';
      await interviewNav.finish();

      // The interview shows its completed state in place: the finish stage's
      // finished screen, no Finish button, and the app's Exit.
      await expect(
        page.getByText('Thank you for participating!'),
      ).toBeVisible();
      await expect(
        page.getByRole('heading', { name: 'Interview Finished' }),
      ).toBeVisible();
      await expect(
        page.getByRole('button', { name: 'Finish', exact: true }),
      ).toHaveCount(0);
      await expect(page).toHaveURL(new RegExp(`/interview/${sessionId}$`));
      // The finish is stored with the stage it happened at and its outcome.
      const finishStageId = await finishStageIdOf(LEAN_E2E_PROTOCOL_PATH);
      expect(finishStageId).not.toBe('');
      await expect
        .poll(() => readStoredFinish(page, sessionId))
        .toEqual({
          finishedAt: expect.any(String),
          finishStageId,
          finishOutcome: 'completed',
        });
      await capture('interview-complete');

      await page.getByRole('button', { name: 'Exit', exact: true }).click();
      await expect(page).toHaveURL(/\/(data)?$/);

      // Opening it again, without asking to review it, shows the same
      // completed state.
      await page.goto(`/interview/${sessionId}`);
      await expect(
        page.getByText('Thank you for participating!'),
      ).toBeVisible();
      await expect(
        page.getByRole('heading', { name: 'Interview Finished' }),
      ).toBeVisible();
      await expect(
        page.getByRole('button', { name: 'Exit', exact: true }),
      ).toBeVisible();
      await expect(page.getByText('Read-only review')).toHaveCount(0);
    },
  );

  test('resumes a partially-completed interview at the right stage', async ({
    protocol,
    interviewNav,
    page,
  }) => {
    await protocol.import(LEAN_E2E_PROTOCOL_PATH, LEAN_E2E_PROTOCOL_NAME);
    await interviewNav.startNewSession('P02');
    // Advance one stage so currentStep persists (>0), then leave.
    await interviewNav.next();
    const stepBefore = await page
      .locator('[data-stage-step]')
      .getAttribute('data-stage-step');

    // InterviewRoute persists currentStep with a fire-and-forget updateSession,
    // so navigating away immediately can unmount before the write lands and
    // leave the resume row on the previous step. Wait for the persisted
    // currentStep (a plaintext field on the session row) to reflect the advance
    // before leaving.
    const sessionId = /\/interview\/([^/?#]+)/.exec(page.url())?.[1] ?? '';
    await expect
      .poll(
        () =>
          page.evaluate(
            ({ id, dbName }) =>
              new Promise<number | null>((resolve) => {
                const req = indexedDB.open(dbName);
                req.onsuccess = () => {
                  const get = req.result
                    .transaction('sessions', 'readonly')
                    .objectStore('sessions')
                    .get(id);
                  get.onsuccess = () =>
                    resolve(
                      (get.result as { currentStep?: number } | undefined)
                        ?.currentStep ?? null,
                    );
                  get.addEventListener('error', () => resolve(null));
                };
                req.addEventListener('error', () => resolve(null));
              }),
            { id: sessionId, dbName: DB_NAME },
          ),
        { timeout: 10_000 },
      )
      .toBe(Number(stepBefore));

    await page.goto('/data');

    // Resume via the in-progress row.
    await page.getByRole('button', { name: /^In progress ·/ }).click();
    await page.getByTestId('data-resume').first().click();
    await interviewNav.waitForStage();
    // hydrateSession restores currentStep (Interview.tsx); promptIndex is
    // always reset to 0 on hydration and is not asserted here.
    await expect(page.locator('[data-stage-step]')).toHaveAttribute(
      'data-stage-step',
      stepBefore ?? '1',
    );
  });

  test('resuming immediately after exit keeps the just-added alter', async ({
    protocol,
    interviewNav,
    page,
  }) => {
    await protocol.import(LEAN_E2E_PROTOCOL_PATH, LEAN_E2E_PROTOCOL_NAME);
    await interviewNav.startNewSession('P04');
    const sessionId = /\/interview\/([^/?#]+)/.exec(page.url())?.[1] ?? '';
    expect(sessionId).not.toBe('');

    await interviewNav.next(); // Information -> EgoForm
    await interviewNav.fillEgoName('Ada');
    await interviewNav.next(); // EgoForm -> NameGeneratorQuickAdd

    await interviewNav.quickAddNode('LossProbe');

    // Exit and resume PROMPTLY: the engine autosaves on a 3s trailing
    // debounce, so the alter added above is still in the debounce window when
    // we leave. Before the fix (Shell unmount flush + getSession joining the
    // session write chain), a resume within that window hydrated the
    // pre-write network — the alter rendered missing — and the resumed
    // engine's next autosave wrote that stale network back over the stored
    // row, destroying the alter. Do not add waits between these steps: the
    // promptness is what this test guards.
    await interviewNav.exitInterview();
    await page.getByRole('button', { name: /Resume last interview/ }).click();
    await interviewNav.waitForStage();

    // The just-added alter must be rendered on the resumed stage.
    await expect(page.getByRole('option', { name: 'LossProbe' })).toBeVisible();

    // Ordinary navigation after the resume must not clobber the stored
    // network (this is the write that destroyed the alter pre-fix).
    await interviewNav.next(); // NameGeneratorQuickAdd -> Sociogram
    await interviewNav.back(); // Sociogram -> NameGeneratorQuickAdd
    await expect(page.getByRole('option', { name: 'LossProbe' })).toBeVisible();
    await expect
      .poll(() => readStoredNodeCount(page, sessionId), { timeout: 10_000 })
      .toBe(1);
  });

  test('places nodes on the sociogram canvas and connects them', async ({
    protocol,
    interviewNav,
    page,
  }) => {
    await protocol.import(LEAN_E2E_PROTOCOL_PATH, LEAN_E2E_PROTOCOL_NAME);
    await interviewNav.startNewSession('P03');
    await interviewNav.next(); // Information -> EgoForm

    await interviewNav.fillEgoName('Rosalind');
    await interviewNav.next(); // EgoForm -> NameGeneratorQuickAdd

    await interviewNav.quickAddNode('Alice');
    await interviewNav.quickAddNode('Bob');
    await interviewNav.next(); // NameGeneratorQuickAdd -> Sociogram

    const canvas = page.getByRole('application', {
      name: 'Placement area',
    });
    const box = await canvas.boundingBox();
    if (!box) throw new Error('Sociogram canvas has no bounding box');

    await placeNodeOnCanvas(page, 'Alice', {
      x: box.x + box.width * 0.3,
      y: box.y + box.height * 0.3,
    });
    await placeNodeOnCanvas(page, 'Bob', {
      x: box.x + box.width * 0.7,
      y: box.y + box.height * 0.6,
    });

    // Both alters are now placed; the drawer reports zero unplaced.
    await expect(page.getByText(/^0 unplaced$/)).toBeVisible();

    await expect.poll(() => getEdgeCount(page)).toBe(0);
    await connectNodes(page, 'Alice', 'Bob');
    await expect.poll(() => getEdgeCount(page)).toBe(1);
  });
});
