import{$n as e,An as t,Ci as n,Ct as r,D as i,Dr as a,Dt as o,E as s,Ei as c,Er as l,Gr as u,Gt as d,Hn as f,Ht as p,I as m,Ii as h,In as g,Ki as _,Kt as v,L as y,Li as b,Lt as x,M as S,Mn as C,O as w,On as T,Ot as E,R as D,Ri as O,Rn as ee,Sa as te,Si as k,Tn as A,Tt as j,Un as M,V as N,Vt as P,Wi as F,Wt as I,Y as L,Yt as R,Z as z,Zi as B,Zn as V,Zt as H,_ as U,_a as ne,_r as re,_t as ie,ai as ae,an as oe,ar as se,at as ce,bi as le,c as ue,ca as W,en as G,ga as de,gt as fe,h as pe,ha as me,jn as he,li as ge,lr as _e,mi as ve,na as ye,ni as be,nn as xe,oa as Se,on as K,or as Ce,p as we,pn as Te,pt as Ee,q,qr as J,rr as De,si as Oe,sr as Y,st as ke,tt as Ae,u as je,x as Me,xa as Ne,xn as X,xt as Pe,ya as Fe,yt as Ie,zi as Le}from"./interview-engine-BWTdRp2k.js";import{n as Re,t as ze}from"./hd_standard.shared-BkCRwBfb.js";import{b as Be,c as Ve,d as He,h as Ue,l as We,o as Ge,s as Ke,t as qe,y as Je}from"./hd_standard.model-DGm0b7P3.js";import{n as Ye}from"./standard.shared-D-IwzUcH.js";var Xe=new Float32Array(Oe([])),Ze=[0,0,0],Qe=(e,t,n,r,i,a,o,s,c,l,u,d,f,p=[0,0,0],m,h,g,_=1,v=!1)=>{let y=Ze,b=0,x=Ze;if(!v){let e=i.style.light,t=e.properties.get(`position`);if(y=[-t.x,-t.y,t.z],e.properties.get(`anchor`)===`viewport`){let e=C();R(e,-i.transform.angle),Ee(y,y,e)}let n=e.properties.get(`color`).toNonPremultipliedRenderColor(null);b=e.properties.get(`intensity`),x=[n.r,n.g,n.b]}let S=u.alphaMode===`MASK`,w=f.paint.get(`model-ambient-occlusion-intensity`),T=f.paint.get(`model-color`).constantOr(K.white).toNonPremultipliedRenderColor(null);return T.a=f.paint.get(`model-color-mix-intensity`).constantOr(0),g&&(T.r=g[0],T.g=g[1],T.b=g[2],T.a=g[3]),h&&(T.r=h.color.r,T.g=h.color.g,T.b=h.color.b,T.a=h.colorMix,d=h.emissionStrength,a*=h.opacity),{u_matrix:e,u_lighting_matrix:t,u_normal_matrix:n,u_node_matrix:r||Xe,u_lightpos:y,u_lightintensity:b,u_lightcolor:x,u_camera_pos:p,u_opacity:a,u_baseTextureIsAlpha:0,u_alphaMask:+S,u_alphaCutoff:u.alphaCutoff,u_baseColorFactor:o.toNonPremultipliedRenderColor(null).toArray01(),u_emissiveFactor:s.toNonPremultipliedRenderColor(null).toArray01(),u_metallicFactor:c,u_roughnessFactor:l,u_baseColorTexture:N.BaseColor,u_metallicRoughnessTexture:N.MetallicRoughness,u_normalTexture:N.Normal,u_occlusionTexture:N.Occlusion,u_emissionTexture:N.Emission,u_lutTexture:N.LUT,u_color_mix:T.toArray01(),u_aoIntensity:w,u_emissive_strength:d,u_occlusionTextureTransform:m||[0,0,0,0],u_dithered_discard_threshold:_,u_model_mesh_params:[0,1,0,0]}},$e=(e,t=Xe,n=Xe)=>({u_matrix:e,u_instance:t,u_node_matrix:n});function et(e,t,n,r){let i=1<<e.z;t.lat=oe((r/f+e.y)/i),t.lng=P((n/f+e.x)/i)}var Z=new Float64Array(16),Q=new Float64Array(16),tt=new Float64Array(16),nt=new Float64Array(16),rt=new Float64Array(16),it=new Float64Array(16),at=new Float64Array(16),ot=[0,0,0],st=new Float32Array(16),ct=[0,0,0],lt=[0,0,0],ut=[];function dt(t,n,r){let i=r.cameraWorldSizeForFog/r.worldSize;return Ce(t,r.worldToFogMatrix,[i,i,1]),e(t,t,n),t}function ft(e,t,n,r){return O(e,t,n),g(r,qe)||Ce(e,e,r),e}function pt(e,t,n,r){let i=n?t.lightsStyleAabb:e.aabb,a=i?i.min[2]:1/0,o=(i?i.max[2]:-1/0)-a;return[isFinite(a)?a:0,o>0&&isFinite(o)?o:1,+!!r,0]}function mt(e,t){return t.featureBuffer?e.partStyleUBO:null}function ht(e,t,n,r,i,a=null){let o=n.material,s=r.context,{baseColorTexture:c,metallicRoughnessTexture:l}=o.pbrMetallicRoughness,{normalTexture:u,occlusionTexture:d,emissionTexture:f}=o;function p(t,n,r){if(t&&(e.push(n),s.activeTexture.set(s.gl.TEXTURE0+r),t.gfxTexture)){let{minFilter:e,magFilter:n,wrapS:r,wrapT:i}=t.sampler;t.gfxTexture.bindExtraParam(e,n,r,i)}}p(c,`HAS_TEXTURE_u_baseColorTexture`,N.BaseColor),p(l,`HAS_TEXTURE_u_metallicRoughnessTexture`,N.MetallicRoughness),p(u,`HAS_TEXTURE_u_normalTexture`,N.Normal),p(d,`HAS_TEXTURE_u_occlusionTexture`,N.Occlusion),p(f,`HAS_TEXTURE_u_emissionTexture`,N.Emission),i&&(i.texture||=new T(r.context,i.image,[i.image.height,i.image.height,i.image.height],s.gl.RGBA8),s.activeTexture.set(s.gl.TEXTURE0+N.LUT),i.texture&&i.texture.bind(s.gl.LINEAR,s.gl.CLAMP_TO_EDGE),e.push(`APPLY_LUT_ON_GPU`)),n.texcoordBuffer&&(e.push(`HAS_ATTRIBUTE_a_uv_2f`),t.push(n.texcoordBuffer)),n.colorBuffer&&(e.push(n.colorBuffer.itemSize===12?`HAS_ATTRIBUTE_a_color_3f`:`HAS_ATTRIBUTE_a_color_4f`),t.push(n.colorBuffer)),n.normalBuffer&&(e.push(`HAS_ATTRIBUTE_a_normal_4n`),t.push(n.normalBuffer)),a&&(e.push(`HAS_ATTRIBUTE_a_feature`),t.push(n.featureBuffer)),o.alphaMode!==`OPAQUE`&&o.alphaMode!==`MASK`||e.push(`UNPREMULT_TEXTURE_IN_SHADER`),o.defined||e.push(`DIFFUSE_SHADED`);let m=r.shadowRenderer;m&&(e.push(`RENDER_SHADOWS`),m.useNormalOffset&&e.push(`NORMAL_OFFSET`))}function gt(t,n,r,i,a,o){let c=t.modelOpacity,l=n.context,u=new D(n.context.gl.LEQUAL,t.isLightMesh?D.ReadOnly:D.ReadWrite,n.depthRangeFor3D),d=n.transform,f=t.mesh,p=f.material,m=p.pbrMetallicRoughness,h=n.style.fog;n.transform.projection.zAxisUnit===`pixels`?Z.set(t.nodeModelMatrix):e(Z,i.zScaleMatrix,t.nodeModelMatrix),e(Z,i.negCameraPosMatrix,Z),L(Q,Z),E(Q,Q);let g=r.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`,_=r.paint.get(`model-emissive-strength`).constantOr(0),v={defines:[]},y=[],b=n.shadowRenderer;b&&(b.useNormalOffset=!1),ht(v.defines,y,f,n,g?null:r.lut);let x=null;if(h&&(x=dt(tt,t.nodeModelMatrix,n.transform),d.projection.name!==`globe`)){let e=f.aabb.min,t=f.aabb.max,[n,r]=h.getOpacityForBounds(x,e[0],e[1],t[0],t[1]);v.overrideFog=n>=.05||r>=.05}let C=S(n,r.paint.get(`model-cutoff-fade-range`));C.shouldRenderCutoff&&v.defines.push(`RENDER_CUTOFF`);let w=n.getOrCreateProgram(`model`,v),T=Qe(t.worldViewProjection,Z,Q,null,n,c,m.baseColorFactor,p.emissiveFactor,m.metallicFactor,m.roughnessFactor,p,_,r,void 0,void 0,t.materialOverride,t.modelColor,1,w.fixedDefines.includes(`LIGHTING_3D_MODE`));n.uploadCommonUniforms(l,w,null,x,C,t.lightOverrides),n.renderPass!==`shadow`&&b&&b.setupShadowsFromMatrix(t.nodeModelMatrix,w),w.draw(n,l.gl.TRIANGLES,u,a,o,f.material.doubleSided?s.disabled:s.backCCW,T,r.id,f.vertexBuffer,f.indexBuffer,f.segments,r.paint,n.transform.zoom,void 0,y)}function _t(e,t){return e.style._importedAsBasemap?`basemap`:t.scope}function vt(t,n,r,i,a,o,s,c,l,u,d){let f=t.transform,p=!!n.isGeometryBloom&&n.isGeometryBloom;if(n.minZoom!==void 0&&t.transform.zoom<n.minZoom||n.maxZoom!==void 0&&t.transform.zoom>n.maxZoom||p&&t.renderPass===`shadow`)return;let m=f.projection.name===`globe`?Je(r,f):[...r];e(m,m,n.globalMatrix);let h=e([],i,m);if(n.meshes)for(let e of n.meshes){let t=c.get(e.material.name);if(t&&t.opacity<=0)continue;if(e.material.alphaMode!==`BLEND`){s.push({mesh:e,depth:0,modelIndex:a,worldViewProjection:h,nodeModelMatrix:m,isLightMesh:p,materialOverride:t,modelOpacity:l,modelColor:u,lightOverrides:d,node:n,modelMatrix:r});continue}let i=j([],e.centroid,h);!f.isOrthographic&&i[2]<=0||o.push({mesh:e,depth:i[2],modelIndex:a,worldViewProjection:h,nodeModelMatrix:m,isLightMesh:p,materialOverride:t,modelOpacity:l,modelColor:u,lightOverrides:d,node:n,modelMatrix:r})}if(n.children)for(let e of n.children)vt(t,e,r,i,a,o,s,c,l,u,d)}function yt(e,t,n,r,i){let a=n.shadowRenderer;if(!a)return;let o=a.getShadowPassDepthMode(),c=$e(i||a.calculateShadowPassMatrixFromMatrix(t));n.getOrCreateProgram(`modelDepth`).draw(n,n.context.gl.TRIANGLES,o,m.disabled,q.disabled,s.disabled,c,r.id,e.vertexBuffer,e.indexBuffer,e.segments,r.paint,n.transform.zoom,void 0,void 0)}function bt(e,t,n,r){let i=function(e,t){if(t.footprintDebugMesh)return t.footprintDebugMesh;if(!t.footprint)return null;let n=e.context,r=t.footprint.vertices,i=t.footprint.indices,a=new he;a.reserve(r.length);for(let e of r)a.emplaceBack(e.x,e.y);let o=new se;o.reserve(i.length);for(let e=0;e<i.length;e+=3)o.emplaceBack(i[e],i[e+1],i[e+2]);let s=n.createVertexBuffer(a,de.members),c=n.createIndexBuffer(o),l=Fe.simpleSegment(0,0,r.length,i.length),u=t.id||t.name||`footprint`,d,f=parseInt(u,10);d=isNaN(f)?function(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n)|0;return t}(u):f;let p=fe(d),m=fe(d+1),h=fe(d+2);return t.footprintDebugMesh={vertexBuffer:s,indexBuffer:c,segments:l,color:new K(p,m,h,.5)},t.footprintDebugMesh}(e,n);if(!i)return;let a=e.context,o=a.gl,c=e.getOrCreateProgram(`debug`),l=i.color,u=D.disabled;a.activeTexture.set(o.TEXTURE0),e.emptyTexture.bind(o.LINEAR,o.CLAMP_TO_EDGE),c.draw(e,o.TRIANGLES,u,m.disabled,q.alphaBlended,s.disabled,je(r,l.toPremultipliedRenderColor(null)),`$debug`,i.vertexBuffer,i.indexBuffer,i.segments)}function xt(e,t,n,r,i,a){for(let o of i){let i={...r};i.part=o;let s={type:`Unknown`,id:t,properties:i},c={orientation:e.paint.get(`model-rotation`).evaluate(s,n)};a.set(o,c)}}function St(e,t,n,r,i,a){for(let o of i){let i={...r};i.part=o;let s={type:`Unknown`,id:t,properties:i},c={color:e.paint.get(`model-color`).evaluate(s,n),colorMix:e.paint.get(`model-color-mix-intensity`).evaluate(s,n),opacity:e.paint.get(`model-opacity`).evaluate(s,n),emissionStrength:e.paint.get(`model-emissive-strength`).evaluate(s,n)};a.set(o,c)}}function Ct(e,t,n,r,i){let a=!1;for(let n of r)n.modelOpacity!==1&&(gt(n,e,t,i[n.modelIndex],m.disabled,q.disabled),a=!0);for(let n of r)gt(n,e,t,i[n.modelIndex],n.modelOpacity===1?m.disabled:e.stencilModeFor3D(),e.colorModeForRenderPass());a&&e.resetStencilClippingMasks();let o=q.additive;for(let r of n)gt(r,e,t,i[r.modelIndex],m.disabled,r.isLightMesh?o:e.colorModeForRenderPass())}function wt(e,t,n){let r=t.updateZoomBasedPaintProperties(),i=function(e,t,n){let r,i,a,o=e.terrain?e.terrain.exaggeration():0;if(e.terrain&&o>0){let t=e.terrain,i=t.findDEMTileFor(n);i&&i.dem?r=Pe.create(t,n,i):o=0}if(o===0&&(t.terrainElevationMin=0,t.terrainElevationMax=0),o===t.validForExaggeration&&(o===0||r&&r._demTile&&r._demTile.tileID===t.validForDEMTile.id&&r._dem._timestamp===t.validForDEMTile.timestamp))return!1;for(let e in t.instancesPerModel){let n=t.instancesPerModel[e];for(let e=0;e<n.instancedDataArray.length;++e){let s=(r?o*r.getElevationAt(0|n.instancedDataArray.float32[16*e],0|n.instancedDataArray.float32[16*e+1],!0,!0):0)+n.instancesEvaluatedElevation[e];n.instancedDataArray.float32[16*e+6]=s,i=i?Math.min(t.terrainElevationMin,s):s,a=a?Math.max(t.terrainElevationMax,s):s}}return t.terrainElevationMin=i||0,t.terrainElevationMax=a||0,t.validForExaggeration=o,t.validForDEMTile=r&&r._demTile?{id:r._demTile.tileID,timestamp:r._dem._timestamp}:{id:void 0,timestamp:0},!0}(e,t,n);(r||i)&&(t.uploaded=!1,t.upload(e.context))}var $={shadowUniformsInitialized:!1,useSingleShadowCascade:!1,tileMatrix:new Float64Array(16),shadowTileMatrix:new Float32Array(16),aabb:new o([0,0,0],[f,f,0])};function Tt(e,t){let n=1<<e.canonical.z,r=t.getFreeCameraOptions().position,i=t.elevation,a=e.canonical.x/n,o=(e.canonical.x+1)/n,s=e.canonical.y/n,c=(e.canonical.y+1)/n,l=t._centerAltitude;if(i){let t=i.getMinMaxForTile(e);t&&t.max>l&&(l=t.max)}let u=Y(r.x,a,o)-r.x,d=Y(r.y,s,c)-r.y,f=ce(l,t.center.lat)-r.z;return t._zoomFromMercatorZ(Math.sqrt(u*u+d*d+f*f))}function Et(e,t,n,r,i,a,o){let c=e.context,l=e.renderPass===`shadow`,u=e.shadowRenderer,d=l&&u?u.getShadowPassDepthMode():new D(c.gl.LEQUAL,D.ReadWrite,e.depthRangeFor3D),f=e.isTileAffectedByFog(a),p=e.transform.projection.name===`globe`;if(n.meshes)for(let h of n.meshes){let g=p?[]:[`MODEL_POSITION_ON_GPU`],_=[],v,y,b,x=!p&&r.instancedDataArray.length>20;x&&g.push(`INSTANCED_ARRAYS`);let C=S(e,t.paint.get(`model-cutoff-fade-range`));if(C.shouldRenderCutoff&&g.push(`RENDER_CUTOFF`),l&&u)v=e.getOrCreateProgram(`modelDepth`,{defines:g}),y=$e(o.shadowTileMatrix,o.shadowTileMatrix,n.globalMatrix),b=q.disabled;else{ht(g,_,h,e,t.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`?null:t.lut),v=e.getOrCreateProgram(`model`,{defines:g,overrideFog:f});let r=h.material,s=r.pbrMetallicRoughness,l=t.paint.get(`model-opacity`).constantOr(1),d=t.paint.get(`model-emissive-strength`).constantOr(0);y=Qe(a.expandedProjMatrix,n.globalMatrix,st,null,e,l,s.baseColorFactor,r.emissiveFactor,s.metallicFactor,s.roughnessFactor,r,d,t,i,void 0,void 0,void 0,1,v.fixedDefines.includes(`LIGHTING_3D_MODE`)),u&&(o.shadowUniformsInitialized?v.setShadowUniformValues(c,u.getShadowUniformValues()):(u.setupShadows(a.toUnwrapped(),v,`model-tile`),o.shadowUniformsInitialized=!0)),b=C.shouldRenderCutoff||l<1||r.alphaMode!==`OPAQUE`?q.alphaBlended:q.unblended}e.uploadCommonUniforms(c,v,a.toUnwrapped(),null,C);let w=h.material.doubleSided?s.disabled:s.backCCW;if(x)_.push(r.instancedDataBuffer),v.draw(e,c.gl.TRIANGLES,d,m.disabled,b,w,y,t.id,h.vertexBuffer,h.indexBuffer,h.segments,t.paint,e.transform.zoom,void 0,_,r.instancedDataArray.length);else{let n=l?`u_instance`:`u_normal_matrix`;for(let i=0;i<r.instancedDataArray.length;++i)y[n]=new Float32Array(r.instancedDataArray.arrayBuffer,64*i,16),v.draw(e,c.gl.TRIANGLES,d,m.disabled,b,w,y,t.id,h.vertexBuffer,h.indexBuffer,h.segments,t.paint,e.transform.zoom,void 0,_)}}if(n.children)for(let s of n.children)Et(e,t,s,r,i,a,o)}function Dt(e,t,n,r,i){let a=e.node;if(a.lodMeshes&&a.lodMeshes.length>0){if(e.targetLod<0)e.targetLod=+(t>r);else{let a=i>0?n/1e3/i:1;e.targetLod=Y(t>r?e.targetLod+a:e.targetLod-a,0,1)}}else e.targetLod=0}function Ot(e,t,n,r){if(!n.modelManager)return!0;let i=n.modelManager;if(!n.shadowRenderer)return!0;let a=n.shadowRenderer,o=t.aabb,s=!0,c=e.maxHeight;if(c===0){let t=0;for(let n in e.instancesPerModel){let e=i.getModel(n,r);e?t=Math.max(t,Math.max(Math.max(e.aabb.max[0],e.aabb.max[1]),e.aabb.max[2])):s=!1}c=e.maxScale*t*1.41+e.maxVerticalOffset,s&&(e.maxHeight=c)}o.max[2]=c,o.min[2]+=e.terrainElevationMin,o.max[2]+=e.terrainElevationMax,j(o.min,o.min,t.tileMatrix),j(o.max,o.max,t.tileMatrix);let l=o.intersects(a.getCurrentCascadeFrustum());return n.currentShadowCascade===0&&(e.isInsideFirstShadowMapFrustum=l===2),l===0}function kt(e,t){let n=e.uniformValues.u_cutoff_params[0],r=e.uniformValues.u_cutoff_params[1],i=e.uniformValues.u_cutoff_params[2],a=e.uniformValues.u_cutoff_params[3];return r===n||a===i?1:Y(((t-n)/(r-n)-i)/(a-i),0,1)}function At(t,n,r,i){if(n.pitch<20)return 1;let a=n.getWorldToCameraMatrix();e(a,a,t);let o=M(r.min[0],r.min[1],r.min[2],1),s=De(G(),o,a),c=s,l=s;o[1]=r.max[1],s=De(G(),o,a),c=s[1]<c[1]?s:c,l=s[1]>l[1]?s:l,o[0]=r.max[0],s=De(G(),o,a),c=s[1]<c[1]?s:c,l=s[1]>l[1]?s:l,o[1]=r.min[1],s=De(G(),o,a),c=s[1]<c[1]?s:c,l=s[1]>l[1]?s:l;let u=Y(i[0],0,1),d=100*n.pixelsPerMeter*Y(i[1],0,1),f=Y(i[2],0,1),p=Ae(G(),c,l,u),m=Math.tan(.5*n.fovX),h=-p[2]*m;if(d===0)return p[1]<-Math.abs(h)?f:1;let g=(-Math.abs(h)-p[1])/d,_=Y(ke(1,f,g),f,1);return ke(1,_,Y((n.pitch-20)/20,0,1))}var jt={model:U(`#include "_prelude_fog.fragment.glsl"
#include "_prelude_shadow.fragment.glsl"
#include "_prelude_lighting.glsl"
#include "_prelude_indicator_cutout.fragment.glsl"
#include "_prelude_feature_cutout.fragment.glsl"
uniform float u_opacity;
#ifdef DITHERED_DISCARD
uniform float u_dithered_discard_threshold;
#endif
#ifndef LIGHTING_3D_MODE
uniform vec3 u_lightcolor;uniform vec3 u_lightpos;uniform float u_lightintensity;
#endif
uniform vec4 u_baseColorFactor;uniform vec4 u_emissiveFactor;uniform float u_metallicFactor;uniform float u_roughnessFactor;uniform float u_emissive_strength;in highp vec4 v_position_height;in lowp vec4 v_color_mix;
#ifdef RENDER_SHADOWS
in highp vec4 v_pos_light_view_0;in highp vec4 v_pos_light_view_1;in float v_depth_shadows;
#endif
#ifdef OCCLUSION_TEXTURE_TRANSFORM
uniform vec4 u_occlusionTextureTransform;
#endif
#pragma mapbox: define-attribute highp vec4 normal_4n
#pragma mapbox: define-attribute highp vec3 color_3f
#pragma mapbox: define-attribute highp vec4 color_4f
#pragma mapbox: define-attribute highp vec2 uv_2f
#pragma mapbox: initialize-attribute highp vec4 normal_4n
#pragma mapbox: initialize-attribute highp vec3 color_3f
#pragma mapbox: initialize-attribute highp vec4 color_4f
#pragma mapbox: initialize-attribute highp vec2 uv_2f
#ifdef HAS_ATTRIBUTE_a_feature
in lowp vec4 v_roughness_metallic_emissive_alpha;in mediump vec4 v_height_based_emission_params;
#endif
#ifdef HAS_TEXTURE_u_baseColorTexture
uniform sampler2D u_baseColorTexture;uniform bool u_baseTextureIsAlpha;uniform bool u_alphaMask;uniform float u_alphaCutoff;
#endif
#ifdef HAS_TEXTURE_u_metallicRoughnessTexture
uniform sampler2D u_metallicRoughnessTexture;
#endif
#ifdef HAS_TEXTURE_u_occlusionTexture
uniform sampler2D u_occlusionTexture;uniform float u_aoIntensity;
#endif
#ifdef HAS_TEXTURE_u_normalTexture
uniform sampler2D u_normalTexture;
#endif
#ifdef HAS_TEXTURE_u_emissionTexture
uniform sampler2D u_emissionTexture;
#endif
#ifdef APPLY_LUT_ON_GPU
uniform highp sampler3D u_lutTexture;
#endif
#define saturate(_x) clamp(_x,0.,1.)
vec3 linearTosRGB(vec3 color) {return pow(color,vec3(1./2.2));}vec3 sRGBToLinear(vec3 srgbIn) {return pow(srgbIn,vec3(2.2));}float calculate_NdotL(vec3 normal,vec3 lightDir) {const float ext=0.70710678118;return (clamp(dot(normal,lightDir),-ext,1.0)+ext)/(1.0+ext);}vec3 getDiffuseShadedColor(vec3 albedo,vec3 normal,vec3 lightDir,vec3 lightColor)
{
#ifdef LIGHTING_3D_MODE
vec3 transformed_normal=vec3(-normal.xy,normal.z);float lighting_factor;
#ifdef RENDER_SHADOWS
lighting_factor=shadowed_light_factor_normal(transformed_normal,v_pos_light_view_0,v_pos_light_view_1,v_depth_shadows);
#else
lighting_factor=saturate(dot(transformed_normal,u_lighting_directional_dir));
#endif
return apply_lighting(albedo,transformed_normal,lighting_factor);
#else
vec3 n=normal;float colorvalue=((albedo.x*0.2126)+(albedo.y*0.7152))+(albedo.z*0.0722);vec3 c=vec3(0.03,0.03,0.03);float directional=clamp(dot(n,vec3(lightDir)),0.0,1.0);directional=mix(1.0-u_lightintensity,max((1.0-colorvalue)+u_lightintensity,1.0),directional);vec3 c3=c+clamp((albedo*directional)*lightColor,mix(vec3(0.0),vec3(0.3),vec3(1.0)-lightColor),vec3(1.0));return c3;
#endif
}vec4 getBaseColor() {vec4 albedo=u_baseColorFactor;
#ifdef HAS_ATTRIBUTE_a_color_3f
albedo*=vec4(color_3f,1.0);
#endif
#ifdef HAS_ATTRIBUTE_a_feature
#else
#ifdef HAS_ATTRIBUTE_a_color_4f
albedo*=color_4f;
#endif
#endif
#if defined (HAS_TEXTURE_u_baseColorTexture) && defined (HAS_ATTRIBUTE_a_uv_2f)
vec4 texColor=texture(u_baseColorTexture,uv_2f);if(u_alphaMask) {if (texColor.w < u_alphaCutoff) {discard;}}
#ifdef UNPREMULT_TEXTURE_IN_SHADER
texColor=vec4(unpremultiplyColor(texColor),1.0);
#endif
if(u_baseTextureIsAlpha) {if (texColor.r < 0.5) {discard;}} else {texColor.rgb=sRGBToLinear(texColor.rgb);albedo*=texColor;}
#endif
vec4 color=vec4(mix(albedo.rgb,v_color_mix.rgb,v_color_mix.a),albedo.a);
#ifdef APPLY_LUT_ON_GPU
color=applyLUT(u_lutTexture,color);
#endif
return color;}highp mat3 cotangentFrame(highp vec3 N,highp vec3 p,highp vec2 uv ) {
#ifdef HAS_TEXTURE_u_normalTexture
highp vec3 dp1=vec3(dFdx(p.x),dFdx(p.y),dFdx(p.z));highp vec3 dp2=vec3(dFdy(p.x),dFdy(p.y),dFdy(p.z));highp vec2 duv1=vec2(dFdx(uv.x),dFdx(uv.y));highp vec2 duv2=vec2(dFdy(uv.x),dFdy(uv.y));highp vec3 dp2perp=cross( dp2,N );highp vec3 dp1perp=cross( N,dp1 );highp vec3 T=dp2perp*duv1.x+dp1perp*duv2.x;highp vec3 B=dp2perp*duv1.y+dp1perp*duv2.y;highp float lengthT=dot(T,T);highp float lengthB=dot(B,B);highp float maxLength=max(lengthT,lengthB);highp float invmax=inversesqrt( maxLength );highp mat3 res=mat3( T*invmax,B*invmax,N );return res;
#else
return mat3(1.0);
#endif
}highp vec3 getNormal(){highp vec3 n;
#ifdef HAS_ATTRIBUTE_a_normal_4n
n=normalize(normal_4n.xyz);
#else
highp vec3 fdx=vec3(dFdx(v_position_height.x),dFdx(v_position_height.y),dFdx(v_position_height.z));highp vec3 fdy=vec3(dFdy(v_position_height.x),dFdy(v_position_height.y),dFdy(v_position_height.z));n=normalize(cross(fdx,fdy))*-1.0;
#endif
#if defined(HAS_TEXTURE_u_normalTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
vec3 nMap=texture( u_normalTexture,uv_2f).xyz;nMap=normalize(2.0*nMap-vec3(1.0));highp vec3 v=normalize(-v_position_height.xyz);highp mat3 TBN=cotangentFrame(n,v,uv_2f);n=normalize(TBN*nMap);
#endif
return n;}struct Material {float perceptualRoughness;float alphaRoughness;float metallic;vec3 f90;vec4 baseColor;vec3 diffuseColor;vec3 specularColor;highp vec3 normal;};Material getPBRMaterial() {Material mat;mat.baseColor=getBaseColor();mat.perceptualRoughness=u_roughnessFactor;mat.metallic=u_metallicFactor;
#ifdef HAS_ATTRIBUTE_a_feature
mat.perceptualRoughness=v_roughness_metallic_emissive_alpha.x;mat.metallic=v_roughness_metallic_emissive_alpha.y;mat.baseColor.w*=v_roughness_metallic_emissive_alpha.w;
#endif
#if defined(HAS_TEXTURE_u_metallicRoughnessTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
vec4 mrSample=texture(u_metallicRoughnessTexture,uv_2f);mat.perceptualRoughness*=mrSample.g;mat.metallic*=mrSample.b;
#endif
const float c_minRoughness=0.04;mat.perceptualRoughness=clamp(mat.perceptualRoughness,c_minRoughness,1.0);mat.metallic=saturate(mat.metallic);mat.alphaRoughness=mat.perceptualRoughness*mat.perceptualRoughness;const vec3 f0=vec3(0.04);mat.diffuseColor=mat.baseColor.rgb*(vec3(1.0)-f0);mat.diffuseColor*=1.0-mat.metallic;mat.specularColor=mix(f0,mat.baseColor.rgb,mat.metallic);highp float reflectance=max(max(mat.specularColor.r,mat.specularColor.g),mat.specularColor.b);highp float reflectance90=saturate(reflectance*25.0);mat.f90=vec3(reflectance90);mat.normal=getNormal();return mat;}float V_GGX(float NdotL,float NdotV,float roughness)
{float a2=roughness*roughness;float GGXV=NdotL*sqrt(NdotV*NdotV*(1.0-a2)+a2);float GGXL=NdotV*sqrt(NdotL*NdotL*(1.0-a2)+a2);return 0.5/(GGXV+GGXL);}float V_GGXFast(float NdotL,float NdotV,float roughness) {float a=roughness;float GGXV=NdotL*(NdotV*(1.0-a)+a);float GGXL=NdotV*(NdotL*(1.0-a)+a);return 0.5/(GGXV+GGXL);}vec3 F_Schlick(vec3 specularColor,vec3 f90,float VdotH)
{return specularColor+(f90-specularColor)*pow(clamp(1.0-VdotH,0.0,1.0),5.0);}vec3 F_SchlickFast(vec3 specularColor,float VdotH)
{float x=1.0-VdotH;float x4=x*x*x*x;return specularColor+(1.0-specularColor)*x4*x;}float D_GGX(highp float NdotH,float alphaRoughness)
{highp float a4=alphaRoughness*alphaRoughness;highp float f=(NdotH*a4-NdotH)*NdotH+1.0;return a4/(PI*f*f);}vec3 diffuseBurley(Material mat,float LdotH,float NdotL,float NdotV)
{float f90=2.0*LdotH*LdotH*mat.alphaRoughness-0.5;return (mat.diffuseColor/PI)*(1.0+f90*pow((1.0-NdotL),5.0))*(1.0+f90*pow((1.0-NdotV),5.0));}vec3 diffuseLambertian(Material mat)
{
#ifdef LIGHTING_3D_MODE
return mat.diffuseColor;
#else
return mat.diffuseColor/PI;
#endif
}vec3 EnvBRDFApprox(vec3 specularColor,float roughness,highp float NdotV)
{vec4 c0=vec4(-1,-0.0275,-0.572,0.022);vec4 c1=vec4(1,0.0425,1.04,-0.04);highp vec4 r=roughness*c0+c1;highp float a004=min(r.x*r.x,exp2(-9.28*NdotV))*r.x+r.y;vec2 AB=vec2(-1.04,1.04)*a004+r.zw;return specularColor*AB.x+AB.y;}vec3 computeIndirectLightContribution(Material mat,float NdotV,vec3 normal)
{vec3 env_light=vec3(0.65,0.65,0.65);
#ifdef LIGHTING_3D_MODE
float ambient_factor=calculate_ambient_directional_factor(normal);env_light=u_lighting_ambient_color*ambient_factor;
#endif
vec3 envBRDF=EnvBRDFApprox(mat.specularColor,mat.perceptualRoughness,NdotV);vec3 indirectSpecular= envBRDF*env_light;vec3 indirectDiffuse=mat.diffuseColor*env_light;return indirectSpecular+indirectDiffuse;}vec3 computeLightContribution(Material mat,vec3 lightPosition,vec3 lightColor)
{highp vec3 n=mat.normal;highp vec3 v=normalize(-v_position_height.xyz);highp vec3 l=normalize(lightPosition);highp vec3 h=normalize(v+l);float NdotV=clamp(abs(dot(n,v)),0.001,1.0);float NdotL=saturate(dot(n,l));highp float NdotH=saturate(dot(n,h));float VdotH=saturate(dot(v,h));vec3 f=F_SchlickFast(mat.specularColor,VdotH);float g=V_GGXFast(NdotL,NdotV,mat.alphaRoughness);float d=D_GGX(NdotH,mat.alphaRoughness);vec3 diffuseTerm=(1.0-f)*diffuseLambertian(mat);vec3 specularTerm=f*g*d;vec3 transformed_normal=vec3(-n.xy,n.z);float lighting_factor;
#ifdef RENDER_SHADOWS
lighting_factor=shadowed_light_factor_normal(transformed_normal,v_pos_light_view_0,v_pos_light_view_1,v_depth_shadows);
#else
lighting_factor=NdotL;
#endif
vec3 directLightColor=(specularTerm+diffuseTerm)*lighting_factor*lightColor;vec3 indirectLightColor=computeIndirectLightContribution(mat,NdotV,transformed_normal);vec3 color=(saturate(directLightColor)+indirectLightColor);float intensityFactor=1.0;
#if !defined(LIGHTING_3D_MODE)
const vec3 luminosityFactor=vec3(0.2126,0.7152,0.0722);float luminance=dot(diffuseTerm,luminosityFactor);intensityFactor=mix((1.0-u_lightintensity),max((1.0-luminance+u_lightintensity),1.0),NdotL);
#endif
color*=intensityFactor;return color;}void main() {vec3 lightDir;vec3 lightColor;
#ifdef LIGHTING_3D_MODE
lightDir=u_lighting_directional_dir;lightDir.xy=-lightDir.xy;lightColor=u_lighting_directional_color;
#else
lightDir=u_lightpos;lightColor=u_lightcolor;
#endif
vec4 finalColor;
#ifdef DIFFUSE_SHADED
vec3 N=getNormal();vec3 baseColor=getBaseColor().rgb;vec3 diffuse=getDiffuseShadedColor(baseColor,N,lightDir,lightColor);
#ifdef HAS_TEXTURE_u_occlusionTexture
float ao=(texture(u_occlusionTexture,uv_2f).r-1.0)*u_aoIntensity+1.0;diffuse*=ao;
#endif
finalColor=vec4(mix(diffuse,baseColor,u_emissive_strength),1.0)*u_opacity;
#else
Material mat=getPBRMaterial();vec3 color=computeLightContribution(mat,lightDir,lightColor);float ao=1.0;
#if defined (HAS_TEXTURE_u_occlusionTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
#ifdef OCCLUSION_TEXTURE_TRANSFORM
vec2 uv=uv_2f.xy*u_occlusionTextureTransform.zw+u_occlusionTextureTransform.xy;
#else
vec2 uv=uv_2f;
#endif
ao=(texture(u_occlusionTexture,uv).x-1.0)*u_aoIntensity+1.0;color*=ao;
#endif
vec4 emissive=u_emissiveFactor;
#if defined(HAS_TEXTURE_u_emissionTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
emissive.rgb*=sRGBToLinear(texture(u_emissionTexture,uv_2f).rgb);
#endif
#ifdef APPLY_LUT_ON_GPU
float emissiveFactorLength=max(length(u_emissiveFactor.rgb),0.001);emissive.rgb=sRGBToLinear(applyLUT(u_lutTexture,linearTosRGB(emissive.rgb/emissiveFactorLength).rbg))*emissiveFactorLength;
#endif
color+=emissive.rgb;float opacity=mat.baseColor.w*u_opacity;
#ifdef HAS_ATTRIBUTE_a_feature
float resEmission=v_roughness_metallic_emissive_alpha.z;resEmission*=v_height_based_emission_params.z+v_height_based_emission_params.w*pow(clamp(v_height_based_emission_params.x,0.0,1.0),v_height_based_emission_params.y);vec3 color_mix=v_color_mix.rgb;
#ifdef APPLY_LUT_ON_GPU
color_mix=applyLUT(u_lutTexture,color_mix);
#endif
color=mix(color,color_mix,min(1.0,resEmission));
#ifdef HAS_ATTRIBUTE_a_color_4f
float distance=length(vec2(1.3*max(0.0,abs(color_4f.x)-color_4f.z),color_4f.y));distance+= mix(0.5,0.0,clamp(resEmission-1.0,0.0,1.0));opacity*=v_roughness_metallic_emissive_alpha.w*saturate(1.0-distance*distance);
#endif
#endif
vec3 unlitColor=mat.baseColor.rgb*ao+emissive.rgb;color=mix(color,unlitColor,u_emissive_strength);color=linearTosRGB(color);color*=opacity;finalColor=vec4(color,opacity);
#endif
#ifdef DITHERED_DISCARD
if (abs(u_dithered_discard_threshold) < 1.0) {float ditherValue=fract(52.9829189*fract(0.06711056*gl_FragCoord.x+0.00583715*gl_FragCoord.y));float compareValue=mix(1.0-ditherValue,ditherValue,step(0.0,u_dithered_discard_threshold));if (abs(u_dithered_discard_threshold) < compareValue) {discard;}}
#endif
#ifdef FOG
finalColor=fog_dither(fog_apply_premultiplied(finalColor,v_fog_pos,v_position_height.w));
#endif
#ifdef RENDER_CUTOFF
finalColor*=v_cutoff_opacity;
#endif
glFragColor=finalColor;
#ifdef OVERDRAW_INSPECTOR
glFragColor=vec4(1.0);
#endif
HANDLE_WIREFRAME_DEBUG;}`,`#include "_prelude_fog.vertex.glsl"
#include "_prelude_shadow.vertex.glsl"
#include "_prelude_feature_cutout.vertex.glsl"
in vec3 a_pos_3f;
#pragma mapbox: define-attribute highp vec4 normal_4n
#pragma mapbox: define-attribute highp vec2 uv_2f
#pragma mapbox: define-attribute highp vec3 color_3f
#pragma mapbox: define-attribute highp vec4 color_4f
#pragma mapbox: define-attribute-vertex-shader-only highp uvec2 feature
#define MODEL_PART_COUNT 7u
#define MODEL_PART_STYLE_SIZE_VEC4 28u
#ifdef HAS_ATTRIBUTE_a_feature
struct ModelPartStyle {vec4 color_mix;vec4 rmea;vec4 gradient;float gradient_power;};layout(std140) uniform ModelPartStyleUniform {vec4 part_style[MODEL_PART_STYLE_SIZE_VEC4];} u_model_part_style;uniform vec4 u_model_mesh_params;
#endif
uniform mat4 u_matrix;uniform mat4 u_node_matrix;uniform mat4 u_lighting_matrix;uniform vec3 u_camera_pos;uniform vec4 u_color_mix;
#ifdef INSTANCED_ARRAYS
in vec4 a_normal_matrix0;in vec4 a_normal_matrix1;in vec4 a_normal_matrix2;in vec4 a_normal_matrix3;
#else
uniform highp mat4 u_normal_matrix;
#endif
#ifdef RENDER_SHADOWS
uniform mat4 u_light_matrix_0;uniform mat4 u_light_matrix_1;out highp vec4 v_pos_light_view_0;out highp vec4 v_pos_light_view_1;out float v_depth_shadows;
#endif
out vec4 v_position_height;out lowp vec4 v_color_mix;
#ifdef HAS_ATTRIBUTE_a_feature
out lowp vec4 v_roughness_metallic_emissive_alpha;out mediump vec4 v_height_based_emission_params;
#endif
vec3 sRGBToLinear(vec3 srgbIn) {return pow(srgbIn,vec3(2.2));}
#ifdef HAS_ATTRIBUTE_a_feature
uint decodeModelPartId(uvec2 feature) {uint partId=feature.y & 0xFu;return partId < MODEL_PART_COUNT ? partId : 0u;}vec4 decodeModelVertexColor(uvec2 feature) {uvec4 nibbles=uvec4(feature.x >> 12u,feature.x >> 8u,feature.x >> 4u,feature.x) & 0xFu;return vec4(nibbles*17u)/255.0;}ModelPartStyle readModelPartStyle(uint partId) {uint base=partId*4u;ModelPartStyle style;style.color_mix=u_model_part_style.part_style[base];style.rmea=u_model_part_style.part_style[base+1u];style.gradient=u_model_part_style.part_style[base+2u];style.gradient_power=u_model_part_style.part_style[base+3u].x;return style;}vec3 modelAlbedo(ModelPartStyle style,vec4 vertexColor) {float ambientOcclusion=mix(1.0,vertexColor.a,u_model_mesh_params.z);return ambientOcclusion*mix(vertexColor.rgb,style.color_mix.rgb,style.color_mix.a);}vec4 resolveModelEmissiveGradient(ModelPartStyle style,float height) {float begin=u_model_mesh_params.x+u_model_mesh_params.y*style.gradient.x;float span=u_model_mesh_params.y*(style.gradient.y-style.gradient.x);return vec4((height-begin)/span,style.gradient_power,style.gradient.z,style.gradient.w);}
#endif
void main() {
#pragma mapbox: initialize-attribute highp vec4 normal_4n
#pragma mapbox: initialize-attribute highp vec2 uv_2f
#pragma mapbox: initialize-attribute highp vec3 color_3f
#pragma mapbox: initialize-attribute highp vec4 color_4f
#pragma mapbox: initialize-attribute-custom highp uvec2 feature
highp mat4 normal_matrix;
#ifdef INSTANCED_ARRAYS
normal_matrix=mat4(a_normal_matrix0,a_normal_matrix1,a_normal_matrix2,a_normal_matrix3);
#else
normal_matrix=u_normal_matrix;
#endif
vec3 local_pos;mat3 rs;
#ifdef MODEL_POSITION_ON_GPU
vec3 pos_color=normal_matrix[0].xyz;vec4 translate=normal_matrix[1];vec3 pos_a=floor(pos_color);vec3 rgb=1.05*(pos_color-pos_a);float hidden=float(pos_a.x > EXTENT);float color_mix=pos_a.z/100.0;v_color_mix=vec4(sRGBToLinear(rgb),color_mix);float meter_to_tile=normal_matrix[0].w;vec4 pos=vec4(pos_a.xy,translate.z,1.0);rs[0].x=normal_matrix[1].w;rs[0].yz=normal_matrix[2].xy;rs[1].xy=normal_matrix[2].zw;rs[1].z=normal_matrix[3].x;rs[2].xyz=normal_matrix[3].yzw;vec4 pos_node=u_lighting_matrix*vec4(a_pos_3f,1.0);vec3 rotated_pos_node=rs*pos_node.xyz;vec3 pos_model_tile=(rotated_pos_node+vec3(translate.xy,0.0))*vec3(meter_to_tile,meter_to_tile,1.0);pos.xyz+=pos_model_tile;local_pos=pos.xyz;gl_Position=mix(u_matrix*pos,AWAY,hidden);pos.z*=meter_to_tile;v_position_height.xyz=pos.xyz-u_camera_pos;
#else
local_pos=a_pos_3f;gl_Position=u_matrix*vec4(a_pos_3f,1);v_position_height.xyz=vec3(u_lighting_matrix*vec4(a_pos_3f,1));v_color_mix=vec4(sRGBToLinear(u_color_mix.rgb),u_color_mix.a);
#endif
v_position_height.w=a_pos_3f.z;
#ifdef HAS_ATTRIBUTE_a_feature
ModelPartStyle part_style=readModelPartStyle(decodeModelPartId(feature));v_color_mix=vec4(modelAlbedo(part_style,decodeModelVertexColor(feature)),1.0);v_roughness_metallic_emissive_alpha=part_style.rmea;v_height_based_emission_params=resolveModelEmissiveGradient(part_style,a_pos_3f.z);
#endif
#ifdef FOG
v_fog_pos=fog_position(local_pos);
#endif
#ifdef RENDER_CUTOFF
v_cutoff_opacity=cutoff_opacity(u_cutoff_params,gl_Position.z);
#endif
#ifdef HAS_ATTRIBUTE_a_normal_4n
#ifdef MODEL_POSITION_ON_GPU
float x_squared_scale=dot(rs[0],rs[0]);float y_squared_scale=dot(rs[1],rs[1]);float z_squared_scale=dot(rs[2],rs[2]);vec3 squared_scale=vec3(x_squared_scale,y_squared_scale,z_squared_scale);normal_4n=vec4(rs*((u_lighting_matrix*vec4(normal_4n.xyz,0.0)).xyz/squared_scale),0.0);normal_4n=normalize(normal_4n);
#else
normal_4n=vec4((normal_matrix*vec4(normal_4n.xyz,0)).xyz,0.0);
#endif
#endif
#ifdef HAS_ATTRIBUTE_a_feature
#ifdef HAS_ATTRIBUTE_a_color_4f
v_roughness_metallic_emissive_alpha.w=clamp(color_4f.a*v_roughness_metallic_emissive_alpha.w*(v_roughness_metallic_emissive_alpha.z-1.0),0.0,1.0);
#endif
#endif
#ifdef RENDER_SHADOWS
vec4 shadow_pos=u_node_matrix*vec4(local_pos,1.0);
#ifdef NORMAL_OFFSET
#ifdef HAS_ATTRIBUTE_a_normal_4n
#ifdef MODEL_POSITION_ON_GPU
vec3 offset=shadow_normal_offset(vec3(-normal_4n.xy,normal_4n.z));shadow_pos.xyz+=offset*shadow_normal_offset_multiplier0();
#else
vec3 offset=shadow_normal_offset_model(normal_4n.xyz);shadow_pos.xyz+=offset*shadow_normal_offset_multiplier0();
#endif
#endif
#endif
v_pos_light_view_0=u_light_matrix_0*shadow_pos;v_pos_light_view_1=u_light_matrix_1*shadow_pos;v_depth_shadows=gl_Position.w;
#endif
}`),modelDepth:U(`void main() {}`,`in vec3 a_pos_3f;uniform mat4 u_matrix;
#ifdef MODEL_POSITION_ON_GPU
#ifdef INSTANCED_ARRAYS
in vec4 a_normal_matrix0;in vec4 a_normal_matrix1;in vec4 a_normal_matrix2;in vec4 a_normal_matrix3;
#else
uniform highp mat4 u_instance;
#endif
uniform highp mat4 u_node_matrix;
#endif
void main() {
#ifdef MODEL_POSITION_ON_GPU
highp mat4 instance;
#ifdef INSTANCED_ARRAYS
instance=mat4(a_normal_matrix0,a_normal_matrix1,a_normal_matrix2,a_normal_matrix3);
#else
instance=u_instance;
#endif
vec3 pos_color=instance[0].xyz;vec4 translate=instance[1];vec3 pos_a=floor(pos_color);float hidden=float(pos_a.x > EXTENT);float meter_to_tile=instance[0].w;vec4 pos=vec4(pos_a.xy,translate.z,1.0);mat3 rs;rs[0].x=instance[1].w;rs[0].yz=instance[2].xy;rs[1].xy=instance[2].zw;rs[1].z=instance[3].x;rs[2].xyz=instance[3].yzw;vec4 pos_node=u_node_matrix*vec4(a_pos_3f,1.0);vec3 rotated_pos_node=rs*pos_node.xyz;vec3 pos_model_tile=(rotated_pos_node+vec3(translate.xy,0.0))*vec3(meter_to_tile,meter_to_tile,1.0);pos.xyz+=pos_model_tile;gl_Position=mix(u_matrix*pos,AWAY,hidden);
#else
gl_Position=u_matrix*vec4(a_pos_3f,1);
#endif
}`),fillExtrusionDepth:U(`void main() {}`,`#include "_prelude_terrain.vertex.glsl"
#include "_prelude_material_table.vertex.glsl"
uniform mat4 u_matrix;uniform float u_edge_radius;uniform float u_width_scale;uniform float u_vertical_scale;
#ifdef TERRAIN
uniform int u_height_type;uniform int u_base_type;
#endif
in ivec4 a_pos_normal_ed;
#if defined(HAS_CENTROID) || defined(TERRAIN)
in uvec2 a_centroid_pos;
#endif
#ifdef RENDER_WALL_MODE
in ivec4 a_join_normal_inside;
#endif
#pragma mapbox: define highp float base
#pragma mapbox: define highp float height
#pragma mapbox: define highp float line_width
#pragma mapbox: define highp vec4 color
void main() {DECLARE_MATERIAL_TABLE_INFO
#pragma mapbox: initialize highp float base
#pragma mapbox: initialize highp float height
#pragma mapbox: initialize highp float line_width
#pragma mapbox: initialize highp vec4 color
base*=u_vertical_scale;height*=u_vertical_scale;vec3 top_up_ny=vec3(a_pos_normal_ed.xyz & 1);vec3 pos_nx=vec3(a_pos_normal_ed.xyz >> 1);base=max(0.0,base);height=max(0.0,top_up_ny.y==0.0 && top_up_ny.x==1.0 ? height-u_edge_radius : height);float t=top_up_ny.x;vec2 centroid_pos=vec2(0.0);
#if defined(HAS_CENTROID) || defined(TERRAIN)
centroid_pos=vec2(a_centroid_pos);
#endif
vec3 pos;
#ifdef TERRAIN
bool is_flat_height=centroid_pos.x !=0.0 && u_height_type==1;bool is_flat_base=centroid_pos.x !=0.0 && u_base_type==1;float ele=elevation(pos_nx.xy);bool is_elevation_encoded=centroid_pos.y==0.0 || (centroid_pos.y > 0.0 && int(centroid_pos.y)-(int(centroid_pos.y)/8)*8==7);float c_ele=is_flat_height || is_flat_base ? (is_elevation_encoded ? elevationFromUint16(centroid_pos.x) : flatElevation(centroid_pos)) : ele;float h_height=is_flat_height ? max(c_ele+height,ele+base+2.0) : ele+height;float h_base=is_flat_base ? max(c_ele+base,ele+base) : ele+(base==0.0 ?-5.0 : base);float h=t > 0.0 ? max(h_base,h_height) : h_base;pos=vec3(pos_nx.xy,h);
#else
pos=vec3(pos_nx.xy,t > 0.0 ? height : base);
#endif
#ifdef RENDER_WALL_MODE
vec3 join_normal_inside=vec3(a_join_normal_inside);vec2 wall_offset=u_width_scale*line_width*(join_normal_inside.xy/EXTENT);pos.xy+=(1.0-join_normal_inside.z)*wall_offset*0.5;pos.xy-=join_normal_inside.z*wall_offset*0.5;
#endif
float hidden=float((centroid_pos.x==0.0 && centroid_pos.y==1.0) || (color.a==0.0));gl_Position=mix(u_matrix*vec4(pos,1),AWAY,hidden);}`),fillExtrusionGroundEffect:U(`uniform highp float u_ao_pass;uniform highp float u_opacity;uniform highp float u_flood_light_intensity;uniform highp vec3 u_flood_light_color;uniform highp float u_attenuation;uniform sampler2D u_fb;uniform float u_fb_size;
#ifdef SDF_SUBPASS
in highp vec2 v_pos;in highp vec4 v_line_segment;in highp float v_flood_light_radius_tile;in highp vec2 v_ao;float line_df(highp vec2 a,highp vec2 b,highp vec2 p) {highp vec2 ba=b-a;highp vec2 pa=p-a;highp float r=clamp(dot(pa,ba)/dot(ba,ba),0.0,1.0);return length(pa-r*ba);}
#ifdef FOG
in highp float v_fog;
#endif
#endif
void main() {
#ifdef CLEAR_SUBPASS
vec4 color=vec4(1.0);
#ifdef CLEAR_FROM_TEXTURE
color=texture(u_fb,gl_FragCoord.xy/vec2(u_fb_size));
#endif
glFragColor=color;
#else
#ifdef SDF_SUBPASS
highp float d=line_df(v_line_segment.xy,v_line_segment.zw,v_pos);highp float effect_radius=mix(v_flood_light_radius_tile,v_ao.y,u_ao_pass);d/=effect_radius;d=min(d,1.0);d=1.0-pow(1.0-d,u_attenuation);highp float effect_intensity=mix(u_flood_light_intensity,v_ao.x,u_ao_pass);highp float fog=1.0;
#ifdef FOG
fog=v_fog;
#endif
#ifdef RENDER_CUTOFF
fog*=v_cutoff_opacity;
#endif
glFragColor=vec4(vec3(0.0),mix(1.0,d,effect_intensity*u_opacity*fog));
#else
#ifdef USE_MRT1
out_Target1=vec4(1.0-texture(u_fb,gl_FragCoord.xy/vec2(u_fb_size)).a,0.0,0.0,0.0);
#else
vec4 color=mix(vec4(u_flood_light_color,1.0),vec4(vec3(0.0),1.0),u_ao_pass);
#ifdef OVERDRAW_INSPECTOR
color=vec4(1.0);
#endif
glFragColor=color;
#endif
#endif
HANDLE_WIREFRAME_DEBUG;
#endif
}`,`#include "_prelude_fog.vertex.glsl"
in highp ivec4 a_pos_end;in highp int a_angular_offset_factor;in highp uint a_hidden_by_landmark;
#ifdef SDF_SUBPASS
out highp vec2 v_pos;out highp vec4 v_line_segment;out highp float v_flood_light_radius_tile;out highp vec2 v_ao;
#ifdef FOG
out highp float v_fog;
#endif
#endif
uniform highp float u_flood_light_intensity;uniform highp mat4 u_matrix;uniform highp float u_ao_pass;uniform highp float u_meter_to_tile;uniform highp float u_edge_radius;uniform highp float u_dynamic_offset;uniform highp vec2 u_ao;
#pragma mapbox: define highp float flood_light_ground_radius
const float TANGENT_CUTOFF=4.0;const float NORM=32767.0;void main() {
#pragma mapbox: initialize highp float flood_light_ground_radius
vec4 pos_end=vec4(a_pos_end);vec2 p=pos_end.xy;vec2 q=floor(pos_end.zw*0.5);vec2 start_bottom=pos_end.zw-q*2.0;float fl_ground_radius=abs(flood_light_ground_radius);float direction=flood_light_ground_radius < 0.0 ?-1.0 : 1.0;float flood_radius_tile=fl_ground_radius*u_meter_to_tile;vec2 v=normalize(q-p);float ao_radius=u_ao.y/3.5;float effect_radius=mix(flood_radius_tile,ao_radius,u_ao_pass)+u_edge_radius;float angular_offset_factor=float(a_angular_offset_factor)/NORM*TANGENT_CUTOFF;float angular_offset=direction*angular_offset_factor*effect_radius;float top=1.0-start_bottom.y;float side=(0.5-start_bottom.x)*2.0;vec2 extrusion_parallel=v*side*mix(u_dynamic_offset,angular_offset,top);vec2 perp=vec2(v.y,-v.x);vec2 extrusion_perp=direction*perp*effect_radius*top;vec3 pos=vec3(mix(q,p,start_bottom.x),0.0);pos.xy+=extrusion_parallel+extrusion_perp;
#ifdef SDF_SUBPASS
v_pos=pos.xy;v_line_segment=vec4(p,q)+perp.xyxy*u_edge_radius;v_flood_light_radius_tile=flood_radius_tile;v_ao=vec2(u_ao.x,ao_radius);
#ifdef FOG
v_fog_pos=fog_position(pos);v_fog=1.0-fog(v_fog_pos);
#endif
#endif
float hidden_by_landmark=0.0;
#ifdef HAS_CENTROID
hidden_by_landmark=float(a_hidden_by_landmark);
#endif
float isFloodlit=float(fl_ground_radius > 0.0 && u_flood_light_intensity > 0.0);float hidden=mix(1.0-isFloodlit,isFloodlit,u_ao_pass);hidden+=hidden_by_landmark;gl_Position=mix(u_matrix*vec4(pos,1.0),AWAY,float(hidden > 0.0));
#ifdef RENDER_CUTOFF
v_cutoff_opacity=cutoff_opacity(u_cutoff_params,gl_Position.z);
#endif
}`),groundShadow:U(`#include "_prelude_shadow.fragment.glsl"
#include "_prelude_indicator_cutout.fragment.glsl"
#include "_prelude_feature_cutout.fragment.glsl"
precision highp float;uniform vec3 u_ground_shadow_factor;in vec4 v_pos_light_view_0;in vec4 v_pos_light_view_1;
#ifdef FOG
in float v_fog_opacity;
#endif
void main() {float light=shadowed_light_factor_plane_bias(v_pos_light_view_0,v_pos_light_view_1,1.0/gl_FragCoord.w);vec3 shadow=mix(u_ground_shadow_factor,vec3(1.0),light);
#ifdef RENDER_CUTOFF
shadow=mix(vec3(1.0),shadow,cutoff_opacity(u_cutoff_params,1.0/gl_FragCoord.w));
#endif
#ifdef FOG
shadow=mix(shadow,vec3(1.0),v_fog_opacity);
#endif
glFragColor=vec4(shadow,1.0);}`,`#include "_prelude_fog.vertex.glsl"
uniform mat4 u_matrix;uniform mat4 u_light_matrix_0;uniform mat4 u_light_matrix_1;in ivec2 a_pos;out vec4 v_pos_light_view_0;out vec4 v_pos_light_view_1;
#ifdef FOG
out float v_fog_opacity;
#endif
void main() {gl_Position=u_matrix*vec4(a_pos,0.0,1.0);v_pos_light_view_0=u_light_matrix_0*vec4(a_pos,0.0,1.0);v_pos_light_view_1=u_light_matrix_1*vec4(a_pos,0.0,1.0);
#ifdef FOG
v_fog_pos=fog_position(vec2(a_pos));v_fog_opacity=fog(v_fog_pos);
#endif
}`)},Mt=(e,t)=>({u_matrix:e,u_ground_shadow_factor:t}),Nt={model:e=>({u_matrix:new z(e),u_lighting_matrix:new z(e),u_normal_matrix:new z(e),u_node_matrix:new z(e),u_lightpos:new Te(e),u_lightintensity:new H(e),u_lightcolor:new Te(e),u_camera_pos:new Te(e),u_opacity:new H(e),u_baseColorFactor:new ge(e),u_emissiveFactor:new ge(e),u_metallicFactor:new H(e),u_roughnessFactor:new H(e),u_baseTextureIsAlpha:new X(e),u_alphaMask:new X(e),u_alphaCutoff:new H(e),u_baseColorTexture:new X(e),u_metallicRoughnessTexture:new X(e),u_normalTexture:new X(e),u_occlusionTexture:new X(e),u_emissionTexture:new X(e),u_lutTexture:new X(e),u_color_mix:new ge(e),u_aoIntensity:new H(e),u_emissive_strength:new H(e),u_occlusionTextureTransform:new ge(e),u_dithered_discard_threshold:new H(e),u_model_mesh_params:new ge(e)}),modelDepth:e=>({u_matrix:new z(e),u_instance:new z(e),u_node_matrix:new z(e)}),groundShadow:e=>({u_matrix:new z(e),u_ground_shadow_factor:new Te(e)}),fillExtrusionDepth:we,fillExtrusionGroundEffect:Re},Pt=[];function Ft(e){return Pt[e]=Pt[e]||new Float64Array(16)}var It=[],Lt=new Float32Array(16),Rt=class{constructor(e,t){this.aabb=e,this.lastCascade=t}},zt=class{add(e,t){let n=this.receivers[e.key];n===void 0?this.receivers[e.key]=new Rt(t,null):(n.aabb.min[0]=Math.min(n.aabb.min[0],t.min[0]),n.aabb.min[1]=Math.min(n.aabb.min[1],t.min[1]),n.aabb.min[2]=Math.min(n.aabb.min[2],t.min[2]),n.aabb.max[0]=Math.max(n.aabb.max[0],t.max[0]),n.aabb.max[1]=Math.max(n.aabb.max[1],t.max[1]),n.aabb.max[2]=Math.max(n.aabb.max[2],t.max[2]))}clear(){this.receivers={}}get(e){return this.receivers[e.key]}computeRequiredCascades(e,t,n){let r=o.fromPoints(e.points),i=0;for(let e in this.receivers){let a=this.receivers[e];if(!a||!r.intersectsAabb(a.aabb))continue;a.aabb.min=r.closestPoint(a.aabb.min),a.aabb.max=r.closestPoint(a.aabb.max);let o=a.aabb.getCorners();for(let e=0;e<n.length;e++){let r=!0;for(let i of o){let a=[i[0]*t,i[1]*t,i[2]];if(j(a,a,n[e].matrix),a[0]<-1||a[0]>1||a[1]<-1||a[1]>1){r=!1;break}}if(a.lastCascade=e,i=Math.max(i,e),r)break}}return i+1}};function Bt(e,n,r){let i=ie([],r,n),a=ie([],e,n),o=te([],i,a),s=be(o);return s===0?[0,0,1,0]:(l(o,o,1/s),[o[0],o[1],o[2],-t(o,n)])}function Vt(t,r,i,a,o,s){let c=t.zoom,u=t.scale,d=t.worldSize,f=1/d,p=t.aspect,m=Math.sqrt(1+p*p)*Math.tan(.5*t.fovX),h=m*m,g=a-i,_=a+i,v,y;h>g/_?(v=a,y=a*m):(v=.5*_*(1+h),y=.5*Math.sqrt(g*g+2*(a*a+i*i)*h+_*_*h*h));let x=t.projection.pixelsPerMeter(t.center.lat,d),S=t._camera.getCameraToWorldMercator(),C=[0,0,-v*f];j(C,C,S);let T=y*f,E=function(e){return e[0]/=u,e[1]/=u,e[2]=ce(e[2],t._center.lat),e},D=t._edgeInsets;if(!(D.left===0&&D.top===0&&D.right===0&&D.bottom===0||D.left===D.right&&D.top===D.bottom)){let e=t._camera.getWorldToCamera(t.worldSize,t.projection.zAxisUnit===`meters`?x:1),r=t._camera.getCameraToClipPerspective(t._fov,t.width/t.height,i,a);r[8]=2*-t.centerOffset.x/t.width,r[9]=2*t.centerOffset.y/t.height;let o=new Float64Array(16);le(o,r,e);let s=new Float64Array(16);L(s,o);let l=Ie.fromInvProjectionMatrix(s,d,c,!0);for(let e of l.points){let t=E(e);T=Math.max(T,A(n([],C,t)))}}T*=o/(o-1);let ee=Math.acos(r[2]),te=Math.atan2(-r[0],-r[1]),k=new w;k.position=C,k.setPitchBearing(ee,te);let M=k.getWorldToCamera(d,x),N=T*d,P=Math.min(t._mercatorZfromZoom(17)*d*-2,-2*N),F=k.getCameraToClipOrthographic(-N,N,-N,N,P,(N+s*x)/r[2]),I=new Float64Array(16);e(I,F,M);let R=b(Math.floor(1e6*C[0])/1e6*d,Math.floor(1e6*C[1])/1e6*d,0),z=.5*o,B=[0,0,0];j(B,R,I),l(B,B,z);let V=[Math.floor(B[0]),Math.floor(B[1]),Math.floor(B[2])],H=[0,0,0];ie(H,B,V),l(H,H,-1/z);let U=new Float64Array(16);return Oe(U),O(U,U,H),e(I,U,I),[I,N]}var Ht={loaded:!0,drawModels:function(t,n,i,a){if(t.renderPass===`opaque`)return;let u=i.paint.get(`model-opacity`).constantOr(1),g=i.paint.get(`model-elevation-reference`),v=g===`ground`,y=g===`ground`;if(u===0)return;let b=i.paint.get(`model-cast-shadows`);if(t.renderPass===`shadow`&&(!b||t.terrain&&u<.65&&i._transitionablePaint._values[`model-opacity`].value.expression instanceof ae))return;let C=t.shadowRenderer,w=i.paint.get(`model-receive-shadows`);C&&(C.useNormalOffset=!0,w||(C.enabled=!1));let T=()=>{C&&(C.useNormalOffset=!0,w||(C.enabled=!0))},O=n.getSource();if(t.renderPass===`light-beam`&&O.type!==`batched-model`)return;if(O.type===`vector`||O.type===`geojson`)return function(e,t,n,r,i){let a=e.transform,o=a.projection.name===`globe`,s=a.getFreeCameraOptions().position;if(!e.modelManager)return;let u=e.modelManager;n.modelManager=u;let m=e.shadowRenderer;if(!Object.hasOwn(n._unevaluatedLayout._values,`model-id`))return;let h=n._unevaluatedLayout._values[`model-id`],g={...n.layout.get(`model-id`).parameters},_=e.style.order.indexOf(n.fqid),v=n.paint.get(`model-opacity`).constantOr(1);for(let y of r){let r=t.getTile(y).getBucket(n);if(!r||r.projection.name!==a.projection.name)continue;let b=r.getModelUris();b&&!r.modelsRequested&&(u.addModelsFromBucket(b,i),r.modelsRequested=!0),g.zoom=o?y.overscaledZ:Tt(y,a);let S=h.possiblyEvaluate(g);if(wt(e,r,y),$.shadowUniformsInitialized=!1,$.useSingleShadowCascade=!!m&&m.getMaxCascadeForTile(y.toUnwrapped())===0,e.renderPass===`shadow`&&m){if(e.currentShadowCascade===1&&r.isInsideFirstShadowMapFrustum)continue;let t=a.calculatePosMatrix(y.toUnwrapped(),a.worldSize);if($.tileMatrix.set(t),$.shadowTileMatrix.set(m.calculateShadowPassMatrixFromMatrix(t)),$.aabb.min=[0,0,0],$.aabb.max[0]=$.aabb.max[1]=8192,$.aabb.max[2]=0,Ot(r,$,e,n.scope))continue}let C=1<<y.canonical.z,w=[((s.x-y.wrap)*C-y.canonical.x)*f,(s.y*C-y.canonical.y)*f,s.z*C*f];e.conflationActive&&Object.keys(r.instancesPerModel).length>0&&e.style.isLayerClipped(n,t.getSource())&&r.updateReplacement(y,e.replacementSource,_,n.scope)&&(r.uploaded=!1,r.upload(e.context));let T=0,E=[],D=[],O=[];for(let t in r.instancesPerModel){let a=r.instancesPerModel[t];a.features.length>0&&!o&&(t=S.evaluate(a.features[0].feature,{}));let f=u.getModel(t,i);if(f||u.hasURLBeenRequested(t)||r.modelUris.includes(t)||(r.modelUris.push(t),r.modelsRequested=!1),f&&f.uploaded){if(o){let t=l([],[s.x,s.y,s.z],e.transform.worldSize);p(t,t);for(let n=0;n<a.instancedDataArray.length;++n){let i=[0,0,0],o=[1,1,1],s=Le(),l=a.tileCoordinatesForInstance(n),u=a.transformForInstance(n);F(o,u),c(s,u),x(i,s);let p=a.translationForInstance(n),m=new W(0,0);et(r.canonical,m,l.x,l.y);let h=ee();Ue(h,f,e.transform,m,i,o,p,!0,!1,!1);let g=a.colorForInstance(n),_=d([],t),y=Ne(m.lat,e.transform.zoom),b=I([],[1,1,1/y]);O.push({zScaleMatrix:b,negCameraPosMatrix:_});for(let t of f.nodes)vt(e,t,h,e.transform.expandedFarZProjMatrix,T,E,D,f.materialOverrides,v,g);++T}}else for(let t of f.nodes)Et(e,n,t,a,w,y,$)}}if(o){if(e.renderPass===`shadow`){for(let t of D)yt(t.mesh,t.nodeModelMatrix,e,n);for(let t of E)yt(t.mesh,t.nodeModelMatrix,e,n)}else Ct(e,n,E,D,O)}}}(t,n,i,a,_t(t,i)),void T();if(!O.loaded())return;if(O.type===`batched-model`)return function(t,n,i,a){i.resetLayerRenderingStats(t);let c=t.context,u=t.transform,f=t.style.fog,g=t.shadowRenderer;if(u.projection.name!==`mercator`)return void h(`Drawing 3D landmark models for ${u.projection.name} projection is not yet implemented`);let v=t.transform.getFreeCameraOptions().position,y=l([],[v.x,v.y,v.z],t.transform.worldSize),b=p([],y),x=d([],b),C=Ne(u.center.lat,u.zoom),w=I([],[1,1,1/C]),T=e([],x,w),O=i.paint.get(`model-opacity`).constantOr(1),ee=new D(c.gl.LEQUAL,D.ReadWrite,t.depthRangeFor3D),te=new D(c.gl.LEQUAL,D.ReadOnly,t.depthRangeFor3D),k=new o([1/0,1/0,1/0],[-1/0,-1/0,-1/0]),A=t.renderPass===`shadow`,M=t.renderPass===`light-beam`,N=i.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`,P=A&&g?g.getCurrentCascadeFrustum():u.getFrustum(u.scaleZoom(u.worldSize)),F=i.paint.get(`model-front-cutoff`),R=F[2]<1,z=S(t,i.paint.get(`model-cutoff-fade-range`)),V=i.getLayerRenderingStats();(function(e,t,n,r){let i=e.terrain?e.terrain.exaggeration():0,a=e.transform.zoom;for(let o of r){let r=t.getTile(o).getBucket(n);r&&(r.setFilter(n.filter),e.conflationActive&&r.updateReplacement(o,e.replacementSource),r.evaluateTransform(e,n),e.terrain&&i>0&&r.elevationUpdate(e.terrain,i,o,n.source),r.needsReEvaluation(e,a,n)&&r.evaluate(n))}})(t,n,i,a),function(){let o=new Map,l,d,p;R?(l=a.length-1,d=-1,p=-1):(l=0,d=a.length,p=1);let h=Se(),v=new B(0,0);for(let b=l;b!==d;b+=p){let l=a[b],d=n.getTile(l).getBucket(i);if(!d||!d.uploaded)continue;let p=!1;g&&(p=g.getMaxCascadeForTile(l.toUnwrapped())===0);let x=u.calculatePosMatrix(l.toUnwrapped(),u.worldSize),S=!!(d.modelTraits&Ge.HasMapboxMeshFeatures);e(nt,T,x),e(rt,u.expandedFarZProjMatrix,x),L(it,nt),E(it,it);let w=!A&&g&&g.enabled?g.computeCascadeTileMatrices(x):null;!A&&R&&(L(Q,x),j(h,y,Q),v.x=h[0],v.y=h[1]);let D=[];d.setFilter(i.filter);for(let n of d.getNodesInfo()){if(n.hiddenByReplacement||!n.node.meshes)continue;let i=n.node,a=0;t.terrain&&i.elevation&&(a=i.elevation*t.terrain.exaggeration());let o=(()=>{let e=n.aabb,t=k.min,r=k.max;return t[0]=e.min[0],t[1]=e.min[1],t[2]=e.min[2]+a,r[0]=e.max[0],r[1]=e.max[1],r[2]=e.max[2]+a,j(t,t,x),j(r,r,x),k})(),s=n.evaluatedScale;if(s[0]<=1&&s[1]<=1&&s[2]<=1&&o.intersects(P)===0)continue;if(!A){let e=o.min,r=o.max;ct[0]=.5*(e[0]+r[0]),ct[1]=.5*(e[1]+r[1]),ct[2]=.5*(e[2]+r[2]);let i=re(y,ct)*C,a=t._debugParams.lodSwitchDistance,c=a>=0;if(c&&a>=9999)n.targetLod=0;else{let o;if(c)o=a;else{let t=(r[2]-e[2])*C*s[2],n=Math.max(r[0]-e[0],r[1]-e[1])*C*Math.max(s[0],s[1]),i;i=t>=30?1:n>=80?.5:Math.max(t,n)>=20?.25:0,o=2e3+3e3*i}Dt(n,i,Math.min(t.frameTimeDelta,1e3/30),o,t._debugParams.lodSwitchFadeDuration)}}if(!A&&R){let e=1/6;n.cameraCollisionOpacity=y[0]>o.min[0]&&y[0]<o.max[0]&&y[1]>o.min[1]&&y[1]<o.max[1]&&y[2]*C<o.max[2]&&i.footprint&&_(v,i.footprint)?Math.max(n.cameraCollisionOpacity-e,0):Math.min(1,n.cameraCollisionOpacity+e)}let c=1/r(l.canonical),d=i.anchor?i.anchor[0]:0,f=i.anchor?i.anchor[1]:0,p=[d*(s[0]-1)+n.evaluatedTranslation[0]*c,f*(s[1]-1)+n.evaluatedTranslation[1]*c,a+n.evaluatedTranslation[2]],m=ft(new Float64Array(16),x,p,s),h=e([],m,i.globalMatrix),g=e([],u.expandedFarZProjMatrix,h),b=g[2]*d+g[6]*f+g[10]*a+g[14];i.hidden=!1;let S=O;A||(R&&(S*=n.cameraCollisionOpacity,S*=At(m,u,n.aabb,F)),S*=kt(z,b)),S===0?i.hidden=!0:D.push({nodeInfo:n,depth:b,opacity:S,wvpForNode:g,nodeModelMatrix:h,tileModelMatrix:m,tileTranslation:p})}A||D.sort((e,t)=>!R||e.opacity===1&&t.opacity===1?e.depth<t.depth?-1:1:e.opacity===1?-1:t.opacity===1?1:e.depth>t.depth?-1:1);for(let n of D){let r=n.nodeInfo,a=r.node,l=null;if(t._debugParams.show3DModelFootprints&&a.footprint){let e=a.id||a.name||`footprint`;if(!o.has(e)){let t=ft(new Float64Array(16),rt,n.tileTranslation,n.nodeInfo.evaluatedScale);o.set(e,{node:a,mvp:t})}}let d=n.nodeInfo.evaluatedScale;ft(Z,nt,n.tileTranslation,d),ot[0]=1/d[0],ot[1]=-1/d[1],ot[2]=1/d[2],Ce(Q,it,ot),e(Z,Z,a.globalMatrix);let h=S?0:r.evaluatedRMEA[0][2],_=r.targetLod,v=a.lodMeshes&&a.lodMeshes.length>0,y=v&&_>0&&_<1;if(A&&v&&Math.round(_)===1)continue;let b=!A&&f?dt(tt,n.nodeModelMatrix,t.transform):null,x=A&&g?g.calculateShadowPassMatrixFromMatrix(n.nodeModelMatrix):null,C=y?2:1,T=v&&Math.round(_)===1;for(let e=0;e<C;++e){let o=y?e===1:T,d=o?a.lodMeshes:a.meshes,v=y?o?-_:1-_:1;for(let e=0;e<d.length;++e){let _=d[e],C=!o&&e===a.lightMeshIndex,T=n.wvpForNode;if(C){if(!M&&!t.terrain&&t.shadowRenderer){t.currentLayer<t.firstLightBeamLayer&&(t.firstLightBeamLayer=t.currentLayer);continue}T=ft(at,rt,n.tileTranslation,n.nodeInfo.evaluatedScale)}else if(M)continue;let E={defines:[]},D=[],O=!!_.normalBuffer;!A&&g&&(g.useNormalOffset=O);let k=mt(r,_);if(ht(E.defines,D,_,t,N?null:i.lut,k),S||E.defines.push(`DIFFUSE_SHADED`),p&&E.defines.push(`SHADOWS_SINGLE_CASCADE`),V&&(A?V.numRenderedVerticesInShadowPass+=_.vertexArray.length:V.numRenderedVerticesInTransparentPass+=_.vertexArray.length),A){yt(_,n.nodeModelMatrix,t,i,x);continue}if(f&&u.projection.name!==`globe`){let e=_.aabb.min,t=_.aabb.max,[n,r]=f.getOpacityForBounds(b,e[0],e[1],t[0],t[1]);E.overrideFog=n>=.05||r>=.05}let j=_.material,P;j.occlusionTexture&&j.occlusionTexture.offsetScale&&(P=j.occlusionTexture.offsetScale,E.defines.push(`OCCLUSION_TEXTURE_TRANSFORM`)),y&&E.defines.push(`DITHERED_DISCARD`);let F=t.getOrCreateProgram(`model`,E);if(!A&&g&&g.enabled){if(l!==O){for(let e=0;e<w.length;e++)ft(ut[e]=ut[e]||new Float64Array(16),w[e],n.tileTranslation,n.nodeInfo.evaluatedScale);g.setupShadowsFromCascadeMatrices(ut,F,O),l=O}else F.setShadowUniformValues(c,g.getShadowUniformValues())}t.uploadCommonUniforms(c,F,null,b);let I=j.pbrMetallicRoughness;I.metallicFactor=.9,I.roughnessFactor=.5;let L=Qe(T,Z,Q,a.globalMatrix,t,n.opacity,I.baseColorFactor,j.emissiveFactor,I.metallicFactor,I.roughnessFactor,j,h,i,lt,P,void 0,void 0,v,F.fixedDefines.includes(`LIGHTING_3D_MODE`));L.u_model_mesh_params=pt(_,a,C,o),k&&k.bind(c,F.program),!C&&(r.hasTranslucentParts||n.opacity<1)&&F.draw(t,c.gl.TRIANGLES,ee,m.disabled,q.disabled,s.backCCW,L,i.id,_.vertexBuffer,_.indexBuffer,_.segments,i.paint,t.transform.zoom,void 0,D),F.draw(t,c.gl.TRIANGLES,C?te:ee,m.disabled,C||n.opacity<1||r.hasTranslucentParts?q.alphaBlended:q.unblended,s.backCCW,L,i.id,_.vertexBuffer,_.indexBuffer,_.segments,i.paint,t.transform.zoom,void 0,D)}}}}if(t._debugParams.show3DModelFootprints&&o.size>0){let e=Array.from(o.keys()).sort();for(let n of e){let{node:e,mvp:r}=o.get(n);bt(t,0,e,r)}}}()}(t,n,i,a),void T();if(O.type!==`model`)return;let te=O.getModels(),k=[],A=t.transform.getFreeCameraOptions().position,M=l([],[A.x,A.y,A.z],t.transform.worldSize);p(M,M);let N=[],P=[],R=0;for(let e of te){let r=n.getFeatureState(``,e.id),a={type:`Unknown`,id:e.id,properties:e.featureProperties},o=i.paint.get(`model-rotation`).evaluate(a,r),s=i.paint.get(`model-scale`).evaluate(a,r),c=i.paint.get(`model-translation`).evaluate(a,r),l=i.paint.get(`model-opacity`).evaluate(a,r);xt(i,e.id,r,e.featureProperties,e.nodeOverrideNames,e.nodeOverrides),St(i,e.id,r,e.featureProperties,e.materialOverrideNames,e.materialOverrides),e.nodeOverrides.size>0&&e.computeBoundsAndApplyParent(),e.computeModelMatrix(t,o,s,c,y,v,!1);let u=d([],M),f=Ne(e.position.lat,t.transform.zoom),p=I([],[1,1,1/f]);k.push({zScaleMatrix:p,negCameraPosMatrix:u});for(let n of e.nodes)vt(t,n,e.matrix,t.transform.expandedFarZProjMatrix,R,N,P,e.materialOverrides,l,void 0,e.lightOverrides);R++}if(N.sort((e,t)=>t.depth-e.depth),t.renderPass!==`shadow`){if(t._debugParams.show3DModelFootprints){let n=t.transform.projMatrix,r=new Map,i=(t,i)=>{if(t.footprint){let a=t.id||t.name||`footprint`;if(!r.has(a)){let o=e([],n,i);r.set(a,{node:t,mvp:o})}}};for(let e of P)i(e.node,e.modelMatrix);for(let e of N)i(e.node,e.modelMatrix);let a=Array.from(r.keys()).sort();for(let e of a){let{node:n,mvp:i}=r.get(e);bt(t,0,n,i)}}Ct(t,i,N,P,k),T()}else{for(let e of P)yt(e.mesh,e.nodeModelMatrix,t,i);for(let e of N)yt(e.mesh,e.nodeModelMatrix,t,i);T()}},prepare:function(e,t,n){let r=t.getSource();if(!r.loaded())return;if(r.type===`vector`||r.type===`geojson`)return void(n.modelManager&&n.modelManager.upload(n,_t(n,e)));if(r.type===`batched-model`||r.type!==`model`)return;let i=r.getModels();for(let e of i)e.upload(n.context)},shaders:jt,programUniforms:Nt,ShadowRenderer:class{constructor(e){this.painter=e,this._enabled=!1,this._drawShadowAfterLayer=-1,this._numCascadesToRender=0,this._cascades=[],this._groundShadowTiles=[],this._receivers=new zt,this._depthMode=new D(e.context.gl.LEQUAL,D.ReadWrite,[0,1]),this._uniformValues=i(),this._forceDisable=!1,this._devtoolsFolder=null,this.useNormalOffset=!1,this._shadowParameters={cascadeCount:2,normalOffset:3,shadowMapResolution:2048}}destroy(){for(let e of this._cascades)e.texture.destroy(),e.framebuffer.destroy();this._cascades=[]}_hasCasterGeometry(e,t){let n=this.painter.style.getLayerSourceCache(e);if(!n)return!1;let r=n.getSource();if(r.type===`model`)return r.getModels().length>0;let i=t[n.id];if(!i)return!1;for(let t of i){let r=n.getTile(t);if(r&&r.getBucket(e))return!0}return!1}updateShadowParameters(e,t,n){let r=this.painter;if(this._enabled=!1,this._drawShadowAfterLayer=-1,this._receivers.clear(),!t||!t.properties)return;let i=t.properties.get(`shadow-intensity`),a=t.properties.get(`shadow-draw-before-layer`);if(!t.shadowsEnabled()||i<=0)return;let o=-1,s=0;for(let t of r.style.order){let i=r.style._mergedLayers[t];i.hasShadowPass()&&!i.isHidden(e.zoom)&&this._hasCasterGeometry(i,n)&&(o=s),!a||a!==t&&a!==i.slot||(this._drawShadowAfterLayer=s>0?s-1:0),s+=1}if(this._enabled=o>=0,!this.enabled)return;this._drawShadowAfterLayer<0&&(this._drawShadowAfterLayer=o);let c=r.context,l=this._shadowParameters.shadowMapResolution,u=this._shadowParameters.shadowMapResolution;if(this._cascades.length===0||this._shadowParameters.shadowMapResolution!==this._cascades[0].texture.size[0]){this._cascades=[];for(let e=0;e<this._shadowParameters.cascadeCount;++e){let e=c.gl,t=c.createFramebuffer(l,u,0,`texture`),n=new xe(c,{width:l,height:u,data:null},e.DEPTH_COMPONENT16);t.depthAttachment.set(n.texture),this._cascades.push({framebuffer:t,texture:n,matrix:[],far:0,boundingSphereRadius:0,frustum:new Ie,scale:0})}}this.shadowDirection=Me(t);let d=0;if(e.elevation){let t=e.elevation,n=[1e4,-1e4];t.visibleDemTiles.filter(e=>e.dem).forEach(e=>{let t=e.dem.tree;n[0]=Math.min(n[0],t.minimums[0]),n[1]=Math.max(n[1],t.maximums[0])}),n[0]!==1e4&&(d=(n[1]-n[0])*t.exaggeration())}let f=1.5*e.cameraToCenterDistance,p=3*f,m=new Float64Array(16);for(let t=0;t<this._cascades.length;++t){let n=this._cascades[t],r=e.height/50,i=1;this._shadowParameters.cascadeCount===1?i=p:t===0?i=f:(r=f,i=p);let[a,o]=Vt(e,this.shadowDirection,r,i,this._shadowParameters.shadowMapResolution,d);n.scale=e.scale,n.matrix=a,n.boundingSphereRadius=o,L(m,n.matrix),n.frustum=Ie.fromInvProjectionMatrix(m,1,0,!0),n.far=i}let h=this._cascades.length-1;this._uniformValues.u_fade_range=[.75*this._cascades[h].far,this._cascades[h].far],this._uniformValues.u_shadow_intensity=i,this._uniformValues.u_shadow_direction=[this.shadowDirection[0],this.shadowDirection[1],this.shadowDirection[2]],this._uniformValues.u_shadow_texel_size=1/this._shadowParameters.shadowMapResolution,this._uniformValues.u_shadow_map_resolution=this._shadowParameters.shadowMapResolution,this._uniformValues.u_shadowmap_0=N.ShadowMap0,this._uniformValues.u_shadowmap_1=N.ShadowMap0+1,this._groundShadowTiles=r.transform.coveringTiles({tileSize:512,renderWorldCopies:!0});let g=r.transform.elevation;for(let e of this._groundShadowTiles){let t={min:0,max:0};if(g){let n=g.getMinMaxForTile(e);n&&(t=n)}this.addShadowReceiver(e.toUnwrapped(),t.min,t.max)}}get enabled(){return this._enabled&&!this._forceDisable}set enabled(e){this._enabled=e}drawShadowPass(e,t){if(!this.enabled)return;let n=this.painter,r=n.context;this._numCascadesToRender=this._receivers.computeRequiredCascades(n.transform.getFrustum(0),n.transform.worldSize,this._cascades),r.viewport.set([0,0,this._shadowParameters.shadowMapResolution,this._shadowParameters.shadowMapResolution]);for(let i=0;i<this._numCascadesToRender;++i){n.currentShadowCascade=i,r.bindFramebuffer.set(this._cascades[i].framebuffer.framebuffer),r.clear({color:K.white,depth:1});for(let r of e.order){let i=e._mergedLayers[r];if(!i.hasShadowPass()||i.isHidden(n.transform.zoom))continue;let a=e.getLayerSourceCache(i),o=a?t[a.id]:void 0;(i.type===`model`||o&&o.length)&&n.renderLayer(n,a,i,o)}}n.currentShadowCascade=0}drawGroundShadows(){if(!this.enabled)return;let e=this.painter,t=e.style,n=e.context,r=n.gl,i=t.directionalLight,a=t.ambientLight;if(!i||!a)return;let o=[],c=S(e,e.longestCutoffRange);c.shouldRenderCutoff&&o.push(`RENDER_CUTOFF`),o.push(`RENDER_SHADOWS`),this.useNormalOffset&&o.push(`NORMAL_OFFSET`);let l=ue(t,i,a),u=new D(r.LEQUAL,D.ReadOnly,e.depthRangeFor3D),d=new m({func:r.EQUAL,mask:255},0,255,r.KEEP,r.KEEP,r.KEEP);for(let t of this._groundShadowTiles){let i=t.toUnwrapped(),a=e.isTileAffectedByFog(t),f=e.getOrCreateProgram(`groundShadow`,{defines:o,overrideFog:a});this.setupShadows(i,f),e.uploadCommonUniforms(n,f,i,null,c);let p=Mt(e.transform.calculateProjMatrix(i),l);f.draw(e,r.TRIANGLES,u,d,q.multiply,s.disabled,p,`ground_shadow`,e.tileExtentBuffer,e.quadTriangleIndexBuffer,e.tileExtentSegments,null,e.transform.zoom,null,null)}}getShadowPassDepthMode(){return this._depthMode}getGroundShadowLayerIndex(){return this._drawShadowAfterLayer}calculateShadowPassMatrixFromTile(t){let n=this.painter.transform,r=n.calculatePosMatrix(t,n.worldSize);return e(r,this._cascades[this.painter.currentShadowCascade].matrix,r),Float32Array.from(r)}calculateShadowPassMatrixFromMatrix(t){return e(Lt,this._cascades[this.painter.currentShadowCascade].matrix,t)}setupShadows(t,n,i){if(!this.enabled)return;let a=this.painter.transform,o=this.painter.context,s=o.gl,c=this._uniformValues,l=a.calculatePosMatrix(t,a.worldSize);for(let t=0;t<this._cascades.length;t++){let n=Ft(t);e(n,this._cascades[t].matrix,l),c[t===0?`u_light_matrix_0`:`u_light_matrix_1`]=n,o.activeTexture.set(s.TEXTURE0+N.ShadowMap0+t),this._cascades[t].texture.bindExtraParam(s.LINEAR,s.LINEAR,s.CLAMP_TO_EDGE,s.CLAMP_TO_EDGE,s.GREATER)}if(this.useNormalOffset=!!i,this.useNormalOffset){let e=r(t.canonical),n=2/a.tileSize*f/this._shadowParameters.shadowMapResolution,o=n*this._cascades[0].boundingSphereRadius,s=n*this._cascades.at(-1).boundingSphereRadius,l=(i===`vector-tile`?1:3)*function(e){let t=Y((e-22)/-22,0,1);return .125*(1-t)+4*t}(a.zoom);c.u_shadow_normal_offset=[e,o*l,s*l],c.u_shadow_bias=[1e-4,.0012,.012]}else c.u_shadow_bias=[36e-5,.0012,.012];n.setShadowUniformValues(o,c)}computeCascadeTileMatrices(t){let n=this._shadowParameters.cascadeCount;for(let r=0;r<n;r++){let n=It[r]=It[r]||new Float64Array(16);e(n,this._cascades[r].matrix,t)}return It.length=n,It}setupShadowsFromMatrix(t,n,r=!1){if(!this.enabled)return;let i=this._shadowParameters.cascadeCount;for(let n=0;n<i;n++)e(Ft(n),this._cascades[n].matrix,t);Pt.length=i,this.setupShadowsFromCascadeMatrices(Pt,n,r)}setupShadowsFromCascadeMatrices(e,t,n=!1){if(!this.enabled)return;let r=this.painter.context,i=r.gl,a=this._uniformValues;for(let t=0;t<this._shadowParameters.cascadeCount;t++)a[t===0?`u_light_matrix_0`:`u_light_matrix_1`]=e[t],r.activeTexture.set(i.TEXTURE0+N.ShadowMap0+t),this._cascades[t].texture.bindExtraParam(i.LINEAR,i.LINEAR,i.CLAMP_TO_EDGE,i.CLAMP_TO_EDGE,i.GREATER);if(this.useNormalOffset=n,n){let e=this._shadowParameters.normalOffset;a.u_shadow_normal_offset=[1,e,e],a.u_shadow_bias=[6e-5,.0012,.012]}else a.u_shadow_bias=[36e-5,.0012,.012];t.setShadowUniformValues(r,a)}getShadowUniformValues(){return this._uniformValues}getCurrentCascadeFrustum(){return this._cascades[this.painter.currentShadowCascade].frustum}computeSimplifiedTileShadowVolume(e,t,n,r){if(r[2]>=0)return{};let i=function(e,t,n){let r=n/(1<<e.canonical.z);return new o([e.canonical.x*r+e.wrap*n,e.canonical.y*r+e.wrap*n,0],[(e.canonical.x+1)*r+e.wrap*n,(e.canonical.y+1)*r+e.wrap*n,t])}(e,t,n).getCorners(),a=t/-r[2];r[0]<0?(J(i[0],i[0],[r[0]*a,0,0]),J(i[3],i[3],[r[0]*a,0,0])):r[0]>0&&(J(i[1],i[1],[r[0]*a,0,0]),J(i[2],i[2],[r[0]*a,0,0])),r[1]<0?(J(i[0],i[0],[0,r[1]*a,0]),J(i[1],i[1],[0,r[1]*a,0])):r[1]>0&&(J(i[2],i[2],[0,r[1]*a,0]),J(i[3],i[3],[0,r[1]*a,0]));let s={};return s.vertices=i,s.planes=[Bt(i[1],i[0],i[4]),Bt(i[2],i[1],i[5]),Bt(i[3],i[2],i[6]),Bt(i[0],i[3],i[7])],s}addShadowReceiver(e,t,n){this._receivers.add(e,o.fromTileIdAndHeight(e,t,n))}getMaxCascadeForTile(e){let t=this._receivers.get(e);return t&&t.lastCascade?t.lastCascade:0}},drawGroundEffect:ze,queryModelLayerRendered:function(t,n,r,i){let a=r.getSource();if(!a||a.type!==`model`)return{};let o=a,s={};s[t.id]=[];let c=s[t.id],l=0;for(let a of o.models){let o=r.getFeatureState(t.sourceLayer,a.id),s={type:`Unknown`,id:a.id,properties:a.featureProperties},u=t.paint.get(`model-rotation`).evaluate(s,o),d=t.paint.get(`model-scale`).evaluate(s,o),f=t.paint.get(`model-translation`).evaluate(s,o),p=t.paint.get(`model-elevation-reference`),m=[];Ue(m,a,i,a.position,u,d,f,p===`ground`,p===`ground`,!1),i.projection.name===`globe`&&(m=Je(m,i));let h=e([],i.projMatrix,m),g=n.isPointQuery()?n.screenBounds:n.screenGeometry,_=Ve(g,i,h,a.aabb);if(_!=null){let e=new ve(void 0,0,0,0,a.id);e.layer=t.layer,e.properties=structuredClone(a.featureProperties),e.properties.layer=t.id,e.properties.uri=a.uri,e.properties.orientation=a.orientation,e.sourceLayer=t.sourceLayer,e.geometry={type:`Point`,coordinates:[a.position.lng,a.position.lat]},e.state=o,e.source=t.source,c.push({featureIndex:l,feature:e,intersectionZ:_})}++l}return s},queryModelLayerIntersectsFeature:function(t,n,r,i,a,o){if(!t.modelManager)return!1;let s=t.modelManager,c=n.tile.getBucket(t);if(!(c&&c instanceof Ye))return!1;for(let i in c.instancesPerModel){let l=c.instancesPerModel[i],u=r.id===void 0?r.properties&&Object.hasOwn(r.properties,`id`)?r.properties.id:void 0:r.id;if(Object.hasOwn(l.idToFeaturesIndex,u)){let r=l.features[l.idToFeaturesIndex[u]],d=s.getModel(i,o||t.scope);if(!d)return!1;let f=[],p=new W(0,0),m=c.canonical,h=Number.MAX_VALUE;for(let t=0;t<r.instancedDataCount;++t){let i=16*(r.instancedDataOffset+t),o=l.instancedDataArray.float32,s=[o[i+4],o[i+5],o[i+6]];et(m,p,Math.floor(o[i]),Math.floor(o[i+1])),Ue(f,d,a,p,r.rotation,r.scale,s,!1,!1,!1),a.projection.name===`globe`&&(f=Je(f,a));let c=e([],a.projMatrix,f),u=n.queryGeometry,g=u.isPointQuery()?u.screenBounds:u.screenGeometry,_=Ve(g,a,c,d.aabb);_!=null&&(h=Math.min(_,h))}return h!==Number.MAX_VALUE&&h}}return!1},loadMatchingModelFeature:function(t,n,r,i){let a=t.getNodesInfo()[n];if(!a||a.hiddenByReplacement||!a.node.meshes)return;let o=Number.MAX_VALUE,s=a.node,c=r.tile,l=i.calculatePosMatrix(c.tileID.toUnwrapped(),i.worldSize),u=a.evaluatedScale,d=0;i.elevation&&s.elevation&&(d=s.elevation*i.elevation.exaggeration()),O(l,l,[(s.anchor?s.anchor[0]:0)*(u[0]-1),(s.anchor?s.anchor[1]:0)*(u[1]-1),d]),Ce(l,l,u);let f=r.queryGeometry,p=f.isPointQuery()?f.screenBounds:f.screenGeometry,m=function(t){let n=e([],l,t.globalMatrix);e(n,i.expandedFarZProjMatrix,n);for(let e=0;e<t.meshes.length;++e){let r=t.meshes[e];if(e===t.lightMeshIndex)continue;let a=Ve(p,i,n,r.aabb);a!=null&&(o=Math.min(a,o))}if(t.children)for(let e of t.children)m(e)};if(m(s),o===Number.MAX_VALUE)return;let h=new W(0,0);return et(c.tileID.canonical,h,a.node.anchor[0],a.node.anchor[1]),{intersectionZ:o,position:h,feature:a.feature}},ModelSource:class e extends me{constructor(e,t,n,r){super(),this.id=e,this.type=`model`,this.models=[],this._options=t,this._modelsInfo=new Map,this._abortController=null}cancelModelRequests(){this._abortController&&=(this._abortController.abort(),null)}async loadGLTFFromURI(e,t){let n=await this.map._requestManager.transformRequest(e,V.Model,t);return Ke(n,t)}async loadModel(t,n,r){try{let i=await this.loadGLTFFromURI(n.uri,r);if(r.aborted)return;let a=this._modelsInfo.get(t);if(!a)return;let o=We(i),s=a.modelSpec,c=new Be(t,s.uri,s.position,s.orientation,o);e.applyModelSpecification(c,s),c.computeBoundsAndApplyParent(),this.models.push(c),a.model=c}catch(e){if(r.aborted)return;this.fire(new k(Error(`Could not load model ${t} from ${n.uri}`,{cause:e})))}}async load(){this._abortController||=new AbortController;let t=this._abortController.signal,n=[];for(let r in this._options.models){let i=this._options.models[r],a=this._modelsInfo.get(r);if(a&&a.model){a.modelSpec=i;let t=a.model;t.position=i.position==null?new W(0,0):new W(i.position[0],i.position[1]),t.orientation=i.orientation??[0,0,0],e.applyModelSpecification(t,i),t.computeBoundsAndApplyParent(),this.models.push(t)}else a?a.modelSpec=i:(this._modelsInfo.set(r,{modelSpec:i,model:null}),n.push(this.loadModel(r,i,t)))}n.length===0?this.loaded()&&this.fire(new u(`data`,{dataType:`source`,sourceDataType:`metadata`})):(await Promise.allSettled(n),t.aborted||this.fire(new u(`data`,{dataType:`source`,sourceDataType:`metadata`})))}static arrayFromColorSpecification(e){let t=e;if(t===void 0)return;if(Array.isArray(t))return[t[0],t[1],t[2]];let n=K.parse(t);return n?[n.r,n.g,n.b]:void 0}static applyModelSpecification(t,n){if(n.nodeOverrides&&e.convertNodeOverrides(t,n.nodeOverrides),n.materialOverrides&&e.convertMaterialOverrides(t,n.materialOverrides),n.nodeOverrideNames&&(t.nodeOverrideNames=[...n.nodeOverrideNames]),n.materialOverrideNames&&(t.materialOverrideNames=[...n.materialOverrideNames]),n.featureProperties&&(t.featureProperties=n.featureProperties),n.lightOverrides){let r=n.lightOverrides,i=e.arrayFromColorSpecification(r[`light-ambient-color`]),a=e.arrayFromColorSpecification(r[`light-directional-color`]);t.lightOverrides={ambientIntensity:r[`light-ambient-intensity`],ambientColor:i,directionalIntensity:r[`light-directional-intensity`],directionalColor:a}}else t.lightOverrides=void 0}static convertNodeOverrides(e,t){if(Array.isArray(t)&&t.every(e=>typeof e==`string`)){e.nodeOverrideNames=[];for(let n of t)e.nodeOverrideNames.push(n)}else Object.entries(t).forEach(([t,n])=>{let r={orientation:[0,0,0],minZoom:void 0,maxZoom:void 0};if(Object.hasOwn(n,`orientation`)){let e=n.orientation;e&&(r.orientation=e)}Object.hasOwn(n,`minzoom`)&&(r.minZoom=n.minzoom),Object.hasOwn(n,`maxzoom`)&&(r.maxZoom=n.maxzoom),e.nodeOverrides.set(t,r)})}static convertMaterialOverrides(t,n){if(Array.isArray(n)&&n.every(e=>typeof e==`string`)){t.materialOverrideNames=[];for(let e of n)t.materialOverrideNames.push(e)}else Object.entries(n).forEach(([n,r])=>{let i=e.arrayFromColorSpecification(r[`model-color`]),a={color:i===void 0?new K(1,1,1):new K(i[0],i[1],i[2]),colorMix:0,emissionStrength:0,opacity:1},o=r[`model-color-mix-intensity`];o!==void 0&&(a.colorMix=o);let s=r[`model-emissive-strength`];s!==void 0&&(a.emissionStrength=s);let c=r[`model-opacity`];c!==void 0&&(a.opacity=c),t.materialOverrides.set(n,a)})}onAdd(e){this.map=e,this.load()}hasTransition(){return!1}loaded(){if(this._modelsInfo.size===0)return!0;for(let e of this._modelsInfo.values())if(e.model==null)return!1;return!0}getModels(){return this.models}loadTile(e,t){}serialize(){return this._options}setProperty(e,t){return!1}reload(){this.cancelModelRequests();let e=_e(this.id,this.scope);this.map.style.clearSource(e),this.models=[],this._modelsInfo.clear(),this.load()}onRemove(e){this.cancelModelRequests()}setModels(e){this.models=[];let t=new Map;for(let n in e){let r=e[n],i=this._modelsInfo.get(n);i&&i.modelSpec.uri===r.uri&&t.set(n,i)}if(this._modelsInfo.size!==t.size){this.cancelModelRequests();for(let[e,n]of t)n.model||t.delete(e)}this._modelsInfo=t,this._options.models=e,this.load()}},Tiled3dModelSource:class extends me{constructor(e,t,n,r){super(),this.type=`batched-model`,this.id=e,this.tileSize=512,this._options=t,this.tiles=this._options.tiles,this.maxzoom=t.maxzoom||19,this.minzoom=t.minzoom||0,this.roundZoom=!0,this.usedInConflation=!0,this.dispatcher=n,this.reparseOverscaled=!1,this.scheme=`xyz`,this._loaded=!1,this.setEventedParent(r)}onAdd(e){this.map=e,this.load()}reload(){this.cancelTileJSONRequest();let e=_e(this.id,this.scope);this.load(()=>this.map.style.clearSource(e))}cancelTileJSONRequest(){this._tileJSONRequest&&=(this._tileJSONRequest.cancel(),null)}load(e){this._loaded=!1,this.fire(new u(`dataloading`,{dataType:`source`}));let t=Array.isArray(this.map._language)?this.map._language.join():this.map._language,n=this.map.getWorldview();this._tileJSONRequest=a(this._options,this.map._requestManager,t,n,(r,i)=>{this._tileJSONRequest=null,this._loaded=!0,r?(t&&console.warn(`Ensure that your requested language string is a valid BCP-47 code or list of codes. Found: ${t}`),n&&n.length!==2&&console.warn(`Requested worldview strings must be a valid ISO alpha-2 code. Found: ${n}`),this.fire(new k(r))):i&&(Object.assign(this,i),this.tileBounds=new pe(i),y(i.tiles,this.map._requestManager._customAccessToken),this.fire(new u(`data`,{dataType:`source`,sourceDataType:`metadata`})),this.fire(new u(`data`,{dataType:`source`,sourceDataType:`content`}))),e&&e(r)})}hasTransition(){return!1}hasTile(e){return!this.tileBounds||this.tileBounds.contains(e.canonical)}loaded(){return this._loaded}async loadTile(e,t){let n=this.map._requestManager.normalizeTileURL(e.tileID.canonical.url(this.tiles,this.scheme)),r=!e.actor||e.state===`expired`;if(r)e.actor=this.dispatcher.getActor();else{if(e.state===`loading`)return void(e.reloadCallback=t);if(e.buckets){let t=Object.values(e.buckets);for(let e of t)e.dirty=!0;e.state=`loaded`;return}}let i=r?`loadTile`:`reloadTile`,a=new AbortController;e.request=a;let o=(n,r)=>(delete e.request,e.aborted?t(null):n&&!v(n)?t(n):(this.map._refreshExpiredTiles&&r&&e.setExpiryData(ne(r.headers)),e.loadModelData(r,this.map.painter),e.state=`loaded`,t(null),void(e.reloadCallback&&=(this.loadTile(e,e.reloadCallback),null))));try{let r=await this.map._requestManager.transformRequest(n,V.Tile,a.signal);if(a.signal.aborted)return t(null);let s={request:r,data:void 0,uid:e.uid,tileID:e.tileID,tileZoom:e.tileZoom,zoom:e.tileID.overscaledZ,tileSize:this.tileSize*e.tileID.overscaleFactor(),type:this.type,source:this.id,scope:this.scope,showCollisionBoxes:this.map.showCollisionBoxes,renderSourceType:e.renderSourceType,brightness:this.map.style&&this.map.style.getBrightness()||0,pixelRatio:ye.devicePixelRatio,promoteId:this.promoteId};e.request=e.actor.sendCancelable(i,s,{},o)}catch(e){if(a.signal.aborted)return t(null);t(e)}}abortTile(e){e.request&&(e.request.abort(),delete e.request),e.actor&&e.actor.notify(`abortTile`,{uid:e.uid,type:this.type,source:this.id,scope:this.scope})}serialize(){return{...this._options}}},loadModel:He};export{Ht as Standard};