import{E as e,H as t,K as n,L as r,M as i,N as a,Q as o,S as s,U as c,V as l,b as u,f as d,j as f,m as p,v as m}from"./documentMetadata-C9b_NLej.js";import{$ as h,$i as g,$n as _,$s as v,Aa as y,Ao as b,B as x,Ba as S,Bs as C,Ci as w,Ct as T,D as E,Dt as D,Ea as O,Er as k,Es as A,Gr as j,Ir as M,It as N,Jo as P,L as F,M as I,Ma as L,Nt as R,Qn as z,Rn as B,Ro as V,Tt as H,U as ee,Un as te,Ur as ne,Ut as U,Vs as re,Vt as ie,X as ae,Yt as oe,Zn as se,Zr as ce,Zs as le,_n as ue,an as W,as as de,dr as G,en as fe,eo as pe,es as me,fo as he,fr as ge,g as _e,gt as ve,in as ye,io as be,ir as xe,j as Se,jo as Ce,ko as we,kr as K,l as Te,li as Ee,ms as De,na as q,nc as Oe,oo as ke,q as J,qn as Ae,qr as Y,r as X,sr as je,t as Me,wi as Ne,xs as Pe,y as Fe,ya as Ie,zs as Le}from"./shared-DkED7Zk_.js";import{n as Re,t as ze}from"./hd_standard.shared-DaYxuiwk.js";import{b as Be,c as Ve,d as He,h as Ue,l as We,o as Ge,s as Ke,t as qe,y as Je}from"./hd_standard.model-Bj7Wcz2R.js";import{n as Ye}from"./standard.shared-F6LAswi0.js";var Xe=new Float32Array(y([])),Ze=[0,0,0],Qe=(e,t,r,i,a,o,s,c,l,u,d,f,p,m=[0,0,0],h,g,v,y=1,b=!1)=>{let x=Ze,S=0,C=Ze;if(!b){let e=a.style.light,t=e.properties.get(`position`);if(x=[-t.x,-t.y,t.z],e.properties.get(`anchor`)===`viewport`){let e=_();ie(e,-a.transform.angle),E(x,x,e)}let n=e.properties.get(`color`).toNonPremultipliedRenderColor(null);S=e.properties.get(`intensity`),C=[n.r,n.g,n.b]}let w=d.alphaMode===`MASK`,T=p.paint.get(`model-ambient-occlusion-intensity`),D=p.paint.get(`model-color`).constantOr(W.white).toNonPremultipliedRenderColor(null);return D.a=p.paint.get(`model-color-mix-intensity`).constantOr(0),v&&(D.r=v[0],D.g=v[1],D.b=v[2],D.a=v[3]),g&&(D.r=g.color.r,D.g=g.color.g,D.b=g.color.b,D.a=g.colorMix,f=g.emissionStrength,o*=g.opacity),{u_matrix:e,u_lighting_matrix:t,u_normal_matrix:r,u_node_matrix:i||Xe,u_lightpos:x,u_lightintensity:S,u_lightcolor:C,u_camera_pos:m,u_opacity:o,u_baseTextureIsAlpha:0,u_alphaMask:+w,u_alphaCutoff:d.alphaCutoff,u_baseColorFactor:s.toNonPremultipliedRenderColor(null).toArray01(),u_emissiveFactor:c.toNonPremultipliedRenderColor(null).toArray01(),u_metallicFactor:l,u_roughnessFactor:u,u_baseColorTexture:n.BaseColor,u_metallicRoughnessTexture:n.MetallicRoughness,u_normalTexture:n.Normal,u_occlusionTexture:n.Occlusion,u_emissionTexture:n.Emission,u_lutTexture:n.LUT,u_color_mix:D.toArray01(),u_aoIntensity:T,u_emissive_strength:f,u_occlusionTextureTransform:h||[0,0,0,0],u_dithered_discard_threshold:y,u_model_mesh_params:[0,1,0,0]}},$e=(e,t=Xe,n=Xe)=>({u_matrix:e,u_instance:t,u_node_matrix:n});function et(e,t,n,r){let i=1<<e.z;t.lat=ye((r/G+e.y)/i),t.lng=T((n/G+e.x)/i)}var Z=new Float64Array(16),Q=new Float64Array(16),tt=new Float64Array(16),nt=new Float64Array(16),rt=new Float64Array(16),it=new Float64Array(16),at=new Float64Array(16),ot=[0,0,0],st=new Float32Array(16),ct=[0,0,0],lt=[0,0,0],ut=[];function dt(e,t,n){let r=n.cameraWorldSizeForFog/n.worldSize;return j(e,n.worldToFogMatrix,[r,r,1]),K(e,e,t),e}function ft(e,t,n,r){return Ce(e,t,n),xe(r,qe)||j(e,e,r),e}function pt(e,t,n,r){let i=n?t.lightsStyleAabb:e.aabb,a=i?i.min[2]:1/0,o=(i?i.max[2]:-1/0)-a;return[isFinite(a)?a:0,o>0&&isFinite(o)?o:1,+!!r,0]}function mt(e,t){return t.featureBuffer?e.partStyleUBO:null}function ht(e,t,r,i,a,o=null){let s=r.material,c=i.context,{baseColorTexture:l,metallicRoughnessTexture:u}=s.pbrMetallicRoughness,{normalTexture:d,occlusionTexture:f,emissionTexture:p}=s;function m(t,n,r){if(t&&(e.push(n),c.activeTexture.set(c.gl.TEXTURE0+r),t.gfxTexture)){let{minFilter:e,magFilter:n,wrapS:r,wrapT:i}=t.sampler;t.gfxTexture.bindExtraParam(e,n,r,i)}}m(l,`HAS_TEXTURE_u_baseColorTexture`,n.BaseColor),m(u,`HAS_TEXTURE_u_metallicRoughnessTexture`,n.MetallicRoughness),m(d,`HAS_TEXTURE_u_normalTexture`,n.Normal),m(f,`HAS_TEXTURE_u_occlusionTexture`,n.Occlusion),m(p,`HAS_TEXTURE_u_emissionTexture`,n.Emission),a&&(a.texture||=new Ae(i.context,a.image,[a.image.height,a.image.height,a.image.height],c.gl.RGBA8),c.activeTexture.set(c.gl.TEXTURE0+n.LUT),a.texture&&a.texture.bind(c.gl.LINEAR,c.gl.CLAMP_TO_EDGE),e.push(`APPLY_LUT_ON_GPU`)),r.texcoordBuffer&&(e.push(`HAS_ATTRIBUTE_a_uv_2f`),t.push(r.texcoordBuffer)),r.colorBuffer&&(e.push(r.colorBuffer.itemSize===12?`HAS_ATTRIBUTE_a_color_3f`:`HAS_ATTRIBUTE_a_color_4f`),t.push(r.colorBuffer)),r.normalBuffer&&(e.push(`HAS_ATTRIBUTE_a_normal_4n`),t.push(r.normalBuffer)),o&&(e.push(`HAS_ATTRIBUTE_a_feature`),t.push(r.featureBuffer)),s.alphaMode!==`OPAQUE`&&s.alphaMode!==`MASK`||e.push(`UNPREMULT_TEXTURE_IN_SHADER`),s.defined||e.push(`DIFFUSE_SHADED`);let h=i.shadowRenderer;h&&(e.push(`RENDER_SHADOWS`),h.useNormalOffset&&e.push(`NORMAL_OFFSET`))}function gt(e,t,n,i,a,o){let s=e.modelOpacity,l=t.context,u=new c(t.context.gl.LEQUAL,e.isLightMesh?c.ReadOnly:c.ReadWrite,t.depthRangeFor3D),d=t.transform,p=e.mesh,m=p.material,g=m.pbrMetallicRoughness,_=t.style.fog;t.transform.projection.zAxisUnit===`pixels`?Z.set(e.nodeModelMatrix):K(Z,i.zScaleMatrix,e.nodeModelMatrix),K(Z,i.negCameraPosMatrix,Z),Me(Q,Z),h(Q,Q);let v=n.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`,y=n.paint.get(`model-emissive-strength`).constantOr(0),b={defines:[]},x=[],S=t.shadowRenderer;S&&(S.useNormalOffset=!1),ht(b.defines,x,p,t,v?null:n.lut);let C=null;if(_&&(C=dt(tt,e.nodeModelMatrix,t.transform),d.projection.name!==`globe`)){let e=p.aabb.min,t=p.aabb.max,[n,r]=_.getOpacityForBounds(C,e[0],e[1],t[0],t[1]);b.overrideFog=n>=.05||r>=.05}let w=r(t,n.paint.get(`model-cutoff-fade-range`));w.shouldRenderCutoff&&b.defines.push(`RENDER_CUTOFF`);let T=t.getOrCreateProgram(`model`,b),E=Qe(e.worldViewProjection,Z,Q,null,t,s,g.baseColorFactor,m.emissiveFactor,g.metallicFactor,g.roughnessFactor,m,y,n,void 0,void 0,e.materialOverride,e.modelColor,1,T.fixedDefines.includes(`LIGHTING_3D_MODE`));t.uploadCommonUniforms(l,T,null,C,w,e.lightOverrides),t.renderPass!==`shadow`&&S&&S.setupShadowsFromMatrix(e.nodeModelMatrix,T),T.draw(t,l.gl.TRIANGLES,u,a,o,p.material.doubleSided?f.disabled:f.backCCW,E,n.id,p.vertexBuffer,p.indexBuffer,p.segments,n.paint,t.transform.zoom,void 0,x)}function _t(e,t){return e.style._importedAsBasemap?`basemap`:t.scope}function vt(e,t,n,r,i,a,o,s,c,l,u){let d=e.transform,f=!!t.isGeometryBloom&&t.isGeometryBloom;if(t.minZoom!==void 0&&e.transform.zoom<t.minZoom||t.maxZoom!==void 0&&e.transform.zoom>t.maxZoom||f&&e.renderPass===`shadow`)return;let p=d.projection.name===`globe`?Je(n,d):[...n];K(p,p,t.globalMatrix);let m=K([],r,p);if(t.meshes)for(let e of t.meshes){let r=s.get(e.material.name);if(r&&r.opacity<=0)continue;if(e.material.alphaMode!==`BLEND`){o.push({mesh:e,depth:0,modelIndex:i,worldViewProjection:m,nodeModelMatrix:p,isLightMesh:f,materialOverride:r,modelOpacity:c,modelColor:l,lightOverrides:u,node:t,modelMatrix:n});continue}let h=J([],e.centroid,m);!d.isOrthographic&&h[2]<=0||a.push({mesh:e,depth:h[2],modelIndex:i,worldViewProjection:m,nodeModelMatrix:p,isLightMesh:f,materialOverride:r,modelOpacity:c,modelColor:l,lightOverrides:u,node:t,modelMatrix:n})}if(t.children)for(let d of t.children)vt(e,d,n,r,i,a,o,s,c,l,u)}function yt(e,t,n,r,i){let a=n.shadowRenderer;if(!a)return;let s=a.getShadowPassDepthMode(),c=$e(i||a.calculateShadowPassMatrixFromMatrix(t));n.getOrCreateProgram(`modelDepth`).draw(n,n.context.gl.TRIANGLES,s,l.disabled,o.disabled,f.disabled,c,r.id,e.vertexBuffer,e.indexBuffer,e.segments,r.paint,n.transform.zoom,void 0,void 0)}function bt(e,t,n,r){let i=function(e,t){if(t.footprintDebugMesh)return t.footprintDebugMesh;if(!t.footprint)return null;let n=e.context,r=t.footprint.vertices,i=t.footprint.indices,a=new z;a.reserve(r.length);for(let e of r)a.emplaceBack(e.x,e.y);let o=new ne;o.reserve(i.length);for(let e=0;e<i.length;e+=3)o.emplaceBack(i[e],i[e+1],i[e+2]);let s=n.createVertexBuffer(a,C.members),c=n.createIndexBuffer(o),l=le.simpleSegment(0,0,r.length,i.length),u=t.id||t.name||`footprint`,d,f=parseInt(u,10);d=isNaN(f)?function(e){let t=0;for(let n=0;n<e.length;n++)t=(t<<5)-t+e.charCodeAt(n)|0;return t}(u):f;let p=Se(d),m=Se(d+1),h=Se(d+2);return t.footprintDebugMesh={vertexBuffer:s,indexBuffer:c,segments:l,color:new W(p,m,h,.5)},t.footprintDebugMesh}(e,n);if(!i)return;let a=e.context,s=a.gl,u=e.getOrCreateProgram(`debug`),d=i.color,m=c.disabled;a.activeTexture.set(s.TEXTURE0),e.emptyTexture.bind(s.LINEAR,s.CLAMP_TO_EDGE),u.draw(e,s.TRIANGLES,m,l.disabled,o.alphaBlended,f.disabled,p(r,d.toPremultipliedRenderColor(null)),`$debug`,i.vertexBuffer,i.indexBuffer,i.segments)}function xt(e,t,n,r,i,a){for(let o of i){let i={...r};i.part=o;let s={type:`Unknown`,id:t,properties:i},c={orientation:e.paint.get(`model-rotation`).evaluate(s,n)};a.set(o,c)}}function St(e,t,n,r,i,a){for(let o of i){let i={...r};i.part=o;let s={type:`Unknown`,id:t,properties:i},c={color:e.paint.get(`model-color`).evaluate(s,n),colorMix:e.paint.get(`model-color-mix-intensity`).evaluate(s,n),opacity:e.paint.get(`model-opacity`).evaluate(s,n),emissionStrength:e.paint.get(`model-emissive-strength`).evaluate(s,n)};a.set(o,c)}}function Ct(e,t,n,r,i){let a=!1;for(let n of r)n.modelOpacity!==1&&(gt(n,e,t,i[n.modelIndex],l.disabled,o.disabled),a=!0);for(let n of r)gt(n,e,t,i[n.modelIndex],n.modelOpacity===1?l.disabled:e.stencilModeFor3D(),e.colorModeForRenderPass());a&&e.resetStencilClippingMasks();let s=o.additive;for(let r of n)gt(r,e,t,i[r.modelIndex],l.disabled,r.isLightMesh?s:e.colorModeForRenderPass())}function wt(e,t,n){let r=t.updateZoomBasedPaintProperties(),i=function(e,t,n){let r,i,a,o=e.terrain?e.terrain.exaggeration():0;if(e.terrain&&o>0){let t=e.terrain,i=t.findDEMTileFor(n);i&&i.dem?r=x.create(t,n,i):o=0}if(o===0&&(t.terrainElevationMin=0,t.terrainElevationMax=0),o===t.validForExaggeration&&(o===0||r&&r._demTile&&r._demTile.tileID===t.validForDEMTile.id&&r._dem._timestamp===t.validForDEMTile.timestamp))return!1;for(let e in t.instancesPerModel){let n=t.instancesPerModel[e];for(let e=0;e<n.instancedDataArray.length;++e){let s=(r?o*r.getElevationAt(0|n.instancedDataArray.float32[16*e],0|n.instancedDataArray.float32[16*e+1],!0,!0):0)+n.instancesEvaluatedElevation[e];n.instancedDataArray.float32[16*e+6]=s,i=i?Math.min(t.terrainElevationMin,s):s,a=a?Math.max(t.terrainElevationMax,s):s}}return t.terrainElevationMin=i||0,t.terrainElevationMax=a||0,t.validForExaggeration=o,t.validForDEMTile=r&&r._demTile?{id:r._demTile.tileID,timestamp:r._dem._timestamp}:{id:void 0,timestamp:0},!0}(e,t,n);(r||i)&&(t.uploaded=!1,t.upload(e.context))}var $={shadowUniformsInitialized:!1,useSingleShadowCascade:!1,tileMatrix:new Float64Array(16),shadowTileMatrix:new Float32Array(16),aabb:new ae([0,0,0],[G,G,0])};function Tt(e,t){let n=1<<e.canonical.z,r=t.getFreeCameraOptions().position,i=t.elevation,a=e.canonical.x/n,o=(e.canonical.x+1)/n,s=e.canonical.y/n,c=(e.canonical.y+1)/n,l=t._centerAltitude;if(i){let t=i.getMinMaxForTile(e);t&&t.max>l&&(l=t.max)}let u=Y(r.x,a,o)-r.x,d=Y(r.y,s,c)-r.y,f=_e(l,t.center.lat)-r.z;return t._zoomFromMercatorZ(Math.sqrt(u*u+d*d+f*f))}function Et(e,t,n,i,a,s,u){let d=e.context,p=e.renderPass===`shadow`,m=e.shadowRenderer,h=p&&m?m.getShadowPassDepthMode():new c(d.gl.LEQUAL,c.ReadWrite,e.depthRangeFor3D),g=e.isTileAffectedByFog(s),_=e.transform.projection.name===`globe`;if(n.meshes)for(let c of n.meshes){let v=_?[]:[`MODEL_POSITION_ON_GPU`],y=[],b,x,S,C=!_&&i.instancedDataArray.length>20;C&&v.push(`INSTANCED_ARRAYS`);let w=r(e,t.paint.get(`model-cutoff-fade-range`));if(w.shouldRenderCutoff&&v.push(`RENDER_CUTOFF`),p&&m)b=e.getOrCreateProgram(`modelDepth`,{defines:v}),x=$e(u.shadowTileMatrix,u.shadowTileMatrix,n.globalMatrix),S=o.disabled;else{ht(v,y,c,e,t.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`?null:t.lut),b=e.getOrCreateProgram(`model`,{defines:v,overrideFog:g});let r=c.material,i=r.pbrMetallicRoughness,l=t.paint.get(`model-opacity`).constantOr(1),f=t.paint.get(`model-emissive-strength`).constantOr(0);x=Qe(s.expandedProjMatrix,n.globalMatrix,st,null,e,l,i.baseColorFactor,r.emissiveFactor,i.metallicFactor,i.roughnessFactor,r,f,t,a,void 0,void 0,void 0,1,b.fixedDefines.includes(`LIGHTING_3D_MODE`)),m&&(u.shadowUniformsInitialized?b.setShadowUniformValues(d,m.getShadowUniformValues()):(m.setupShadows(s.toUnwrapped(),b,`model-tile`),u.shadowUniformsInitialized=!0)),S=w.shouldRenderCutoff||l<1||r.alphaMode!==`OPAQUE`?o.alphaBlended:o.unblended}e.uploadCommonUniforms(d,b,s.toUnwrapped(),null,w);let T=c.material.doubleSided?f.disabled:f.backCCW;if(C)y.push(i.instancedDataBuffer),b.draw(e,d.gl.TRIANGLES,h,l.disabled,S,T,x,t.id,c.vertexBuffer,c.indexBuffer,c.segments,t.paint,e.transform.zoom,void 0,y,i.instancedDataArray.length);else{let n=p?`u_instance`:`u_normal_matrix`;for(let r=0;r<i.instancedDataArray.length;++r)x[n]=new Float32Array(i.instancedDataArray.arrayBuffer,64*r,16),b.draw(e,d.gl.TRIANGLES,h,l.disabled,S,T,x,t.id,c.vertexBuffer,c.indexBuffer,c.segments,t.paint,e.transform.zoom,void 0,y)}}if(n.children)for(let r of n.children)Et(e,t,r,i,a,s,u)}function Dt(e,t,n,r,i){let a=e.node;if(a.lodMeshes&&a.lodMeshes.length>0){if(e.targetLod<0)e.targetLod=+(t>r);else{let a=i>0?n/1e3/i:1;e.targetLod=Y(t>r?e.targetLod+a:e.targetLod-a,0,1)}}else e.targetLod=0}function Ot(e,t,n,r){if(!n.modelManager)return!0;let i=n.modelManager;if(!n.shadowRenderer)return!0;let a=n.shadowRenderer,o=t.aabb,s=!0,c=e.maxHeight;if(c===0){let t=0;for(let n in e.instancesPerModel){let e=i.getModel(n,r);e?t=Math.max(t,Math.max(Math.max(e.aabb.max[0],e.aabb.max[1]),e.aabb.max[2])):s=!1}c=e.maxScale*t*1.41+e.maxVerticalOffset,s&&(e.maxHeight=c)}o.max[2]=c,o.min[2]+=e.terrainElevationMin,o.max[2]+=e.terrainElevationMax,J(o.min,o.min,t.tileMatrix),J(o.max,o.max,t.tileMatrix);let l=o.intersects(a.getCurrentCascadeFrustum());return n.currentShadowCascade===0&&(e.isInsideFirstShadowMapFrustum=l===2),l===0}function kt(e,t){let n=e.uniformValues.u_cutoff_params[0],r=e.uniformValues.u_cutoff_params[1],i=e.uniformValues.u_cutoff_params[2],a=e.uniformValues.u_cutoff_params[3];return r===n||a===i?1:Y(((t-n)/(r-n)-i)/(a-i),0,1)}function At(e,t,n,r){if(t.pitch<20)return 1;let i=t.getWorldToCameraMatrix();K(i,i,e);let a=ge(n.min[0],n.min[1],n.min[2],1),o=M(oe(),a,i),s=o,c=o;a[1]=n.max[1],o=M(oe(),a,i),s=o[1]<s[1]?o:s,c=o[1]>c[1]?o:c,a[0]=n.max[0],o=M(oe(),a,i),s=o[1]<s[1]?o:s,c=o[1]>c[1]?o:c,a[1]=n.min[1],o=M(oe(),a,i),s=o[1]<s[1]?o:s,c=o[1]>c[1]?o:c;let l=Y(r[0],0,1),u=100*t.pixelsPerMeter*Y(r[1],0,1),d=Y(r[2],0,1),f=Te(oe(),s,c,l),p=Math.tan(.5*t.fovX),m=-f[2]*p;if(u===0)return f[1]<-Math.abs(m)?d:1;let h=(-Math.abs(m)-f[1])/u,g=Y(Fe(1,d,h),d,1);return Fe(1,g,Y((t.pitch-20)/20,0,1))}var jt={model:s(`#include "_prelude_fog.fragment.glsl"
#include "_prelude_shadow.fragment.glsl"
#include "_prelude_lighting.glsl"
#include "_prelude_indicator_cutout.fragment.glsl"
#include "_prelude_feature_cutout.fragment.glsl"
uniform float u_opacity;
#ifdef DITHERED_DISCARD
uniform float u_dithered_discard_threshold;
#endif
#ifndef LIGHTING_3D_MODE
uniform vec3 u_lightcolor;uniform vec3 u_lightpos;uniform float u_lightintensity;
#endif
uniform vec4 u_baseColorFactor;uniform vec4 u_emissiveFactor;uniform float u_metallicFactor;uniform float u_roughnessFactor;uniform float u_emissive_strength;in highp vec4 v_position_height;in lowp vec4 v_color_mix;
#ifdef RENDER_SHADOWS
in highp vec4 v_pos_light_view_0;in highp vec4 v_pos_light_view_1;in float v_depth_shadows;
#endif
#ifdef OCCLUSION_TEXTURE_TRANSFORM
uniform vec4 u_occlusionTextureTransform;
#endif
#pragma mapbox: define-attribute highp vec4 normal_4n
#pragma mapbox: define-attribute highp vec3 color_3f
#pragma mapbox: define-attribute highp vec4 color_4f
#pragma mapbox: define-attribute highp vec2 uv_2f
#pragma mapbox: initialize-attribute highp vec4 normal_4n
#pragma mapbox: initialize-attribute highp vec3 color_3f
#pragma mapbox: initialize-attribute highp vec4 color_4f
#pragma mapbox: initialize-attribute highp vec2 uv_2f
#ifdef HAS_ATTRIBUTE_a_feature
in lowp vec4 v_roughness_metallic_emissive_alpha;in mediump vec4 v_height_based_emission_params;
#endif
#ifdef HAS_TEXTURE_u_baseColorTexture
uniform sampler2D u_baseColorTexture;uniform bool u_baseTextureIsAlpha;uniform bool u_alphaMask;uniform float u_alphaCutoff;
#endif
#ifdef HAS_TEXTURE_u_metallicRoughnessTexture
uniform sampler2D u_metallicRoughnessTexture;
#endif
#ifdef HAS_TEXTURE_u_occlusionTexture
uniform sampler2D u_occlusionTexture;uniform float u_aoIntensity;
#endif
#ifdef HAS_TEXTURE_u_normalTexture
uniform sampler2D u_normalTexture;
#endif
#ifdef HAS_TEXTURE_u_emissionTexture
uniform sampler2D u_emissionTexture;
#endif
#ifdef APPLY_LUT_ON_GPU
uniform highp sampler3D u_lutTexture;
#endif
#define saturate(_x) clamp(_x,0.,1.)
vec3 linearTosRGB(vec3 color) {return pow(color,vec3(1./2.2));}vec3 sRGBToLinear(vec3 srgbIn) {return pow(srgbIn,vec3(2.2));}float calculate_NdotL(vec3 normal,vec3 lightDir) {const float ext=0.70710678118;return (clamp(dot(normal,lightDir),-ext,1.0)+ext)/(1.0+ext);}vec3 getDiffuseShadedColor(vec3 albedo,vec3 normal,vec3 lightDir,vec3 lightColor)
{
#ifdef LIGHTING_3D_MODE
vec3 transformed_normal=vec3(-normal.xy,normal.z);float lighting_factor;
#ifdef RENDER_SHADOWS
lighting_factor=shadowed_light_factor_normal(transformed_normal,v_pos_light_view_0,v_pos_light_view_1,v_depth_shadows);
#else
lighting_factor=saturate(dot(transformed_normal,u_lighting_directional_dir));
#endif
return apply_lighting(albedo,transformed_normal,lighting_factor);
#else
vec3 n=normal;float colorvalue=((albedo.x*0.2126)+(albedo.y*0.7152))+(albedo.z*0.0722);vec3 c=vec3(0.03,0.03,0.03);float directional=clamp(dot(n,vec3(lightDir)),0.0,1.0);directional=mix(1.0-u_lightintensity,max((1.0-colorvalue)+u_lightintensity,1.0),directional);vec3 c3=c+clamp((albedo*directional)*lightColor,mix(vec3(0.0),vec3(0.3),vec3(1.0)-lightColor),vec3(1.0));return c3;
#endif
}vec4 getBaseColor() {vec4 albedo=u_baseColorFactor;
#ifdef HAS_ATTRIBUTE_a_color_3f
albedo*=vec4(color_3f,1.0);
#endif
#ifdef HAS_ATTRIBUTE_a_feature
#else
#ifdef HAS_ATTRIBUTE_a_color_4f
albedo*=color_4f;
#endif
#endif
#if defined (HAS_TEXTURE_u_baseColorTexture) && defined (HAS_ATTRIBUTE_a_uv_2f)
vec4 texColor=texture(u_baseColorTexture,uv_2f);if(u_alphaMask) {if (texColor.w < u_alphaCutoff) {discard;}}
#ifdef UNPREMULT_TEXTURE_IN_SHADER
texColor=vec4(unpremultiplyColor(texColor),1.0);
#endif
if(u_baseTextureIsAlpha) {if (texColor.r < 0.5) {discard;}} else {texColor.rgb=sRGBToLinear(texColor.rgb);albedo*=texColor;}
#endif
vec4 color=vec4(mix(albedo.rgb,v_color_mix.rgb,v_color_mix.a),albedo.a);
#ifdef APPLY_LUT_ON_GPU
color=applyLUT(u_lutTexture,color);
#endif
return color;}highp mat3 cotangentFrame(highp vec3 N,highp vec3 p,highp vec2 uv ) {
#ifdef HAS_TEXTURE_u_normalTexture
highp vec3 dp1=vec3(dFdx(p.x),dFdx(p.y),dFdx(p.z));highp vec3 dp2=vec3(dFdy(p.x),dFdy(p.y),dFdy(p.z));highp vec2 duv1=vec2(dFdx(uv.x),dFdx(uv.y));highp vec2 duv2=vec2(dFdy(uv.x),dFdy(uv.y));highp vec3 dp2perp=cross( dp2,N );highp vec3 dp1perp=cross( N,dp1 );highp vec3 T=dp2perp*duv1.x+dp1perp*duv2.x;highp vec3 B=dp2perp*duv1.y+dp1perp*duv2.y;highp float lengthT=dot(T,T);highp float lengthB=dot(B,B);highp float maxLength=max(lengthT,lengthB);highp float invmax=inversesqrt( maxLength );highp mat3 res=mat3( T*invmax,B*invmax,N );return res;
#else
return mat3(1.0);
#endif
}highp vec3 getNormal(){highp vec3 n;
#ifdef HAS_ATTRIBUTE_a_normal_4n
n=normalize(normal_4n.xyz);
#else
highp vec3 fdx=vec3(dFdx(v_position_height.x),dFdx(v_position_height.y),dFdx(v_position_height.z));highp vec3 fdy=vec3(dFdy(v_position_height.x),dFdy(v_position_height.y),dFdy(v_position_height.z));n=normalize(cross(fdx,fdy))*-1.0;
#endif
#if defined(HAS_TEXTURE_u_normalTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
vec3 nMap=texture( u_normalTexture,uv_2f).xyz;nMap=normalize(2.0*nMap-vec3(1.0));highp vec3 v=normalize(-v_position_height.xyz);highp mat3 TBN=cotangentFrame(n,v,uv_2f);n=normalize(TBN*nMap);
#endif
return n;}struct Material {float perceptualRoughness;float alphaRoughness;float metallic;vec3 f90;vec4 baseColor;vec3 diffuseColor;vec3 specularColor;highp vec3 normal;};Material getPBRMaterial() {Material mat;mat.baseColor=getBaseColor();mat.perceptualRoughness=u_roughnessFactor;mat.metallic=u_metallicFactor;
#ifdef HAS_ATTRIBUTE_a_feature
mat.perceptualRoughness=v_roughness_metallic_emissive_alpha.x;mat.metallic=v_roughness_metallic_emissive_alpha.y;mat.baseColor.w*=v_roughness_metallic_emissive_alpha.w;
#endif
#if defined(HAS_TEXTURE_u_metallicRoughnessTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
vec4 mrSample=texture(u_metallicRoughnessTexture,uv_2f);mat.perceptualRoughness*=mrSample.g;mat.metallic*=mrSample.b;
#endif
const float c_minRoughness=0.04;mat.perceptualRoughness=clamp(mat.perceptualRoughness,c_minRoughness,1.0);mat.metallic=saturate(mat.metallic);mat.alphaRoughness=mat.perceptualRoughness*mat.perceptualRoughness;const vec3 f0=vec3(0.04);mat.diffuseColor=mat.baseColor.rgb*(vec3(1.0)-f0);mat.diffuseColor*=1.0-mat.metallic;mat.specularColor=mix(f0,mat.baseColor.rgb,mat.metallic);highp float reflectance=max(max(mat.specularColor.r,mat.specularColor.g),mat.specularColor.b);highp float reflectance90=saturate(reflectance*25.0);mat.f90=vec3(reflectance90);mat.normal=getNormal();return mat;}float V_GGX(float NdotL,float NdotV,float roughness)
{float a2=roughness*roughness;float GGXV=NdotL*sqrt(NdotV*NdotV*(1.0-a2)+a2);float GGXL=NdotV*sqrt(NdotL*NdotL*(1.0-a2)+a2);return 0.5/(GGXV+GGXL);}float V_GGXFast(float NdotL,float NdotV,float roughness) {float a=roughness;float GGXV=NdotL*(NdotV*(1.0-a)+a);float GGXL=NdotV*(NdotL*(1.0-a)+a);return 0.5/(GGXV+GGXL);}vec3 F_Schlick(vec3 specularColor,vec3 f90,float VdotH)
{return specularColor+(f90-specularColor)*pow(clamp(1.0-VdotH,0.0,1.0),5.0);}vec3 F_SchlickFast(vec3 specularColor,float VdotH)
{float x=1.0-VdotH;float x4=x*x*x*x;return specularColor+(1.0-specularColor)*x4*x;}float D_GGX(highp float NdotH,float alphaRoughness)
{highp float a4=alphaRoughness*alphaRoughness;highp float f=(NdotH*a4-NdotH)*NdotH+1.0;return a4/(PI*f*f);}vec3 diffuseBurley(Material mat,float LdotH,float NdotL,float NdotV)
{float f90=2.0*LdotH*LdotH*mat.alphaRoughness-0.5;return (mat.diffuseColor/PI)*(1.0+f90*pow((1.0-NdotL),5.0))*(1.0+f90*pow((1.0-NdotV),5.0));}vec3 diffuseLambertian(Material mat)
{
#ifdef LIGHTING_3D_MODE
return mat.diffuseColor;
#else
return mat.diffuseColor/PI;
#endif
}vec3 EnvBRDFApprox(vec3 specularColor,float roughness,highp float NdotV)
{vec4 c0=vec4(-1,-0.0275,-0.572,0.022);vec4 c1=vec4(1,0.0425,1.04,-0.04);highp vec4 r=roughness*c0+c1;highp float a004=min(r.x*r.x,exp2(-9.28*NdotV))*r.x+r.y;vec2 AB=vec2(-1.04,1.04)*a004+r.zw;return specularColor*AB.x+AB.y;}vec3 computeIndirectLightContribution(Material mat,float NdotV,vec3 normal)
{vec3 env_light=vec3(0.65,0.65,0.65);
#ifdef LIGHTING_3D_MODE
float ambient_factor=calculate_ambient_directional_factor(normal);env_light=u_lighting_ambient_color*ambient_factor;
#endif
vec3 envBRDF=EnvBRDFApprox(mat.specularColor,mat.perceptualRoughness,NdotV);vec3 indirectSpecular= envBRDF*env_light;vec3 indirectDiffuse=mat.diffuseColor*env_light;return indirectSpecular+indirectDiffuse;}vec3 computeLightContribution(Material mat,vec3 lightPosition,vec3 lightColor)
{highp vec3 n=mat.normal;highp vec3 v=normalize(-v_position_height.xyz);highp vec3 l=normalize(lightPosition);highp vec3 h=normalize(v+l);float NdotV=clamp(abs(dot(n,v)),0.001,1.0);float NdotL=saturate(dot(n,l));highp float NdotH=saturate(dot(n,h));float VdotH=saturate(dot(v,h));vec3 f=F_SchlickFast(mat.specularColor,VdotH);float g=V_GGXFast(NdotL,NdotV,mat.alphaRoughness);float d=D_GGX(NdotH,mat.alphaRoughness);vec3 diffuseTerm=(1.0-f)*diffuseLambertian(mat);vec3 specularTerm=f*g*d;vec3 transformed_normal=vec3(-n.xy,n.z);float lighting_factor;
#ifdef RENDER_SHADOWS
lighting_factor=shadowed_light_factor_normal(transformed_normal,v_pos_light_view_0,v_pos_light_view_1,v_depth_shadows);
#else
lighting_factor=NdotL;
#endif
vec3 directLightColor=(specularTerm+diffuseTerm)*lighting_factor*lightColor;vec3 indirectLightColor=computeIndirectLightContribution(mat,NdotV,transformed_normal);vec3 color=(saturate(directLightColor)+indirectLightColor);float intensityFactor=1.0;
#if !defined(LIGHTING_3D_MODE)
const vec3 luminosityFactor=vec3(0.2126,0.7152,0.0722);float luminance=dot(diffuseTerm,luminosityFactor);intensityFactor=mix((1.0-u_lightintensity),max((1.0-luminance+u_lightintensity),1.0),NdotL);
#endif
color*=intensityFactor;return color;}void main() {vec3 lightDir;vec3 lightColor;
#ifdef LIGHTING_3D_MODE
lightDir=u_lighting_directional_dir;lightDir.xy=-lightDir.xy;lightColor=u_lighting_directional_color;
#else
lightDir=u_lightpos;lightColor=u_lightcolor;
#endif
vec4 finalColor;
#ifdef DIFFUSE_SHADED
vec3 N=getNormal();vec3 baseColor=getBaseColor().rgb;vec3 diffuse=getDiffuseShadedColor(baseColor,N,lightDir,lightColor);
#ifdef HAS_TEXTURE_u_occlusionTexture
float ao=(texture(u_occlusionTexture,uv_2f).r-1.0)*u_aoIntensity+1.0;diffuse*=ao;
#endif
finalColor=vec4(mix(diffuse,baseColor,u_emissive_strength),1.0)*u_opacity;
#else
Material mat=getPBRMaterial();vec3 color=computeLightContribution(mat,lightDir,lightColor);float ao=1.0;
#if defined (HAS_TEXTURE_u_occlusionTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
#ifdef OCCLUSION_TEXTURE_TRANSFORM
vec2 uv=uv_2f.xy*u_occlusionTextureTransform.zw+u_occlusionTextureTransform.xy;
#else
vec2 uv=uv_2f;
#endif
ao=(texture(u_occlusionTexture,uv).x-1.0)*u_aoIntensity+1.0;color*=ao;
#endif
vec4 emissive=u_emissiveFactor;
#if defined(HAS_TEXTURE_u_emissionTexture) && defined(HAS_ATTRIBUTE_a_uv_2f)
emissive.rgb*=sRGBToLinear(texture(u_emissionTexture,uv_2f).rgb);
#endif
#ifdef APPLY_LUT_ON_GPU
float emissiveFactorLength=max(length(u_emissiveFactor.rgb),0.001);emissive.rgb=sRGBToLinear(applyLUT(u_lutTexture,linearTosRGB(emissive.rgb/emissiveFactorLength).rbg))*emissiveFactorLength;
#endif
color+=emissive.rgb;float opacity=mat.baseColor.w*u_opacity;
#ifdef HAS_ATTRIBUTE_a_feature
float resEmission=v_roughness_metallic_emissive_alpha.z;resEmission*=v_height_based_emission_params.z+v_height_based_emission_params.w*pow(clamp(v_height_based_emission_params.x,0.0,1.0),v_height_based_emission_params.y);vec3 color_mix=v_color_mix.rgb;
#ifdef APPLY_LUT_ON_GPU
color_mix=applyLUT(u_lutTexture,color_mix);
#endif
color=mix(color,color_mix,min(1.0,resEmission));
#ifdef HAS_ATTRIBUTE_a_color_4f
float distance=length(vec2(1.3*max(0.0,abs(color_4f.x)-color_4f.z),color_4f.y));distance+= mix(0.5,0.0,clamp(resEmission-1.0,0.0,1.0));opacity*=v_roughness_metallic_emissive_alpha.w*saturate(1.0-distance*distance);
#endif
#endif
vec3 unlitColor=mat.baseColor.rgb*ao+emissive.rgb;color=mix(color,unlitColor,u_emissive_strength);color=linearTosRGB(color);color*=opacity;finalColor=vec4(color,opacity);
#endif
#ifdef DITHERED_DISCARD
if (abs(u_dithered_discard_threshold) < 1.0) {float ditherValue=fract(52.9829189*fract(0.06711056*gl_FragCoord.x+0.00583715*gl_FragCoord.y));float compareValue=mix(1.0-ditherValue,ditherValue,step(0.0,u_dithered_discard_threshold));if (abs(u_dithered_discard_threshold) < compareValue) {discard;}}
#endif
#ifdef FOG
finalColor=fog_dither(fog_apply_premultiplied(finalColor,v_fog_pos,v_position_height.w));
#endif
#ifdef RENDER_CUTOFF
finalColor*=v_cutoff_opacity;
#endif
glFragColor=finalColor;
#ifdef OVERDRAW_INSPECTOR
glFragColor=vec4(1.0);
#endif
HANDLE_WIREFRAME_DEBUG;}`,`#include "_prelude_fog.vertex.glsl"
#include "_prelude_shadow.vertex.glsl"
#include "_prelude_feature_cutout.vertex.glsl"
in vec3 a_pos_3f;
#pragma mapbox: define-attribute highp vec4 normal_4n
#pragma mapbox: define-attribute highp vec2 uv_2f
#pragma mapbox: define-attribute highp vec3 color_3f
#pragma mapbox: define-attribute highp vec4 color_4f
#pragma mapbox: define-attribute-vertex-shader-only highp uvec2 feature
#define MODEL_PART_COUNT 7u
#define MODEL_PART_STYLE_SIZE_VEC4 28u
#ifdef HAS_ATTRIBUTE_a_feature
struct ModelPartStyle {vec4 color_mix;vec4 rmea;vec4 gradient;float gradient_power;};layout(std140) uniform ModelPartStyleUniform {vec4 part_style[MODEL_PART_STYLE_SIZE_VEC4];} u_model_part_style;uniform vec4 u_model_mesh_params;
#endif
uniform mat4 u_matrix;uniform mat4 u_node_matrix;uniform mat4 u_lighting_matrix;uniform vec3 u_camera_pos;uniform vec4 u_color_mix;
#ifdef INSTANCED_ARRAYS
in vec4 a_normal_matrix0;in vec4 a_normal_matrix1;in vec4 a_normal_matrix2;in vec4 a_normal_matrix3;
#else
uniform highp mat4 u_normal_matrix;
#endif
#ifdef RENDER_SHADOWS
uniform mat4 u_light_matrix_0;uniform mat4 u_light_matrix_1;out highp vec4 v_pos_light_view_0;out highp vec4 v_pos_light_view_1;out float v_depth_shadows;
#endif
out vec4 v_position_height;out lowp vec4 v_color_mix;
#ifdef HAS_ATTRIBUTE_a_feature
out lowp vec4 v_roughness_metallic_emissive_alpha;out mediump vec4 v_height_based_emission_params;
#endif
vec3 sRGBToLinear(vec3 srgbIn) {return pow(srgbIn,vec3(2.2));}
#ifdef HAS_ATTRIBUTE_a_feature
uint decodeModelPartId(uvec2 feature) {uint partId=feature.y & 0xFu;return partId < MODEL_PART_COUNT ? partId : 0u;}vec4 decodeModelVertexColor(uvec2 feature) {uvec4 nibbles=uvec4(feature.x >> 12u,feature.x >> 8u,feature.x >> 4u,feature.x) & 0xFu;return vec4(nibbles*17u)/255.0;}ModelPartStyle readModelPartStyle(uint partId) {uint base=partId*4u;ModelPartStyle style;style.color_mix=u_model_part_style.part_style[base];style.rmea=u_model_part_style.part_style[base+1u];style.gradient=u_model_part_style.part_style[base+2u];style.gradient_power=u_model_part_style.part_style[base+3u].x;return style;}vec3 modelAlbedo(ModelPartStyle style,vec4 vertexColor) {float ambientOcclusion=mix(1.0,vertexColor.a,u_model_mesh_params.z);return ambientOcclusion*mix(vertexColor.rgb,style.color_mix.rgb,style.color_mix.a);}vec4 resolveModelEmissiveGradient(ModelPartStyle style,float height) {float begin=u_model_mesh_params.x+u_model_mesh_params.y*style.gradient.x;float span=u_model_mesh_params.y*(style.gradient.y-style.gradient.x);return vec4((height-begin)/span,style.gradient_power,style.gradient.z,style.gradient.w);}
#endif
void main() {
#pragma mapbox: initialize-attribute highp vec4 normal_4n
#pragma mapbox: initialize-attribute highp vec2 uv_2f
#pragma mapbox: initialize-attribute highp vec3 color_3f
#pragma mapbox: initialize-attribute highp vec4 color_4f
#pragma mapbox: initialize-attribute-custom highp uvec2 feature
highp mat4 normal_matrix;
#ifdef INSTANCED_ARRAYS
normal_matrix=mat4(a_normal_matrix0,a_normal_matrix1,a_normal_matrix2,a_normal_matrix3);
#else
normal_matrix=u_normal_matrix;
#endif
vec3 local_pos;mat3 rs;
#ifdef MODEL_POSITION_ON_GPU
vec3 pos_color=normal_matrix[0].xyz;vec4 translate=normal_matrix[1];vec3 pos_a=floor(pos_color);vec3 rgb=1.05*(pos_color-pos_a);float hidden=float(pos_a.x > EXTENT);float color_mix=pos_a.z/100.0;v_color_mix=vec4(sRGBToLinear(rgb),color_mix);float meter_to_tile=normal_matrix[0].w;vec4 pos=vec4(pos_a.xy,translate.z,1.0);rs[0].x=normal_matrix[1].w;rs[0].yz=normal_matrix[2].xy;rs[1].xy=normal_matrix[2].zw;rs[1].z=normal_matrix[3].x;rs[2].xyz=normal_matrix[3].yzw;vec4 pos_node=u_lighting_matrix*vec4(a_pos_3f,1.0);vec3 rotated_pos_node=rs*pos_node.xyz;vec3 pos_model_tile=(rotated_pos_node+vec3(translate.xy,0.0))*vec3(meter_to_tile,meter_to_tile,1.0);pos.xyz+=pos_model_tile;local_pos=pos.xyz;gl_Position=mix(u_matrix*pos,AWAY,hidden);pos.z*=meter_to_tile;v_position_height.xyz=pos.xyz-u_camera_pos;
#else
local_pos=a_pos_3f;gl_Position=u_matrix*vec4(a_pos_3f,1);v_position_height.xyz=vec3(u_lighting_matrix*vec4(a_pos_3f,1));v_color_mix=vec4(sRGBToLinear(u_color_mix.rgb),u_color_mix.a);
#endif
v_position_height.w=a_pos_3f.z;
#ifdef HAS_ATTRIBUTE_a_feature
ModelPartStyle part_style=readModelPartStyle(decodeModelPartId(feature));v_color_mix=vec4(modelAlbedo(part_style,decodeModelVertexColor(feature)),1.0);v_roughness_metallic_emissive_alpha=part_style.rmea;v_height_based_emission_params=resolveModelEmissiveGradient(part_style,a_pos_3f.z);
#endif
#ifdef FOG
v_fog_pos=fog_position(local_pos);
#endif
#ifdef RENDER_CUTOFF
v_cutoff_opacity=cutoff_opacity(u_cutoff_params,gl_Position.z);
#endif
#ifdef HAS_ATTRIBUTE_a_normal_4n
#ifdef MODEL_POSITION_ON_GPU
float x_squared_scale=dot(rs[0],rs[0]);float y_squared_scale=dot(rs[1],rs[1]);float z_squared_scale=dot(rs[2],rs[2]);vec3 squared_scale=vec3(x_squared_scale,y_squared_scale,z_squared_scale);normal_4n=vec4(rs*((u_lighting_matrix*vec4(normal_4n.xyz,0.0)).xyz/squared_scale),0.0);normal_4n=normalize(normal_4n);
#else
normal_4n=vec4((normal_matrix*vec4(normal_4n.xyz,0)).xyz,0.0);
#endif
#endif
#ifdef HAS_ATTRIBUTE_a_feature
#ifdef HAS_ATTRIBUTE_a_color_4f
v_roughness_metallic_emissive_alpha.w=clamp(color_4f.a*v_roughness_metallic_emissive_alpha.w*(v_roughness_metallic_emissive_alpha.z-1.0),0.0,1.0);
#endif
#endif
#ifdef RENDER_SHADOWS
vec4 shadow_pos=u_node_matrix*vec4(local_pos,1.0);
#ifdef NORMAL_OFFSET
#ifdef HAS_ATTRIBUTE_a_normal_4n
#ifdef MODEL_POSITION_ON_GPU
vec3 offset=shadow_normal_offset(vec3(-normal_4n.xy,normal_4n.z));shadow_pos.xyz+=offset*shadow_normal_offset_multiplier0();
#else
vec3 offset=shadow_normal_offset_model(normal_4n.xyz);shadow_pos.xyz+=offset*shadow_normal_offset_multiplier0();
#endif
#endif
#endif
v_pos_light_view_0=u_light_matrix_0*shadow_pos;v_pos_light_view_1=u_light_matrix_1*shadow_pos;v_depth_shadows=gl_Position.w;
#endif
}`),modelDepth:s(`void main() {}`,`in vec3 a_pos_3f;uniform mat4 u_matrix;
#ifdef MODEL_POSITION_ON_GPU
#ifdef INSTANCED_ARRAYS
in vec4 a_normal_matrix0;in vec4 a_normal_matrix1;in vec4 a_normal_matrix2;in vec4 a_normal_matrix3;
#else
uniform highp mat4 u_instance;
#endif
uniform highp mat4 u_node_matrix;
#endif
void main() {
#ifdef MODEL_POSITION_ON_GPU
highp mat4 instance;
#ifdef INSTANCED_ARRAYS
instance=mat4(a_normal_matrix0,a_normal_matrix1,a_normal_matrix2,a_normal_matrix3);
#else
instance=u_instance;
#endif
vec3 pos_color=instance[0].xyz;vec4 translate=instance[1];vec3 pos_a=floor(pos_color);float hidden=float(pos_a.x > EXTENT);float meter_to_tile=instance[0].w;vec4 pos=vec4(pos_a.xy,translate.z,1.0);mat3 rs;rs[0].x=instance[1].w;rs[0].yz=instance[2].xy;rs[1].xy=instance[2].zw;rs[1].z=instance[3].x;rs[2].xyz=instance[3].yzw;vec4 pos_node=u_node_matrix*vec4(a_pos_3f,1.0);vec3 rotated_pos_node=rs*pos_node.xyz;vec3 pos_model_tile=(rotated_pos_node+vec3(translate.xy,0.0))*vec3(meter_to_tile,meter_to_tile,1.0);pos.xyz+=pos_model_tile;gl_Position=mix(u_matrix*pos,AWAY,hidden);
#else
gl_Position=u_matrix*vec4(a_pos_3f,1);
#endif
}`),fillExtrusionDepth:s(`void main() {}`,`#include "_prelude_terrain.vertex.glsl"
#include "_prelude_material_table.vertex.glsl"
uniform mat4 u_matrix;uniform float u_edge_radius;uniform float u_width_scale;uniform float u_vertical_scale;
#ifdef TERRAIN
uniform int u_height_type;uniform int u_base_type;
#endif
in ivec4 a_pos_normal_ed;
#if defined(HAS_CENTROID) || defined(TERRAIN)
in uvec2 a_centroid_pos;
#endif
#ifdef RENDER_WALL_MODE
in ivec4 a_join_normal_inside;
#endif
#pragma mapbox: define highp float base
#pragma mapbox: define highp float height
#pragma mapbox: define highp float line_width
#pragma mapbox: define highp vec4 color
void main() {DECLARE_MATERIAL_TABLE_INFO
#pragma mapbox: initialize highp float base
#pragma mapbox: initialize highp float height
#pragma mapbox: initialize highp float line_width
#pragma mapbox: initialize highp vec4 color
base*=u_vertical_scale;height*=u_vertical_scale;vec3 top_up_ny=vec3(a_pos_normal_ed.xyz & 1);vec3 pos_nx=vec3(a_pos_normal_ed.xyz >> 1);base=max(0.0,base);height=max(0.0,top_up_ny.y==0.0 && top_up_ny.x==1.0 ? height-u_edge_radius : height);float t=top_up_ny.x;vec2 centroid_pos=vec2(0.0);
#if defined(HAS_CENTROID) || defined(TERRAIN)
centroid_pos=vec2(a_centroid_pos);
#endif
vec3 pos;
#ifdef TERRAIN
bool is_flat_height=centroid_pos.x !=0.0 && u_height_type==1;bool is_flat_base=centroid_pos.x !=0.0 && u_base_type==1;float ele=elevation(pos_nx.xy);bool is_elevation_encoded=centroid_pos.y==0.0 || (centroid_pos.y > 0.0 && int(centroid_pos.y)-(int(centroid_pos.y)/8)*8==7);float c_ele=is_flat_height || is_flat_base ? (is_elevation_encoded ? elevationFromUint16(centroid_pos.x) : flatElevation(centroid_pos)) : ele;float h_height=is_flat_height ? max(c_ele+height,ele+base+2.0) : ele+height;float h_base=is_flat_base ? max(c_ele+base,ele+base) : ele+(base==0.0 ?-5.0 : base);float h=t > 0.0 ? max(h_base,h_height) : h_base;pos=vec3(pos_nx.xy,h);
#else
pos=vec3(pos_nx.xy,t > 0.0 ? height : base);
#endif
#ifdef RENDER_WALL_MODE
vec3 join_normal_inside=vec3(a_join_normal_inside);vec2 wall_offset=u_width_scale*line_width*(join_normal_inside.xy/EXTENT);pos.xy+=(1.0-join_normal_inside.z)*wall_offset*0.5;pos.xy-=join_normal_inside.z*wall_offset*0.5;
#endif
float hidden=float((centroid_pos.x==0.0 && centroid_pos.y==1.0) || (color.a==0.0));gl_Position=mix(u_matrix*vec4(pos,1),AWAY,hidden);}`),fillExtrusionGroundEffect:s(`uniform highp float u_ao_pass;uniform highp float u_opacity;uniform highp float u_flood_light_intensity;uniform highp vec3 u_flood_light_color;uniform highp float u_attenuation;uniform sampler2D u_fb;uniform float u_fb_size;
#ifdef SDF_SUBPASS
in highp vec2 v_pos;in highp vec4 v_line_segment;in highp float v_flood_light_radius_tile;in highp vec2 v_ao;float line_df(highp vec2 a,highp vec2 b,highp vec2 p) {highp vec2 ba=b-a;highp vec2 pa=p-a;highp float r=clamp(dot(pa,ba)/dot(ba,ba),0.0,1.0);return length(pa-r*ba);}
#ifdef FOG
in highp float v_fog;
#endif
#endif
void main() {
#ifdef CLEAR_SUBPASS
vec4 color=vec4(1.0);
#ifdef CLEAR_FROM_TEXTURE
color=texture(u_fb,gl_FragCoord.xy/vec2(u_fb_size));
#endif
glFragColor=color;
#else
#ifdef SDF_SUBPASS
highp float d=line_df(v_line_segment.xy,v_line_segment.zw,v_pos);highp float effect_radius=mix(v_flood_light_radius_tile,v_ao.y,u_ao_pass);d/=effect_radius;d=min(d,1.0);d=1.0-pow(1.0-d,u_attenuation);highp float effect_intensity=mix(u_flood_light_intensity,v_ao.x,u_ao_pass);highp float fog=1.0;
#ifdef FOG
fog=v_fog;
#endif
#ifdef RENDER_CUTOFF
fog*=v_cutoff_opacity;
#endif
glFragColor=vec4(vec3(0.0),mix(1.0,d,effect_intensity*u_opacity*fog));
#else
#ifdef USE_MRT1
out_Target1=vec4(1.0-texture(u_fb,gl_FragCoord.xy/vec2(u_fb_size)).a,0.0,0.0,0.0);
#else
vec4 color=mix(vec4(u_flood_light_color,1.0),vec4(vec3(0.0),1.0),u_ao_pass);
#ifdef OVERDRAW_INSPECTOR
color=vec4(1.0);
#endif
glFragColor=color;
#endif
#endif
HANDLE_WIREFRAME_DEBUG;
#endif
}`,`#include "_prelude_fog.vertex.glsl"
in highp ivec4 a_pos_end;in highp int a_angular_offset_factor;in highp uint a_hidden_by_landmark;
#ifdef SDF_SUBPASS
out highp vec2 v_pos;out highp vec4 v_line_segment;out highp float v_flood_light_radius_tile;out highp vec2 v_ao;
#ifdef FOG
out highp float v_fog;
#endif
#endif
uniform highp float u_flood_light_intensity;uniform highp mat4 u_matrix;uniform highp float u_ao_pass;uniform highp float u_meter_to_tile;uniform highp float u_edge_radius;uniform highp float u_dynamic_offset;uniform highp vec2 u_ao;
#pragma mapbox: define highp float flood_light_ground_radius
const float TANGENT_CUTOFF=4.0;const float NORM=32767.0;void main() {
#pragma mapbox: initialize highp float flood_light_ground_radius
vec4 pos_end=vec4(a_pos_end);vec2 p=pos_end.xy;vec2 q=floor(pos_end.zw*0.5);vec2 start_bottom=pos_end.zw-q*2.0;float fl_ground_radius=abs(flood_light_ground_radius);float direction=flood_light_ground_radius < 0.0 ?-1.0 : 1.0;float flood_radius_tile=fl_ground_radius*u_meter_to_tile;vec2 v=normalize(q-p);float ao_radius=u_ao.y/3.5;float effect_radius=mix(flood_radius_tile,ao_radius,u_ao_pass)+u_edge_radius;float angular_offset_factor=float(a_angular_offset_factor)/NORM*TANGENT_CUTOFF;float angular_offset=direction*angular_offset_factor*effect_radius;float top=1.0-start_bottom.y;float side=(0.5-start_bottom.x)*2.0;vec2 extrusion_parallel=v*side*mix(u_dynamic_offset,angular_offset,top);vec2 perp=vec2(v.y,-v.x);vec2 extrusion_perp=direction*perp*effect_radius*top;vec3 pos=vec3(mix(q,p,start_bottom.x),0.0);pos.xy+=extrusion_parallel+extrusion_perp;
#ifdef SDF_SUBPASS
v_pos=pos.xy;v_line_segment=vec4(p,q)+perp.xyxy*u_edge_radius;v_flood_light_radius_tile=flood_radius_tile;v_ao=vec2(u_ao.x,ao_radius);
#ifdef FOG
v_fog_pos=fog_position(pos);v_fog=1.0-fog(v_fog_pos);
#endif
#endif
float hidden_by_landmark=0.0;
#ifdef HAS_CENTROID
hidden_by_landmark=float(a_hidden_by_landmark);
#endif
float isFloodlit=float(fl_ground_radius > 0.0 && u_flood_light_intensity > 0.0);float hidden=mix(1.0-isFloodlit,isFloodlit,u_ao_pass);hidden+=hidden_by_landmark;gl_Position=mix(u_matrix*vec4(pos,1.0),AWAY,float(hidden > 0.0));
#ifdef RENDER_CUTOFF
v_cutoff_opacity=cutoff_opacity(u_cutoff_params,gl_Position.z);
#endif
}`),groundShadow:s(`#include "_prelude_shadow.fragment.glsl"
#include "_prelude_indicator_cutout.fragment.glsl"
#include "_prelude_feature_cutout.fragment.glsl"
precision highp float;uniform vec3 u_ground_shadow_factor;in vec4 v_pos_light_view_0;in vec4 v_pos_light_view_1;
#ifdef FOG
in float v_fog_opacity;
#endif
void main() {float light=shadowed_light_factor_plane_bias(v_pos_light_view_0,v_pos_light_view_1,1.0/gl_FragCoord.w);vec3 shadow=mix(u_ground_shadow_factor,vec3(1.0),light);
#ifdef RENDER_CUTOFF
shadow=mix(vec3(1.0),shadow,cutoff_opacity(u_cutoff_params,1.0/gl_FragCoord.w));
#endif
#ifdef FOG
shadow=mix(shadow,vec3(1.0),v_fog_opacity);
#endif
glFragColor=vec4(shadow,1.0);}`,`#include "_prelude_fog.vertex.glsl"
uniform mat4 u_matrix;uniform mat4 u_light_matrix_0;uniform mat4 u_light_matrix_1;in ivec2 a_pos;out vec4 v_pos_light_view_0;out vec4 v_pos_light_view_1;
#ifdef FOG
out float v_fog_opacity;
#endif
void main() {gl_Position=u_matrix*vec4(a_pos,0.0,1.0);v_pos_light_view_0=u_light_matrix_0*vec4(a_pos,0.0,1.0);v_pos_light_view_1=u_light_matrix_1*vec4(a_pos,0.0,1.0);
#ifdef FOG
v_fog_pos=fog_position(vec2(a_pos));v_fog_opacity=fog(v_fog_pos);
#endif
}`)},Mt=(e,t)=>({u_matrix:e,u_ground_shadow_factor:t}),Nt={model:e=>({u_matrix:new X(e),u_lighting_matrix:new X(e),u_normal_matrix:new X(e),u_node_matrix:new X(e),u_lightpos:new ue(e),u_lightintensity:new U(e),u_lightcolor:new ue(e),u_camera_pos:new ue(e),u_opacity:new U(e),u_baseColorFactor:new L(e),u_emissiveFactor:new L(e),u_metallicFactor:new U(e),u_roughnessFactor:new U(e),u_baseTextureIsAlpha:new B(e),u_alphaMask:new B(e),u_alphaCutoff:new U(e),u_baseColorTexture:new B(e),u_metallicRoughnessTexture:new B(e),u_normalTexture:new B(e),u_occlusionTexture:new B(e),u_emissionTexture:new B(e),u_lutTexture:new B(e),u_color_mix:new L(e),u_aoIntensity:new U(e),u_emissive_strength:new U(e),u_occlusionTextureTransform:new L(e),u_dithered_discard_threshold:new U(e),u_model_mesh_params:new L(e)}),modelDepth:e=>({u_matrix:new X(e),u_instance:new X(e),u_node_matrix:new X(e)}),groundShadow:e=>({u_matrix:new X(e),u_ground_shadow_factor:new ue(e)}),fillExtrusionDepth:m,fillExtrusionGroundEffect:Re},Pt=[];function Ft(e){return Pt[e]=Pt[e]||new Float64Array(16)}var It=[],Lt=new Float32Array(16),Rt=class{constructor(e,t){this.aabb=e,this.lastCascade=t}},zt=class{add(e,t){let n=this.receivers[e.key];n===void 0?this.receivers[e.key]=new Rt(t,null):(n.aabb.min[0]=Math.min(n.aabb.min[0],t.min[0]),n.aabb.min[1]=Math.min(n.aabb.min[1],t.min[1]),n.aabb.min[2]=Math.min(n.aabb.min[2],t.min[2]),n.aabb.max[0]=Math.max(n.aabb.max[0],t.max[0]),n.aabb.max[1]=Math.max(n.aabb.max[1],t.max[1]),n.aabb.max[2]=Math.max(n.aabb.max[2],t.max[2]))}clear(){this.receivers={}}get(e){return this.receivers[e.key]}computeRequiredCascades(e,t,n){let r=ae.fromPoints(e.points),i=0;for(let e in this.receivers){let a=this.receivers[e];if(!a||!r.intersectsAabb(a.aabb))continue;a.aabb.min=r.closestPoint(a.aabb.min),a.aabb.max=r.closestPoint(a.aabb.max);let o=a.aabb.getCorners();for(let e=0;e<n.length;e++){let r=!0;for(let i of o){let a=[i[0]*t,i[1]*t,i[2]];if(J(a,a,n[e].matrix),a[0]<-1||a[0]>1||a[1]<-1||a[1]>1){r=!1;break}}if(a.lastCascade=e,i=Math.max(i,e),r)break}}return i+1}};function Bt(e,t,n){let r=I([],n,t),i=I([],e,t),a=Oe([],r,i),o=Ie(a);return o===0?[0,0,1,0]:(w(a,a,1/o),[a[0],a[1],a[2],-se(a,t)])}function Vt(e,t,n,r,i,o){let s=e.zoom,c=e.scale,l=e.worldSize,u=1/l,d=e.aspect,f=Math.sqrt(1+d*d)*Math.tan(.5*e.fovX),p=f*f,m=r-n,h=r+n,g,_;p>m/h?(g=r,_=r*f):(g=.5*h*(1+p),_=.5*Math.sqrt(m*m+2*(r*r+n*n)*p+h*h*p*p));let v=e.projection.pixelsPerMeter(e.center.lat,l),x=e._camera.getCameraToWorldMercator(),S=[0,0,-g*u];J(S,S,x);let C=_*u,T=function(t){return t[0]/=c,t[1]/=c,t[2]=_e(t[2],e._center.lat),t},E=e._edgeInsets;if(!(E.left===0&&E.top===0&&E.right===0&&E.bottom===0||E.left===E.right&&E.top===E.bottom)){let t=e._camera.getWorldToCamera(e.worldSize,e.projection.zAxisUnit===`meters`?v:1),i=e._camera.getCameraToClipPerspective(e._fov,e.width/e.height,n,r);i[8]=2*-e.centerOffset.x/e.width,i[9]=2*e.centerOffset.y/e.height;let a=new Float64Array(16);pe(a,i,t);let o=new Float64Array(16);Me(o,a);let c=F.fromInvProjectionMatrix(o,l,s,!0);for(let e of c.points){let t=T(e);C=Math.max(C,te(ke([],S,t)))}}C*=i/(i-1);let D=Math.acos(t[2]),O=Math.atan2(-t[0],-t[1]),k=new a;k.position=S,k.setPitchBearing(D,O);let A=k.getWorldToCamera(l,v),j=C*l,M=Math.min(e._mercatorZfromZoom(17)*l*-2,-2*j),N=k.getCameraToClipOrthographic(-j,j,-j,j,M,(j+o*v)/t[2]),P=new Float64Array(16);K(P,N,A);let L=b(Math.floor(1e6*S[0])/1e6*l,Math.floor(1e6*S[1])/1e6*l,0),R=.5*i,z=[0,0,0];J(z,L,P),w(z,z,R);let B=[Math.floor(z[0]),Math.floor(z[1]),Math.floor(z[2])],V=[0,0,0];I(V,z,B),w(V,V,-1/R);let H=new Float64Array(16);return y(H),Ce(H,H,V),K(P,H,P),[P,j]}var Ht={loaded:!0,drawModels:function(e,t,n,i){if(e.renderPass===`opaque`)return;let a=n.paint.get(`model-opacity`).constantOr(1),s=n.paint.get(`model-elevation-reference`),u=s===`ground`,d=s===`ground`;if(a===0)return;let p=n.paint.get(`model-cast-shadows`);if(e.renderPass===`shadow`&&(!p||e.terrain&&a<.65&&n._transitionablePaint._values[`model-opacity`].value.expression instanceof O))return;let m=e.shadowRenderer,g=n.paint.get(`model-receive-shadows`);m&&(m.useNormalOffset=!0,g||(m.enabled=!1));let _=()=>{m&&(m.useNormalOffset=!0,g||(m.enabled=!0))},y=t.getSource();if(e.renderPass===`light-beam`&&y.type!==`batched-model`)return;if(y.type===`vector`||y.type===`geojson`)return function(e,t,n,r,i){let a=e.transform,o=a.projection.name===`globe`,s=a.getFreeCameraOptions().position;if(!e.modelManager)return;let c=e.modelManager;n.modelManager=c;let l=e.shadowRenderer;if(!Object.hasOwn(n._unevaluatedLayout._values,`model-id`))return;let u=n._unevaluatedLayout._values[`model-id`],d={...n.layout.get(`model-id`).parameters},f=e.style.order.indexOf(n.fqid),p=n.paint.get(`model-opacity`).constantOr(1);for(let m of r){let r=t.getTile(m).getBucket(n);if(!r||r.projection.name!==a.projection.name)continue;let h=r.getModelUris();h&&!r.modelsRequested&&(c.addModelsFromBucket(h,i),r.modelsRequested=!0),d.zoom=o?m.overscaledZ:Tt(m,a);let g=u.possiblyEvaluate(d);if(wt(e,r,m),$.shadowUniformsInitialized=!1,$.useSingleShadowCascade=!!l&&l.getMaxCascadeForTile(m.toUnwrapped())===0,e.renderPass===`shadow`&&l){if(e.currentShadowCascade===1&&r.isInsideFirstShadowMapFrustum)continue;let t=a.calculatePosMatrix(m.toUnwrapped(),a.worldSize);if($.tileMatrix.set(t),$.shadowTileMatrix.set(l.calculateShadowPassMatrixFromMatrix(t)),$.aabb.min=[0,0,0],$.aabb.max[0]=$.aabb.max[1]=8192,$.aabb.max[2]=0,Ot(r,$,e,n.scope))continue}let _=1<<m.canonical.z,y=[((s.x-m.wrap)*_-m.canonical.x)*G,(s.y*_-m.canonical.y)*G,s.z*_*G];e.conflationActive&&Object.keys(r.instancesPerModel).length>0&&e.style.isLayerClipped(n,t.getSource())&&r.updateReplacement(m,e.replacementSource,f,n.scope)&&(r.uploaded=!1,r.upload(e.context));let b=0,x=[],S=[],C=[];for(let t in r.instancesPerModel){let a=r.instancesPerModel[t];a.features.length>0&&!o&&(t=g.evaluate(a.features[0].feature,{}));let l=c.getModel(t,i);if(l||c.hasURLBeenRequested(t)||r.modelUris.includes(t)||(r.modelUris.push(t),r.modelsRequested=!1),l&&l.uploaded){if(o){let t=w([],[s.x,s.y,s.z],e.transform.worldSize);H(t,t);for(let n=0;n<a.instancedDataArray.length;++n){let i=[0,0,0],o=[1,1,1],s=V(),c=a.tileCoordinatesForInstance(n),u=a.transformForInstance(n);P(o,u),he(s,u),ve(i,s);let d=a.translationForInstance(n),f=new A(0,0);et(r.canonical,f,c.x,c.y);let m=je();Ue(m,l,e.transform,f,i,o,d,!0,!1,!1);let h=a.colorForInstance(n),g=R([],t),_=v(f.lat,e.transform.zoom),y=D([],[1,1,1/_]);C.push({zScaleMatrix:y,negCameraPosMatrix:g});for(let t of l.nodes)vt(e,t,m,e.transform.expandedFarZProjMatrix,b,x,S,l.materialOverrides,p,h);++b}}else for(let t of l.nodes)Et(e,n,t,a,y,m,$)}}if(o){if(e.renderPass===`shadow`){for(let t of S)yt(t.mesh,t.nodeModelMatrix,e,n);for(let t of x)yt(t.mesh,t.nodeModelMatrix,e,n)}else Ct(e,n,x,S,C)}}}(e,t,n,i,_t(e,n)),void _();if(!y.loaded())return;if(y.type===`batched-model`)return function(e,t,n,i){n.resetLayerRenderingStats(e);let a=e.context,s=e.transform,u=e.style.fog,d=e.shadowRenderer;if(s.projection.name!==`mercator`)return void we(`Drawing 3D landmark models for ${s.projection.name} projection is not yet implemented`);let p=e.transform.getFreeCameraOptions().position,m=w([],[p.x,p.y,p.z],e.transform.worldSize),g=H([],m),_=R([],g),y=v(s.center.lat,s.zoom),b=D([],[1,1,1/y]),x=K([],_,b),S=n.paint.get(`model-opacity`).constantOr(1),C=new c(a.gl.LEQUAL,c.ReadWrite,e.depthRangeFor3D),T=new c(a.gl.LEQUAL,c.ReadOnly,e.depthRangeFor3D),E=new ae([1/0,1/0,1/0],[-1/0,-1/0,-1/0]),O=e.renderPass===`shadow`,k=e.renderPass===`light-beam`,A=n.paint.get(`model-color-use-theme`).constantOr(`default`)===`none`,M=O&&d?d.getCurrentCascadeFrustum():s.getFrustum(s.scaleZoom(s.worldSize)),N=n.paint.get(`model-front-cutoff`),P=N[2]<1,F=r(e,n.paint.get(`model-cutoff-fade-range`)),I=n.getLayerRenderingStats();(function(e,t,n,r){let i=e.terrain?e.terrain.exaggeration():0,a=e.transform.zoom;for(let o of r){let r=t.getTile(o).getBucket(n);r&&(r.setFilter(n.filter),e.conflationActive&&r.updateReplacement(o,e.replacementSource),r.evaluateTransform(e,n),e.terrain&&i>0&&r.elevationUpdate(e.terrain,i,o,n.source),r.needsReEvaluation(e,a,n)&&r.evaluate(n))}})(e,t,n,i),function(){let r=new Map,c,p,g;P?(c=i.length-1,p=-1,g=-1):(c=0,p=i.length,g=1);let _=Pe(),v=new de(0,0);for(let b=c;b!==p;b+=g){let c=i[b],p=t.getTile(c).getBucket(n);if(!p||!p.uploaded)continue;let g=!1;d&&(g=d.getMaxCascadeForTile(c.toUnwrapped())===0);let w=s.calculatePosMatrix(c.toUnwrapped(),s.worldSize),D=!!(p.modelTraits&Ge.HasMapboxMeshFeatures);K(nt,x,w),K(rt,s.expandedFarZProjMatrix,w),Me(it,nt),h(it,it);let L=!O&&d&&d.enabled?d.computeCascadeTileMatrices(w):null;!O&&P&&(Me(Q,w),J(_,m,Q),v.x=_[0],v.y=_[1]);let R=[];p.setFilter(n.filter);for(let t of p.getNodesInfo()){if(t.hiddenByReplacement||!t.node.meshes)continue;let n=t.node,r=0;e.terrain&&n.elevation&&(r=n.elevation*e.terrain.exaggeration());let i=(()=>{let e=t.aabb,n=E.min,i=E.max;return n[0]=e.min[0],n[1]=e.min[1],n[2]=e.min[2]+r,i[0]=e.max[0],i[1]=e.max[1],i[2]=e.max[2]+r,J(n,n,w),J(i,i,w),E})(),a=t.evaluatedScale;if(a[0]<=1&&a[1]<=1&&a[2]<=1&&i.intersects(M)===0)continue;if(!O){let n=i.min,r=i.max;ct[0]=.5*(n[0]+r[0]),ct[1]=.5*(n[1]+r[1]),ct[2]=.5*(n[2]+r[2]);let o=Ee(m,ct)*y,s=e._debugParams.lodSwitchDistance,c=s>=0;if(c&&s>=9999)t.targetLod=0;else{let i;if(c)i=s;else{let e=(r[2]-n[2])*y*a[2],t=Math.max(r[0]-n[0],r[1]-n[1])*y*Math.max(a[0],a[1]),o;o=e>=30?1:t>=80?.5:Math.max(e,t)>=20?.25:0,i=2e3+3e3*o}Dt(t,o,Math.min(e.frameTimeDelta,1e3/30),i,e._debugParams.lodSwitchFadeDuration)}}if(!O&&P){let e=1/6;t.cameraCollisionOpacity=m[0]>i.min[0]&&m[0]<i.max[0]&&m[1]>i.min[1]&&m[1]<i.max[1]&&m[2]*y<i.max[2]&&n.footprint&&me(v,n.footprint)?Math.max(t.cameraCollisionOpacity-e,0):Math.min(1,t.cameraCollisionOpacity+e)}let o=1/ee(c.canonical),l=n.anchor?n.anchor[0]:0,u=n.anchor?n.anchor[1]:0,d=[l*(a[0]-1)+t.evaluatedTranslation[0]*o,u*(a[1]-1)+t.evaluatedTranslation[1]*o,r+t.evaluatedTranslation[2]],f=ft(new Float64Array(16),w,d,a),p=K([],f,n.globalMatrix),h=K([],s.expandedFarZProjMatrix,p),g=h[2]*l+h[6]*u+h[10]*r+h[14];n.hidden=!1;let _=S;O||(P&&(_*=t.cameraCollisionOpacity,_*=At(f,s,t.aabb,N)),_*=kt(F,g)),_===0?n.hidden=!0:R.push({nodeInfo:t,depth:g,opacity:_,wvpForNode:h,nodeModelMatrix:p,tileModelMatrix:f,tileTranslation:d})}O||R.sort((e,t)=>!P||e.opacity===1&&t.opacity===1?e.depth<t.depth?-1:1:e.opacity===1?-1:t.opacity===1?1:e.depth>t.depth?-1:1);for(let t of R){let i=t.nodeInfo,c=i.node,p=null;if(e._debugParams.show3DModelFootprints&&c.footprint){let e=c.id||c.name||`footprint`;if(!r.has(e)){let n=ft(new Float64Array(16),rt,t.tileTranslation,t.nodeInfo.evaluatedScale);r.set(e,{node:c,mvp:n})}}let m=t.nodeInfo.evaluatedScale;ft(Z,nt,t.tileTranslation,m),ot[0]=1/m[0],ot[1]=-1/m[1],ot[2]=1/m[2],j(Q,it,ot),K(Z,Z,c.globalMatrix);let h=D?0:i.evaluatedRMEA[0][2],_=i.targetLod,v=c.lodMeshes&&c.lodMeshes.length>0,y=v&&_>0&&_<1;if(O&&v&&Math.round(_)===1)continue;let b=!O&&u?dt(tt,t.nodeModelMatrix,e.transform):null,x=O&&d?d.calculateShadowPassMatrixFromMatrix(t.nodeModelMatrix):null,S=y?2:1,w=v&&Math.round(_)===1;for(let r=0;r<S;++r){let m=y?r===1:w,v=m?c.lodMeshes:c.meshes,S=y?m?-_:1-_:1;for(let r=0;r<v.length;++r){let _=v[r],w=!m&&r===c.lightMeshIndex,E=t.wvpForNode;if(w){if(!k&&!e.terrain&&e.shadowRenderer){e.currentLayer<e.firstLightBeamLayer&&(e.firstLightBeamLayer=e.currentLayer);continue}E=ft(at,rt,t.tileTranslation,t.nodeInfo.evaluatedScale)}else if(k)continue;let j={defines:[]},M=[],N=!!_.normalBuffer;!O&&d&&(d.useNormalOffset=N);let P=mt(i,_);if(ht(j.defines,M,_,e,A?null:n.lut,P),D||j.defines.push(`DIFFUSE_SHADED`),g&&j.defines.push(`SHADOWS_SINGLE_CASCADE`),I&&(O?I.numRenderedVerticesInShadowPass+=_.vertexArray.length:I.numRenderedVerticesInTransparentPass+=_.vertexArray.length),O){yt(_,t.nodeModelMatrix,e,n,x);continue}if(u&&s.projection.name!==`globe`){let e=_.aabb.min,t=_.aabb.max,[n,r]=u.getOpacityForBounds(b,e[0],e[1],t[0],t[1]);j.overrideFog=n>=.05||r>=.05}let F=_.material,R;F.occlusionTexture&&F.occlusionTexture.offsetScale&&(R=F.occlusionTexture.offsetScale,j.defines.push(`OCCLUSION_TEXTURE_TRANSFORM`)),y&&j.defines.push(`DITHERED_DISCARD`);let z=e.getOrCreateProgram(`model`,j);if(!O&&d&&d.enabled){if(p!==N){for(let e=0;e<L.length;e++)ft(ut[e]=ut[e]||new Float64Array(16),L[e],t.tileTranslation,t.nodeInfo.evaluatedScale);d.setupShadowsFromCascadeMatrices(ut,z,N),p=N}else z.setShadowUniformValues(a,d.getShadowUniformValues())}e.uploadCommonUniforms(a,z,null,b);let B=F.pbrMetallicRoughness;B.metallicFactor=.9,B.roughnessFactor=.5;let V=Qe(E,Z,Q,c.globalMatrix,e,t.opacity,B.baseColorFactor,F.emissiveFactor,B.metallicFactor,B.roughnessFactor,F,h,n,lt,R,void 0,void 0,S,z.fixedDefines.includes(`LIGHTING_3D_MODE`));V.u_model_mesh_params=pt(_,c,w,m),P&&P.bind(a,z.program),!w&&(i.hasTranslucentParts||t.opacity<1)&&z.draw(e,a.gl.TRIANGLES,C,l.disabled,o.disabled,f.backCCW,V,n.id,_.vertexBuffer,_.indexBuffer,_.segments,n.paint,e.transform.zoom,void 0,M),z.draw(e,a.gl.TRIANGLES,w?T:C,l.disabled,w||t.opacity<1||i.hasTranslucentParts?o.alphaBlended:o.unblended,f.backCCW,V,n.id,_.vertexBuffer,_.indexBuffer,_.segments,n.paint,e.transform.zoom,void 0,M)}}}}if(e._debugParams.show3DModelFootprints&&r.size>0){let t=Array.from(r.keys()).sort();for(let n of t){let{node:t,mvp:i}=r.get(n);bt(e,0,t,i)}}}()}(e,t,n,i),void _();if(y.type!==`model`)return;let b=y.getModels(),x=[],S=e.transform.getFreeCameraOptions().position,C=w([],[S.x,S.y,S.z],e.transform.worldSize);H(C,C);let T=[],E=[],k=0;for(let r of b){let i=t.getFeatureState(``,r.id),a={type:`Unknown`,id:r.id,properties:r.featureProperties},o=n.paint.get(`model-rotation`).evaluate(a,i),s=n.paint.get(`model-scale`).evaluate(a,i),c=n.paint.get(`model-translation`).evaluate(a,i),l=n.paint.get(`model-opacity`).evaluate(a,i);xt(n,r.id,i,r.featureProperties,r.nodeOverrideNames,r.nodeOverrides),St(n,r.id,i,r.featureProperties,r.materialOverrideNames,r.materialOverrides),r.nodeOverrides.size>0&&r.computeBoundsAndApplyParent(),r.computeModelMatrix(e,o,s,c,d,u,!1);let f=R([],C),p=v(r.position.lat,e.transform.zoom),m=D([],[1,1,1/p]);x.push({zScaleMatrix:m,negCameraPosMatrix:f});for(let t of r.nodes)vt(e,t,r.matrix,e.transform.expandedFarZProjMatrix,k,T,E,r.materialOverrides,l,void 0,r.lightOverrides);k++}if(T.sort((e,t)=>t.depth-e.depth),e.renderPass!==`shadow`){if(e._debugParams.show3DModelFootprints){let t=e.transform.projMatrix,n=new Map,r=(e,r)=>{if(e.footprint){let i=e.id||e.name||`footprint`;if(!n.has(i)){let a=K([],t,r);n.set(i,{node:e,mvp:a})}}};for(let e of E)r(e.node,e.modelMatrix);for(let e of T)r(e.node,e.modelMatrix);let i=Array.from(n.keys()).sort();for(let t of i){let{node:r,mvp:i}=n.get(t);bt(e,0,r,i)}}Ct(e,n,T,E,x),_()}else{for(let t of E)yt(t.mesh,t.nodeModelMatrix,e,n);for(let t of T)yt(t.mesh,t.nodeModelMatrix,e,n);_()}},prepare:function(e,t,n){let r=t.getSource();if(!r.loaded())return;if(r.type===`vector`||r.type===`geojson`)return void(n.modelManager&&n.modelManager.upload(n,_t(n,e)));if(r.type===`batched-model`||r.type!==`model`)return;let i=r.getModels();for(let e of i)e.upload(n.context)},shaders:jt,programUniforms:Nt,ShadowRenderer:class{constructor(e){this.painter=e,this._enabled=!1,this._drawShadowAfterLayer=-1,this._numCascadesToRender=0,this._cascades=[],this._groundShadowTiles=[],this._receivers=new zt,this._depthMode=new c(e.context.gl.LEQUAL,c.ReadWrite,[0,1]),this._uniformValues=i(),this._forceDisable=!1,this._devtoolsFolder=null,this.useNormalOffset=!1,this._shadowParameters={cascadeCount:2,normalOffset:3,shadowMapResolution:2048}}destroy(){for(let e of this._cascades)e.texture.destroy(),e.framebuffer.destroy();this._cascades=[]}_hasCasterGeometry(e,t){let n=this.painter.style.getLayerSourceCache(e);if(!n)return!1;let r=n.getSource();if(r.type===`model`)return r.getModels().length>0;let i=t[n.id];if(!i)return!1;for(let t of i){let r=n.getTile(t);if(r&&r.getBucket(e))return!0}return!1}updateShadowParameters(t,r,i){let a=this.painter;if(this._enabled=!1,this._drawShadowAfterLayer=-1,this._receivers.clear(),!r||!r.properties)return;let o=r.properties.get(`shadow-intensity`),s=r.properties.get(`shadow-draw-before-layer`);if(!r.shadowsEnabled()||o<=0)return;let c=-1,l=0;for(let e of a.style.order){let n=a.style._mergedLayers[e];n.hasShadowPass()&&!n.isHidden(t.zoom)&&this._hasCasterGeometry(n,i)&&(c=l),!s||s!==e&&s!==n.slot||(this._drawShadowAfterLayer=l>0?l-1:0),l+=1}if(this._enabled=c>=0,!this.enabled)return;this._drawShadowAfterLayer<0&&(this._drawShadowAfterLayer=c);let u=a.context,d=this._shadowParameters.shadowMapResolution,f=this._shadowParameters.shadowMapResolution;if(this._cascades.length===0||this._shadowParameters.shadowMapResolution!==this._cascades[0].texture.size[0]){this._cascades=[];for(let e=0;e<this._shadowParameters.cascadeCount;++e){let e=u.gl,t=u.createFramebuffer(d,f,0,`texture`),n=new fe(u,{width:d,height:f,data:null},e.DEPTH_COMPONENT16);t.depthAttachment.set(n.texture),this._cascades.push({framebuffer:t,texture:n,matrix:[],far:0,boundingSphereRadius:0,frustum:new F,scale:0})}}this.shadowDirection=e(r);let p=0;if(t.elevation){let e=t.elevation,n=[1e4,-1e4];e.visibleDemTiles.filter(e=>e.dem).forEach(e=>{let t=e.dem.tree;n[0]=Math.min(n[0],t.minimums[0]),n[1]=Math.max(n[1],t.maximums[0])}),n[0]!==1e4&&(p=(n[1]-n[0])*e.exaggeration())}let m=1.5*t.cameraToCenterDistance,h=3*m,g=new Float64Array(16);for(let e=0;e<this._cascades.length;++e){let n=this._cascades[e],r=t.height/50,i=1;this._shadowParameters.cascadeCount===1?i=h:e===0?i=m:(r=m,i=h);let[a,o]=Vt(t,this.shadowDirection,r,i,this._shadowParameters.shadowMapResolution,p);n.scale=t.scale,n.matrix=a,n.boundingSphereRadius=o,Me(g,n.matrix),n.frustum=F.fromInvProjectionMatrix(g,1,0,!0),n.far=i}let _=this._cascades.length-1;this._uniformValues.u_fade_range=[.75*this._cascades[_].far,this._cascades[_].far],this._uniformValues.u_shadow_intensity=o,this._uniformValues.u_shadow_direction=[this.shadowDirection[0],this.shadowDirection[1],this.shadowDirection[2]],this._uniformValues.u_shadow_texel_size=1/this._shadowParameters.shadowMapResolution,this._uniformValues.u_shadow_map_resolution=this._shadowParameters.shadowMapResolution,this._uniformValues.u_shadowmap_0=n.ShadowMap0,this._uniformValues.u_shadowmap_1=n.ShadowMap0+1,this._groundShadowTiles=a.transform.coveringTiles({tileSize:512,renderWorldCopies:!0});let v=a.transform.elevation;for(let e of this._groundShadowTiles){let t={min:0,max:0};if(v){let n=v.getMinMaxForTile(e);n&&(t=n)}this.addShadowReceiver(e.toUnwrapped(),t.min,t.max)}}get enabled(){return this._enabled&&!this._forceDisable}set enabled(e){this._enabled=e}drawShadowPass(e,t){if(!this.enabled)return;let n=this.painter,r=n.context;this._numCascadesToRender=this._receivers.computeRequiredCascades(n.transform.getFrustum(0),n.transform.worldSize,this._cascades),r.viewport.set([0,0,this._shadowParameters.shadowMapResolution,this._shadowParameters.shadowMapResolution]);for(let i=0;i<this._numCascadesToRender;++i){n.currentShadowCascade=i,r.bindFramebuffer.set(this._cascades[i].framebuffer.framebuffer),r.clear({color:W.white,depth:1});for(let r of e.order){let i=e._mergedLayers[r];if(!i.hasShadowPass()||i.isHidden(n.transform.zoom))continue;let a=e.getLayerSourceCache(i),o=a?t[a.id]:void 0;(i.type===`model`||o&&o.length)&&n.renderLayer(n,a,i,o)}}n.currentShadowCascade=0}drawGroundShadows(){if(!this.enabled)return;let e=this.painter,t=e.style,n=e.context,i=n.gl,a=t.directionalLight,s=t.ambientLight;if(!a||!s)return;let u=[],p=r(e,e.longestCutoffRange);p.shouldRenderCutoff&&u.push(`RENDER_CUTOFF`),u.push(`RENDER_SHADOWS`),this.useNormalOffset&&u.push(`NORMAL_OFFSET`);let m=d(t,a,s),h=new c(i.LEQUAL,c.ReadOnly,e.depthRangeFor3D),g=new l({func:i.EQUAL,mask:255},0,255,i.KEEP,i.KEEP,i.KEEP);for(let t of this._groundShadowTiles){let r=t.toUnwrapped(),a=e.isTileAffectedByFog(t),s=e.getOrCreateProgram(`groundShadow`,{defines:u,overrideFog:a});this.setupShadows(r,s),e.uploadCommonUniforms(n,s,r,null,p);let c=Mt(e.transform.calculateProjMatrix(r),m);s.draw(e,i.TRIANGLES,h,g,o.multiply,f.disabled,c,`ground_shadow`,e.tileExtentBuffer,e.quadTriangleIndexBuffer,e.tileExtentSegments,null,e.transform.zoom,null,null)}}getShadowPassDepthMode(){return this._depthMode}getGroundShadowLayerIndex(){return this._drawShadowAfterLayer}calculateShadowPassMatrixFromTile(e){let t=this.painter.transform,n=t.calculatePosMatrix(e,t.worldSize);return K(n,this._cascades[this.painter.currentShadowCascade].matrix,n),Float32Array.from(n)}calculateShadowPassMatrixFromMatrix(e){return K(Lt,this._cascades[this.painter.currentShadowCascade].matrix,e)}setupShadows(e,t,r){if(!this.enabled)return;let i=this.painter.transform,a=this.painter.context,o=a.gl,s=this._uniformValues,c=i.calculatePosMatrix(e,i.worldSize);for(let e=0;e<this._cascades.length;e++){let t=Ft(e);K(t,this._cascades[e].matrix,c),s[e===0?`u_light_matrix_0`:`u_light_matrix_1`]=t,a.activeTexture.set(o.TEXTURE0+n.ShadowMap0+e),this._cascades[e].texture.bindExtraParam(o.LINEAR,o.LINEAR,o.CLAMP_TO_EDGE,o.CLAMP_TO_EDGE,o.GREATER)}if(this.useNormalOffset=!!r,this.useNormalOffset){let t=ee(e.canonical),n=2/i.tileSize*G/this._shadowParameters.shadowMapResolution,a=n*this._cascades[0].boundingSphereRadius,o=n*this._cascades.at(-1).boundingSphereRadius,c=(r===`vector-tile`?1:3)*function(e){let t=Y((e-22)/-22,0,1);return .125*(1-t)+4*t}(i.zoom);s.u_shadow_normal_offset=[t,a*c,o*c],s.u_shadow_bias=[1e-4,.0012,.012]}else s.u_shadow_bias=[36e-5,.0012,.012];t.setShadowUniformValues(a,s)}computeCascadeTileMatrices(e){let t=this._shadowParameters.cascadeCount;for(let n=0;n<t;n++){let t=It[n]=It[n]||new Float64Array(16);K(t,this._cascades[n].matrix,e)}return It.length=t,It}setupShadowsFromMatrix(e,t,n=!1){if(!this.enabled)return;let r=this._shadowParameters.cascadeCount;for(let t=0;t<r;t++)K(Ft(t),this._cascades[t].matrix,e);Pt.length=r,this.setupShadowsFromCascadeMatrices(Pt,t,n)}setupShadowsFromCascadeMatrices(e,t,r=!1){if(!this.enabled)return;let i=this.painter.context,a=i.gl,o=this._uniformValues;for(let t=0;t<this._shadowParameters.cascadeCount;t++)o[t===0?`u_light_matrix_0`:`u_light_matrix_1`]=e[t],i.activeTexture.set(a.TEXTURE0+n.ShadowMap0+t),this._cascades[t].texture.bindExtraParam(a.LINEAR,a.LINEAR,a.CLAMP_TO_EDGE,a.CLAMP_TO_EDGE,a.GREATER);if(this.useNormalOffset=r,r){let e=this._shadowParameters.normalOffset;o.u_shadow_normal_offset=[1,e,e],o.u_shadow_bias=[6e-5,.0012,.012]}else o.u_shadow_bias=[36e-5,.0012,.012];t.setShadowUniformValues(i,o)}getShadowUniformValues(){return this._uniformValues}getCurrentCascadeFrustum(){return this._cascades[this.painter.currentShadowCascade].frustum}computeSimplifiedTileShadowVolume(e,t,n,r){if(r[2]>=0)return{};let i=function(e,t,n){let r=n/(1<<e.canonical.z);return new ae([e.canonical.x*r+e.wrap*n,e.canonical.y*r+e.wrap*n,0],[(e.canonical.x+1)*r+e.wrap*n,(e.canonical.y+1)*r+e.wrap*n,t])}(e,t,n).getCorners(),a=t/-r[2];r[0]<0?(q(i[0],i[0],[r[0]*a,0,0]),q(i[3],i[3],[r[0]*a,0,0])):r[0]>0&&(q(i[1],i[1],[r[0]*a,0,0]),q(i[2],i[2],[r[0]*a,0,0])),r[1]<0?(q(i[0],i[0],[0,r[1]*a,0]),q(i[1],i[1],[0,r[1]*a,0])):r[1]>0&&(q(i[2],i[2],[0,r[1]*a,0]),q(i[3],i[3],[0,r[1]*a,0]));let o={};return o.vertices=i,o.planes=[Bt(i[1],i[0],i[4]),Bt(i[2],i[1],i[5]),Bt(i[3],i[2],i[6]),Bt(i[0],i[3],i[7])],o}addShadowReceiver(e,t,n){this._receivers.add(e,ae.fromTileIdAndHeight(e,t,n))}getMaxCascadeForTile(e){let t=this._receivers.get(e);return t&&t.lastCascade?t.lastCascade:0}},drawGroundEffect:ze,queryModelLayerRendered:function(e,t,n,r){let i=n.getSource();if(!i||i.type!==`model`)return{};let a=i,o={};o[e.id]=[];let s=o[e.id],c=0;for(let i of a.models){let a=n.getFeatureState(e.sourceLayer,i.id),o={type:`Unknown`,id:i.id,properties:i.featureProperties},l=e.paint.get(`model-rotation`).evaluate(o,a),u=e.paint.get(`model-scale`).evaluate(o,a),d=e.paint.get(`model-translation`).evaluate(o,a),f=e.paint.get(`model-elevation-reference`),p=[];Ue(p,i,r,i.position,l,u,d,f===`ground`,f===`ground`,!1),r.projection.name===`globe`&&(p=Je(p,r));let m=K([],r.projMatrix,p),h=t.isPointQuery()?t.screenBounds:t.screenGeometry,g=Ve(h,r,m,i.aabb);if(g!=null){let t=new S(void 0,0,0,0,i.id);t.layer=e.layer,t.properties=structuredClone(i.featureProperties),t.properties.layer=e.id,t.properties.uri=i.uri,t.properties.orientation=i.orientation,t.sourceLayer=e.sourceLayer,t.geometry={type:`Point`,coordinates:[i.position.lng,i.position.lat]},t.state=a,t.source=e.source,s.push({featureIndex:c,feature:t,intersectionZ:g})}++c}return o},queryModelLayerIntersectsFeature:function(e,t,n,r,i,a){if(!e.modelManager)return!1;let o=e.modelManager,s=t.tile.getBucket(e);if(!(s&&s instanceof Ye))return!1;for(let r in s.instancesPerModel){let c=s.instancesPerModel[r],l=n.id===void 0?n.properties&&Object.hasOwn(n.properties,`id`)?n.properties.id:void 0:n.id;if(Object.hasOwn(c.idToFeaturesIndex,l)){let n=c.features[c.idToFeaturesIndex[l]],u=o.getModel(r,a||e.scope);if(!u)return!1;let d=[],f=new A(0,0),p=s.canonical,m=Number.MAX_VALUE;for(let e=0;e<n.instancedDataCount;++e){let r=16*(n.instancedDataOffset+e),a=c.instancedDataArray.float32,o=[a[r+4],a[r+5],a[r+6]];et(p,f,Math.floor(a[r]),Math.floor(a[r+1])),Ue(d,u,i,f,n.rotation,n.scale,o,!1,!1,!1),i.projection.name===`globe`&&(d=Je(d,i));let s=K([],i.projMatrix,d),l=t.queryGeometry,h=l.isPointQuery()?l.screenBounds:l.screenGeometry,g=Ve(h,i,s,u.aabb);g!=null&&(m=Math.min(g,m))}return m!==Number.MAX_VALUE&&m}}return!1},loadMatchingModelFeature:function(e,t,n,r){let i=e.getNodesInfo()[t];if(!i||i.hiddenByReplacement||!i.node.meshes)return;let a=Number.MAX_VALUE,o=i.node,s=n.tile,c=r.calculatePosMatrix(s.tileID.toUnwrapped(),r.worldSize),l=i.evaluatedScale,u=0;r.elevation&&o.elevation&&(u=o.elevation*r.elevation.exaggeration()),Ce(c,c,[(o.anchor?o.anchor[0]:0)*(l[0]-1),(o.anchor?o.anchor[1]:0)*(l[1]-1),u]),j(c,c,l);let d=n.queryGeometry,f=d.isPointQuery()?d.screenBounds:d.screenGeometry,p=function(e){let t=K([],c,e.globalMatrix);K(t,r.expandedFarZProjMatrix,t);for(let n=0;n<e.meshes.length;++n){let i=e.meshes[n];if(n===e.lightMeshIndex)continue;let o=Ve(f,r,t,i.aabb);o!=null&&(a=Math.min(o,a))}if(e.children)for(let t of e.children)p(t)};if(p(o),a===Number.MAX_VALUE)return;let m=new A(0,0);return et(s.tileID.canonical,m,i.node.anchor[0],i.node.anchor[1]),{intersectionZ:a,position:m,feature:i.feature}},ModelSource:class e extends Le{constructor(e,t,n,r){super(),this.id=e,this.type=`model`,this.models=[],this._options=t,this._modelsInfo=new Map,this._abortController=null}cancelModelRequests(){this._abortController&&=(this._abortController.abort(),null)}async loadGLTFFromURI(e,t){let n=await this.map._requestManager.transformRequest(e,k.Model,t);return Ke(n,t)}async loadModel(t,n,r){try{let i=await this.loadGLTFFromURI(n.uri,r);if(r.aborted)return;let a=this._modelsInfo.get(t);if(!a)return;let o=We(i),s=a.modelSpec,c=new Be(t,s.uri,s.position,s.orientation,o);e.applyModelSpecification(c,s),c.computeBoundsAndApplyParent(),this.models.push(c),a.model=c}catch(e){if(r.aborted)return;this.fire(new be(Error(`Could not load model ${t} from ${n.uri}`,{cause:e})))}}async load(){this._abortController||=new AbortController;let t=this._abortController.signal,n=[];for(let r in this._options.models){let i=this._options.models[r],a=this._modelsInfo.get(r);if(a&&a.model){a.modelSpec=i;let t=a.model;t.position=i.position==null?new A(0,0):new A(i.position[0],i.position[1]),t.orientation=i.orientation??[0,0,0],e.applyModelSpecification(t,i),t.computeBoundsAndApplyParent(),this.models.push(t)}else a?a.modelSpec=i:(this._modelsInfo.set(r,{modelSpec:i,model:null}),n.push(this.loadModel(r,i,t)))}n.length===0?this.loaded()&&this.fire(new g(`data`,{dataType:`source`,sourceDataType:`metadata`})):(await Promise.allSettled(n),t.aborted||this.fire(new g(`data`,{dataType:`source`,sourceDataType:`metadata`})))}static arrayFromColorSpecification(e){let t=e;if(t===void 0)return;if(Array.isArray(t))return[t[0],t[1],t[2]];let n=W.parse(t);return n?[n.r,n.g,n.b]:void 0}static applyModelSpecification(t,n){if(n.nodeOverrides&&e.convertNodeOverrides(t,n.nodeOverrides),n.materialOverrides&&e.convertMaterialOverrides(t,n.materialOverrides),n.nodeOverrideNames&&(t.nodeOverrideNames=[...n.nodeOverrideNames]),n.materialOverrideNames&&(t.materialOverrideNames=[...n.materialOverrideNames]),n.featureProperties&&(t.featureProperties=n.featureProperties),n.lightOverrides){let r=n.lightOverrides,i=e.arrayFromColorSpecification(r[`light-ambient-color`]),a=e.arrayFromColorSpecification(r[`light-directional-color`]);t.lightOverrides={ambientIntensity:r[`light-ambient-intensity`],ambientColor:i,directionalIntensity:r[`light-directional-intensity`],directionalColor:a}}else t.lightOverrides=void 0}static convertNodeOverrides(e,t){if(Array.isArray(t)&&t.every(e=>typeof e==`string`)){e.nodeOverrideNames=[];for(let n of t)e.nodeOverrideNames.push(n)}else Object.entries(t).forEach(([t,n])=>{let r={orientation:[0,0,0],minZoom:void 0,maxZoom:void 0};if(Object.hasOwn(n,`orientation`)){let e=n.orientation;e&&(r.orientation=e)}Object.hasOwn(n,`minzoom`)&&(r.minZoom=n.minzoom),Object.hasOwn(n,`maxzoom`)&&(r.maxZoom=n.maxzoom),e.nodeOverrides.set(t,r)})}static convertMaterialOverrides(t,n){if(Array.isArray(n)&&n.every(e=>typeof e==`string`)){t.materialOverrideNames=[];for(let e of n)t.materialOverrideNames.push(e)}else Object.entries(n).forEach(([n,r])=>{let i=e.arrayFromColorSpecification(r[`model-color`]),a={color:i===void 0?new W(1,1,1):new W(i[0],i[1],i[2]),colorMix:0,emissionStrength:0,opacity:1},o=r[`model-color-mix-intensity`];o!==void 0&&(a.colorMix=o);let s=r[`model-emissive-strength`];s!==void 0&&(a.emissionStrength=s);let c=r[`model-opacity`];c!==void 0&&(a.opacity=c),t.materialOverrides.set(n,a)})}onAdd(e){this.map=e,this.load()}hasTransition(){return!1}loaded(){if(this._modelsInfo.size===0)return!0;for(let e of this._modelsInfo.values())if(e.model==null)return!1;return!0}getModels(){return this.models}loadTile(e,t){}serialize(){return this._options}setProperty(e,t){return!1}reload(){this.cancelModelRequests();let e=ce(this.id,this.scope);this.map.style.clearSource(e),this.models=[],this._modelsInfo.clear(),this.load()}onRemove(e){this.cancelModelRequests()}setModels(e){this.models=[];let t=new Map;for(let n in e){let r=e[n],i=this._modelsInfo.get(n);i&&i.modelSpec.uri===r.uri&&t.set(n,i)}if(this._modelsInfo.size!==t.size){this.cancelModelRequests();for(let[e,n]of t)n.model||t.delete(e)}this._modelsInfo=t,this._options.models=e,this.load()}},Tiled3dModelSource:class extends Le{constructor(e,t,n,r){super(),this.type=`batched-model`,this.id=e,this.tileSize=512,this._options=t,this.tiles=this._options.tiles,this.maxzoom=t.maxzoom||19,this.minzoom=t.minzoom||0,this.roundZoom=!0,this.usedInConflation=!0,this.dispatcher=n,this.reparseOverscaled=!1,this.scheme=`xyz`,this._loaded=!1,this.setEventedParent(r)}onAdd(e){this.map=e,this.load()}reload(){this.cancelTileJSONRequest();let e=ce(this.id,this.scope);this.load(()=>this.map.style.clearSource(e))}cancelTileJSONRequest(){this._tileJSONRequest&&=(this._tileJSONRequest.cancel(),null)}load(e){this._loaded=!1,this.fire(new g(`dataloading`,{dataType:`source`}));let n=Array.isArray(this.map._language)?this.map._language.join():this.map._language,r=this.map.getWorldview();this._tileJSONRequest=Ne(this._options,this.map._requestManager,n,r,(i,a)=>{this._tileJSONRequest=null,this._loaded=!0,i?(n&&console.warn(`Ensure that your requested language string is a valid BCP-47 code or list of codes. Found: ${n}`),r&&r.length!==2&&console.warn(`Requested worldview strings must be a valid ISO alpha-2 code. Found: ${r}`),this.fire(new be(i))):a&&(Object.assign(this,a),this.tileBounds=new u(a),t(a.tiles,this.map._requestManager._customAccessToken),this.fire(new g(`data`,{dataType:`source`,sourceDataType:`metadata`})),this.fire(new g(`data`,{dataType:`source`,sourceDataType:`content`}))),e&&e(i)})}hasTransition(){return!1}hasTile(e){return!this.tileBounds||this.tileBounds.contains(e.canonical)}loaded(){return this._loaded}async loadTile(e,t){let n=this.map._requestManager.normalizeTileURL(e.tileID.canonical.url(this.tiles,this.scheme)),r=!e.actor||e.state===`expired`;if(r)e.actor=this.dispatcher.getActor();else{if(e.state===`loading`)return void(e.reloadCallback=t);if(e.buckets){let t=Object.values(e.buckets);for(let e of t)e.dirty=!0;e.state=`loaded`;return}}let i=r?`loadTile`:`reloadTile`,a=new AbortController;e.request=a;let o=(n,r)=>(delete e.request,e.aborted?t(null):n&&!N(n)?t(n):(this.map._refreshExpiredTiles&&r&&e.setExpiryData(re(r.headers)),e.loadModelData(r,this.map.painter),e.state=`loaded`,t(null),void(e.reloadCallback&&=(this.loadTile(e,e.reloadCallback),null))));try{let r=await this.map._requestManager.transformRequest(n,k.Tile,a.signal);if(a.signal.aborted)return t(null);let s={request:r,data:void 0,uid:e.uid,tileID:e.tileID,tileZoom:e.tileZoom,zoom:e.tileID.overscaledZ,tileSize:this.tileSize*e.tileID.overscaleFactor(),type:this.type,source:this.id,scope:this.scope,showCollisionBoxes:this.map.showCollisionBoxes,renderSourceType:e.renderSourceType,brightness:this.map.style&&this.map.style.getBrightness()||0,pixelRatio:De.devicePixelRatio,promoteId:this.promoteId};e.request=e.actor.sendCancelable(i,s,{},o)}catch(e){if(a.signal.aborted)return t(null);t(e)}}abortTile(e){e.request&&(e.request.abort(),delete e.request),e.actor&&e.actor.notify(`abortTile`,{uid:e.uid,type:this.type,source:this.id,scope:this.scope})}serialize(){return{...this._options}}},loadModel:He};export{Ht as Standard};